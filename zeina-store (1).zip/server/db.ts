import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  User,
  Product,
  Category,
  Order,
  PurchaseInvoice,
  DiscountCoupon,
  Review,
  Banner,
  StoreSettings,
} from '../src/types';

export interface DatabaseSchema {
  users: User[];
  products: Product[];
  categories: Category[];
  orders: Order[];
  purchases: PurchaseInvoice[];
  discounts: DiscountCoupon[];
  reviews: Review[];
  banners: Banner[];
  settings: StoreSettings;
}

// Data folder and file path on server
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'zeina_db.json');

// Initial seed categories
const defaultCategories: Category[] = [
  {
    id: 'cat-1',
    name: 'Luxury Jewelry Sets',
    nameAr: 'أطقم مجوهرات فاخرة',
    slug: 'jewelry-sets',
    iconName: 'Sparkles',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80',
    itemCount: 4,
  },
  {
    id: 'cat-2',
    name: 'Necklaces & Pendants',
    nameAr: 'سلاسل وعقود زركون',
    slug: 'necklaces',
    iconName: 'Gem',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=600&q=80',
    itemCount: 6,
  },
  {
    id: 'cat-3',
    name: 'Bracelets & Bangles',
    nameAr: 'أساور وبناجر ذهبية',
    slug: 'bracelets',
    iconName: 'Watch',
    image: 'https://images.unsplash.com/photo-1611591475887-2172a50a6234?auto=format&fit=crop&w=600&q=80',
    itemCount: 5,
  },
  {
    id: 'cat-4',
    name: 'Statement & Solitaire Rings',
    nameAr: 'خواتم سوليتير ومرصعة',
    slug: 'rings',
    iconName: 'CircleDot',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=600&q=80',
    itemCount: 7,
  },
  {
    id: 'cat-5',
    name: 'Earrings & Drops',
    nameAr: 'أقراط وحلقان لؤلؤ',
    slug: 'earrings',
    iconName: 'Disc',
    image: 'https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=600&q=80',
    itemCount: 5,
  },
  {
    id: 'cat-6',
    name: 'Evening Clutches',
    nameAr: 'حقائب سهرة ومحافظ مخملية',
    slug: 'bags',
    iconName: 'ShoppingBag',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80',
    itemCount: 3,
  },
];

// Initial seed products
const defaultProducts: Product[] = [
  {
    id: 'prod-1',
    sku: 'ZN-SET-001',
    name: 'Royal Champagne Diamond Set',
    nameAr: 'طقم الزفاف الملكي المطلي ذهب عيار 18 مع أحجار زركونيا',
    description: 'A breathtaking bridal luxury jewelry set featuring sparkling micropave cubic zirconia and soft champagne gold plating.',
    descriptionAr: 'طقم ملكي متكامل يضم عقداً فخماً، أقراطاً متدلية، سواراً راقياً وخاتماً قابلاً للتعديل. مطلي بماء الذهب الوردي وعيار 18 مع ترصيع زركون سويسري براق.',
    price: 3450,
    costPrice: 1950,
    stock: 14,
    categoryId: 'cat-1',
    categoryName: 'أطقم مجوهرات فاخرة',
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.9,
    reviewsCount: 28,
    isFeatured: true,
    isBestSeller: true,
    colors: ['ذهب وردي', 'ذهب أصفر', 'فضي بلاتيني'],
    material: 'نحاس نقي مطلي ذهب 18k وحجر زركون 5A',
    createdAt: '2026-08-15T10:00:00Z',
  },
  {
    id: 'prod-2',
    sku: 'ZN-NCK-002',
    name: 'Zeina Signature Heart Pendant',
    nameAr: 'عقد زينة الأيقوني بقلب الورد ولمسات الذهب الوردي',
    description: 'Exquisite signature necklace with a dusty rose crystal heart and delicate chain matching Zeina aesthetic.',
    descriptionAr: 'العقد المميز المستوحى من هوية متجر زينة، بتعليقة قلب من الكريستال الوردي الداكن وحلقات انسيابية تعكس الأنوثة والجاذبية.',
    price: 1250,
    costPrice: 620,
    stock: 22,
    categoryId: 'cat-2',
    categoryName: 'سلاسل وعقود زركون',
    images: [
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.8,
    reviewsCount: 42,
    isFeatured: true,
    isNewArrival: true,
    colors: ['روز جولد', 'فضي نقي'],
    material: 'فضة إسترليني عيار 925 مطلية روديوم',
    createdAt: '2026-08-18T12:00:00Z',
  },
  {
    id: 'prod-3',
    sku: 'ZN-BRC-003',
    name: 'Emperatriz Twisted Gold Bangle',
    nameAr: 'إسورة الإمبراطورة المجدولة بطلاء الذهب عيار 21',
    description: 'A heavy luxury open bangle featuring textured twists and pave ends.',
    descriptionAr: 'إسورة فاخرة بتصميم روماني كلاسيكي مجدول، أطراف مرصعة بأحجار الزركون متناهية الدقة، تضفي لمسة وقار استثنائية لمناسباتك.',
    price: 1890,
    costPrice: 980,
    stock: 9,
    categoryId: 'cat-3',
    categoryName: 'أساور وبناجر ذهبية',
    images: [
      'https://images.unsplash.com/photo-1611591475887-2172a50a6234?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.7,
    reviewsCount: 19,
    isBestSeller: true,
    colors: ['ذهب أصفر', 'ذهب أبيض'],
    material: 'ستانلس ستيل 316L مقاوم للماء تماماً مطلي بتقنية PVD',
    createdAt: '2026-08-20T14:30:00Z',
  },
  {
    id: 'prod-4',
    sku: 'ZN-RNG-004',
    name: 'Princess Emerald Cut Solitaire Ring',
    nameAr: 'خاتم الأميرة بقطع الزمرد الأخضر والزركون النقي',
    description: 'A majestic statement ring centered with a deep Colombian-green synthetic emerald.',
    descriptionAr: 'خاتم سهرة خلاب بحجر مركزي قطع زمردي بلون ملكي عميق، محاط بهالة مزدوجة من أحجار الألماس الصناعي السويسري عالي البريق.',
    price: 980,
    costPrice: 420,
    stock: 18,
    categoryId: 'cat-4',
    categoryName: 'خواتم سوليتير ومرصعة',
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 5.0,
    reviewsCount: 33,
    isFeatured: true,
    colors: ['زمرد أخضر / ذهب أصفر', 'ياقوت أزرق / ذهب أبيض'],
    material: 'فضة 925 مطلية ذهب 18k مع حجر نانو زمرد فخم',
    createdAt: '2026-08-22T09:15:00Z',
  },
  {
    id: 'prod-5',
    sku: 'ZN-EAR-005',
    name: 'Celestial Pearl Cascade Earrings',
    nameAr: 'أقراط اللؤلؤ المنسدلة بتصميم العناقيد السماوية',
    description: 'Chandelier style cascading earrings combining lustrous freshwater pearls with crystal branches.',
    descriptionAr: 'حلق سهرة متدلي يجمع بين لؤلؤ المياه العذبة الطبيعي وأغصان الزركون الرقيقة، خفيف الوزن ومريح جداً للأذن طوال الأمسية.',
    price: 850,
    costPrice: 380,
    stock: 15,
    categoryId: 'cat-5',
    categoryName: 'أقراط وحلقان لؤلؤ',
    images: [
      'https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.8,
    reviewsCount: 16,
    isNewArrival: true,
    colors: ['لؤلؤ عاجي / ذهب أصفر', 'لؤلؤ وردي / روز جولد'],
    material: 'لؤلؤ طبيعي مستزرع وفضة خالصة 925 مضادة للحساسية',
    createdAt: '2026-08-24T16:00:00Z',
  },
  {
    id: 'prod-6',
    sku: 'ZN-BAG-006',
    name: 'Midnight Velvet Minaudière Clutch',
    nameAr: 'كلتش السهرة المخملي بإطار ذهبي منقوش وقفل جوهرة',
    description: 'Structured evening box clutch in rich plush velvet with detachable woven gold chain.',
    descriptionAr: 'حقيبة يد للمناسبات مصنوعة من المخمل الفاخر بتشطيب دقيق، ومزودة بسلسلة كتف منسوجة بطلاء ذهبي لا يبهت وقفل مرصع بحجر كريستالي.',
    price: 2100,
    costPrice: 1150,
    stock: 8,
    categoryId: 'cat-6',
    categoryName: 'حقائب سهرة ومحافظ مخملية',
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.9,
    reviewsCount: 12,
    isFeatured: true,
    colors: ['أسود مخملي', 'عنابي بورغندي', 'أخضر زمردي'],
    material: 'قماش مخمل تركي فاخر وهيكل معدني مطلي ذهب',
    createdAt: '2026-08-26T11:20:00Z',
  },
];

// Initial seed users (Admin passwordHash is PBKDF2 100,000 rounds for iyadsayed2007)
const defaultUsers: User[] = [
  {
    id: 'user-admin',
    name: 'إياد سيد (المدير العام)',
    email: 'iyadsayed@gmail.com',
    passwordHash: 'pbkdf2:100000:82190f63b23d16fff76e4725b9f36b08:b05001e87faaa5fa9469af7e4bc6daefc2ce14796d5fef03a7ca5e792808162d',
    role: 'admin',
    phone: '+201012345678',
    address: 'الشيخ زايد، بيفرلي هيلز',
    city: 'الجيزة',
    createdAt: '2026-08-01T00:00:00Z',
    status: 'active',
  },
  {
    id: 'user-staff',
    name: 'مريم الصاوي (مسؤولة المبيعات)',
    email: 'staff@zeinastore.com',
    passwordHash: 'pbkdf2:100000:7d1db067eb7f3a2122f326a1082afcf7:2070a281a0999d81bef898451fdd79a3cacf39037fcf4bb8f3c62b69ee54f8a7',
    role: 'staff',
    phone: '+201123456789',
    address: 'المعادي دجلة، شارع 200',
    city: 'القاهرة',
    createdAt: '2026-08-05T00:00:00Z',
    status: 'active',
  },
  {
    id: 'user-cust-1',
    name: 'نوران الشاذلي',
    email: 'nouran@example.com',
    passwordHash: 'pbkdf2:100000:7d1db067eb7f3a2122f326a1082afcf7:2070a281a0999d81bef898451fdd79a3cacf39037fcf4bb8f3c62b69ee54f8a7',
    role: 'customer',
    phone: '+201098765432',
    address: 'التجمع الخامس، شارع التسعين الشمالي، كمبوند ماونتن فيو',
    city: 'القاهرة',
    createdAt: '2026-08-10T00:00:00Z',
    status: 'active',
  },
  {
    id: 'user-cust-2',
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@example.com',
    passwordHash: 'pbkdf2:100000:7d1db067eb7f3a2122f326a1082afcf7:2070a281a0999d81bef898451fdd79a3cacf39037fcf4bb8f3c62b69ee54f8a7',
    role: 'customer',
    phone: '+201287654321',
    address: 'Beverly Hills, Villa 12, Compound Gate 3',
    city: 'Giza',
    createdAt: '2026-08-10T00:00:00Z',
    status: 'active',
  },
];

// Initial seed orders
const defaultOrders: Order[] = [
  {
    id: 'ord-1001',
    orderNumber: 'ZN-2026-1001',
    invoiceNumber: 'INV-2026-0089',
    customerId: 'user-cust-1',
    customerName: 'نوران الشاذلي',
    customerEmail: 'nouran@example.com',
    customerPhone: '+201098765432',
    shippingAddress: 'شارع التسعين الشمالي، فيلا 14، التجمع الخامس',
    city: 'القاهرة الجديدة',
    items: [
      {
        productId: 'prod-1',
        name: 'Royal Champagne Diamond Set',
        nameAr: 'طقم الزفاف الملكي المطلي ذهب عيار 18 مع أحجار زركونيا',
        price: 3450,
        costPrice: 1950,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=400&q=80',
        selectedColor: 'ذهب وردي',
      },
      {
        productId: 'prod-2',
        name: 'Zeina Signature Heart Pendant',
        nameAr: 'عقد زينة الأيقوني بقلب الورد ولمسات الذهب الوردي',
        price: 1250,
        costPrice: 620,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=400&q=80',
        selectedColor: 'روز جولد',
      },
    ],
    subtotal: 4700,
    discount: 470,
    discountCode: 'ZEINA10',
    shippingFee: 0,
    tax: 0,
    total: 4230,
    totalAmount: 4230,
    status: 'delivered',
    paymentMethod: 'card',
    paymentStatus: 'paid',
    notes: 'يرجى التغليف كهدية فاخرة مع كارت إهداء خاص',
    createdAt: '2026-08-28T14:20:00Z',
    deliveredAt: '2026-08-30T17:00:00Z',
  },
  {
    id: 'ord-1002',
    orderNumber: 'ZN-2026-1002',
    invoiceNumber: 'INV-2026-0090',
    customerId: 'user-cust-2',
    customerName: 'Sarah Jenkins',
    customerEmail: 'sarah.jenkins@example.com',
    customerPhone: '+201287654321',
    shippingAddress: 'Beverly Hills, Villa 12, Compound Gate 3',
    city: 'Giza',
    items: [
      {
        productId: 'prod-4',
        name: 'Princess Emerald Cut Solitaire Ring',
        nameAr: 'خاتم الأميرة بقطع الزمرد الأخضر والزركون النقي',
        price: 980,
        costPrice: 420,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=400&q=80',
        selectedColor: 'زمرد أخضر / ذهب أصفر',
      },
    ],
    subtotal: 1960,
    discount: 0,
    shippingFee: 0,
    tax: 0,
    total: 1960,
    totalAmount: 1960,
    status: 'shipped',
    paymentMethod: 'instapay',
    paymentStatus: 'paid',
    notes: 'الاستلام عند البوابة الرئيسية',
    createdAt: '2026-09-02T11:45:00Z',
  },
  {
    id: 'ord-1003',
    orderNumber: 'ZN-2026-1003',
    invoiceNumber: 'INV-2026-0091',
    customerId: 'user-cust-1',
    customerName: 'نوران الشاذلي - VIP Client',
    customerEmail: 'houda.m@example.com',
    customerPhone: '+201145678901',
    shippingAddress: 'الدقي، شارع مصدق أمام بنك مصر',
    city: 'الجيزة',
    items: [
      {
        productId: 'prod-6',
        name: 'Midnight Velvet Minaudière Clutch',
        nameAr: 'كلتش السهرة المخملي بإطار ذهبي منقوش وقفل جوهرة',
        price: 2100,
        costPrice: 1150,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=400&q=80',
        selectedColor: 'عنابي بورغندي',
      },
    ],
    subtotal: 2100,
    discount: 315,
    discountCode: 'SUMMER15',
    shippingFee: 0,
    tax: 0,
    total: 1785,
    totalAmount: 1785,
    status: 'processing',
    paymentMethod: 'cod',
    paymentStatus: 'pending',
    notes: 'تأكيد موعد التسليم بعد الساعة 5 مساءً',
    createdAt: '2026-09-04T09:10:00Z',
  },
];

// Initial seed supplier purchase invoices
const defaultPurchases: PurchaseInvoice[] = [
  {
    id: 'pur-101',
    invoiceNumber: 'PINV-2026-012',
    supplierName: 'مجموعة الرواد لاستيراد الذهب السويسري ومجوهرات الزركون',
    supplierPhone: '+20227954120',
    supplierTaxId: 'EG-388-990-210',
    date: '2026-08-10',
    createdAt: '2026-08-10T10:00:00Z',
    status: 'received',
    notes: 'دفعة أطقم الزفاف الملكية والخواتم السوليتير - تم الفحص والوزن بنجاح',
    totalAmount: 39000,
    items: [
      {
        productId: 'prod-1',
        productName: 'طقم الزفاف الملكي المطلي ذهب عيار 18 مع أحجار زركونيا',
        costPrice: 1950,
        quantity: 20,
        total: 39000,
      },
    ],
  },
  {
    id: 'pur-102',
    invoiceNumber: 'PINV-2026-013',
    supplierName: 'ورشة القصر الإيطالي للفضيات والطلاء بالروديوم',
    supplierPhone: '+201004455667',
    supplierTaxId: 'EG-511-209-774',
    date: '2026-08-14',
    createdAt: '2026-08-14T15:30:00Z',
    status: 'received',
    notes: 'دفعة سلاسل زينة بقلب الكريستال والأساور المجدولة المقاومة للماء',
    totalAmount: 31000,
    items: [
      {
        productId: 'prod-2',
        productName: 'عقد زينة الأيقوني بقلب الورد ولمسات الذهب الوردي',
        costPrice: 620,
        quantity: 50,
        total: 31000,
      },
    ],
  },
];

// Initial seed discounts
const defaultDiscounts: DiscountCoupon[] = [
  {
    id: 'disc-1',
    code: 'VIP20',
    description: 'خصم خاص 20% لعملاء متجر زينة المميزين',
    type: 'percent',
    value: 20,
    minOrder: 1500,
    validUntil: '2026-12-31',
    isActive: true,
    usageCount: 14,
    usageLimit: 100,
  },
  {
    id: 'disc-2',
    code: 'ZEINA10',
    description: 'كوبون الترحيب 10% لجميع المشترين الجدد',
    type: 'percent',
    value: 10,
    minOrder: 500,
    validUntil: '2026-12-31',
    isActive: true,
    usageCount: 46,
    usageLimit: 500,
  },
  {
    id: 'disc-3',
    code: 'EID2026',
    description: 'خصم ثابت 250 ج.م بمناسبة موسم الأعياد',
    type: 'fixed',
    value: 250,
    minOrder: 2000,
    validUntil: '2026-10-30',
    isActive: true,
    usageCount: 29,
    usageLimit: 200,
  },
  {
    id: 'disc-4',
    code: 'SUMMER15',
    description: 'خصم 15% على تشكيلة الصيف وحقائب السهرة',
    type: 'percent',
    value: 15,
    minOrder: 1000,
    validUntil: '2026-09-30',
    isActive: true,
    usageCount: 8,
    usageLimit: 150,
  },
];

// Initial reviews
const defaultReviews: Review[] = [
  {
    id: 'rev-1',
    productId: 'prod-1',
    productName: 'طقم الزفاف الملكي المطلي ذهب عيار 18 مع أحجار زركونيا',
    customerName: 'د. ياسمين الكردي',
    rating: 5,
    comment: 'الطقم يفوق الخيال حرفياً! ارتديه في فرح أختي والجميع كان يسألني عنه. اللمعان كأنه ألماس طبيعي خالص والتغليف فاخر جداً.',
    date: '2026-08-25',
    status: 'approved',
  },
  {
    id: 'rev-2',
    productId: 'prod-2',
    productName: 'عقد زينة الأيقوني بقلب الورد ولمسات الذهب الوردي',
    customerName: 'مريم العبد',
    rating: 5,
    comment: 'رقيق جداً وأنيق في اللبس، لونه ثابت بعد استخدام يومي أكثر من شهر. شكراً زينة ستور على سرعة التوصيل وذوقكم الراقي.',
    date: '2026-08-27',
    status: 'approved',
  },
  {
    id: 'rev-3',
    productId: 'prod-4',
    productName: 'خاتم الأميرة بقطع الزمرد الأخضر والزركون النقي',
    customerName: 'سلمى رضوان',
    rating: 5,
    comment: 'اللون الأخضر ملكي ساحر ومقاس الخاتم مضبوط ومريح جداً. أفضل تجربة شراء مجوهرات أونلاين في مصر.',
    date: '2026-08-30',
    status: 'approved',
  },
];

// Initial banners
const defaultBanners: Banner[] = [
  {
    id: 'ban-1',
    titleAr: 'مجموعة العروس الملكية 2026',
    subtitleAr: 'تألقي بأفخم أطقم المجوهرات المطلية بماء الذهب والزركون السويسري عالي النقاء',
    tagAr: 'تشكيلة حصرية فاخرة',
    titleEn: 'Royal Bridal Collection 2026',
    subtitleEn: 'Shine bright with 18k gold-plated jewelry sets and flawless Swiss zirconia.',
    ctaTextAr: 'تسوقي التشكيلة الملكية',
    ctaLink: 'jewelry-sets',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1600&q=85',
    badge: 'الأكثر طلباً',
    active: true,
    order: 1,
  },
  {
    id: 'ban-2',
    titleAr: 'سحر الزمرد وسوليتير السهرة',
    subtitleAr: 'خواتم وعقود مصممة لأصحاب الذوق الرفيع بأحجار تحبس الأنفاس',
    tagAr: 'وصل حديثاً للمتجر',
    titleEn: 'Emerald Charm & Solitaire Elegance',
    subtitleEn: 'Handcrafted rings and pendants designed for timeless sophistication.',
    ctaTextAr: 'استكشفي الخواتم والعقود',
    ctaLink: 'rings',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=1600&q=85',
    badge: 'جديد ومميز',
    active: true,
    order: 2,
  },
  {
    id: 'ban-3',
    titleAr: 'حقائب السهرة المخملية المنقوشة',
    subtitleAr: 'كلتشات سهرة بتفاصيل ذهبية مذهلة تكمل إطلالتك في أرقى المناسبات',
    tagAr: 'إصدارات محدودة',
    titleEn: 'Luxury Velvet Evening Clutches',
    subtitleEn: 'Handcrafted clutches with gold filigree frames and jewel clasps.',
    ctaTextAr: 'شاهدي حقائب السهرة',
    ctaLink: 'bags',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1600&q=85',
    active: true,
    order: 3,
  },
];

// Initial settings with all SOP #3 fields
const defaultSettings: StoreSettings = {
  storeName: 'Zeina Store',
  storeNameAr: 'متجر زينة للإكسسوارات الفاخرة',
  storeDescriptionAr: 'متجر زينة هو وجهتكم الأولى لأرقى تشكيلات المجوهرات العصرية والأطقم الملكية وحقائب السهرة المطلية بالذهب والزركون السويسري الفاخر.',
  storeDescriptionEn: 'Zeina Store is your premier destination for luxury bridal jewelry sets, zircon necklaces, bangles, and evening accessories.',
  logoUrl: '',
  faviconUrl: '',
  taxNumber: 'EG-928-117-450',
  commercialRecord: 'CR-1098234',
  phone: '+20 10 9988 7766',
  email: 'contact@zeinastore.com',
  address: 'ممشى أهل مصر، كورنيش النيل، حي الزمالك الفاخر',
  city: 'القاهرة، جمهورية مصر العربية',
  currency: 'EGP',
  currencySymbol: 'ج.م',
  shippingFeeFlat: 50,
  freeShippingThreshold: 1500,
  taxPercentage: 0,
  instagramUrl: 'https://instagram.com/zeinastore',
  facebookUrl: 'https://facebook.com/zeinastore',
  whatsappNumber: '+201099887766',
  tiktokUrl: 'https://tiktok.com/@zeinastore',
  snapchatUrl: 'https://snapchat.com/add/zeinastore',
  returnPolicyAr: 'يحق للعميل استبدال أو استرجاع المنتج خلال 14 يوماً من تاريخ الاستلام بشرط سلامة المنتج وغلافه الأصلي والفاتورة.',
  privacyPolicyAr: 'نلتزم في متجر زينة بحماية خصوصية عملائنا الكرام وأمان بياناتهم الشخصية واستخدامها فقط لإتمام الطلبات والتسليم.',
  termsOfServiceAr: 'تخضع كافة المشتريات والطلبات لشروط الخدمة المعمول بها في جمهورية مصر العربية وسياسات متجر زينة الرسمية.',
  paymentMethods: {
    cod: true,
    card: true,
    instapay: true,
    vodafone_cash: true,
  },
};

// Singleton in-memory database cache
let memoryDb: DatabaseSchema | null = null;

// Ensure database directory exists
function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

// Atomic save to disk
function persistToDisk(data: DatabaseSchema): void {
  ensureDataDir();
  const tmpFile = `${DB_FILE}.tmp.${Date.now()}`;
  try {
    fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tmpFile, DB_FILE);
  } catch (err) {
    console.error('Failed to atomically write database file:', err);
    // Fallback direct write
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  }
}

// Initialize or load database
export function getDb(): DatabaseSchema {
  if (memoryDb) return memoryDb;

  ensureDataDir();

  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as DatabaseSchema;

      // Ensure all collections exist
      memoryDb = {
        users: parsed.users || defaultUsers,
        products: parsed.products || defaultProducts,
        categories: parsed.categories || defaultCategories,
        orders: parsed.orders || defaultOrders,
        purchases: parsed.purchases || defaultPurchases,
        discounts: parsed.discounts || defaultDiscounts,
        reviews: parsed.reviews || defaultReviews,
        banners: parsed.banners || defaultBanners,
        settings: { ...defaultSettings, ...(parsed.settings || {}) },
      };

      // Ensure admin exists with iyadsayed@gmail.com
      const adminIdx = memoryDb.users.findIndex((u) => u.role === 'admin');
      if (adminIdx === -1) {
        memoryDb.users.unshift(defaultUsers[0]);
        persistToDisk(memoryDb);
      } else {
        const admin = memoryDb.users[adminIdx];
        if (admin.email === 'admin@zeinastore.com') {
          admin.email = 'iyadsayed@gmail.com';
          admin.name = 'إياد سيد (المدير العام)';
          persistToDisk(memoryDb);
        }
      }

      return memoryDb;
    } catch (err) {
      console.error('Error parsing existing database file, re-seeding:', err);
    }
  }

  // First time initialization
  memoryDb = {
    users: defaultUsers,
    products: defaultProducts,
    categories: defaultCategories,
    orders: defaultOrders,
    purchases: defaultPurchases,
    discounts: defaultDiscounts,
    reviews: defaultReviews,
    banners: defaultBanners,
    settings: defaultSettings,
  };

  persistToDisk(memoryDb);
  return memoryDb;
}

export function saveDb(data: DatabaseSchema): void {
  memoryDb = data;
  persistToDisk(data);
}

// ==========================================
// Cryptography & Password Hashing (PBKDF2)
// ==========================================
export function hashPasswordServer(password: string): string {
  const saltBuf = crypto.randomBytes(16);
  const salt = saltBuf.toString('hex');
  const iterations = 100000;
  const key = crypto.pbkdf2Sync(password, saltBuf, iterations, 32, 'sha256').toString('hex');
  return `pbkdf2:${iterations}:${salt}:${key}`;
}

export function verifyPasswordServer(passwordAttempt: string, storedHash: string): boolean {
  if (!storedHash) return false;

  // Modern PBKDF2
  if (storedHash.startsWith('pbkdf2:')) {
    const parts = storedHash.split(':');
    if (parts.length === 4) {
      const iterations = parseInt(parts[1], 10);
      const salt = parts[2];
      const expectedKey = parts[3];
      // 1. Try raw salt buffer (matches Web Crypto deriveBits with hexToBytes)
      try {
        const saltBuf = Buffer.from(salt, 'hex');
        const keyWithBuf = crypto.pbkdf2Sync(passwordAttempt, saltBuf, iterations, 32, 'sha256').toString('hex');
        if (keyWithBuf === expectedKey) return true;
      } catch {}
      // 2. Fallback in case salt was treated as raw utf8 string
      try {
        const keyWithString = crypto.pbkdf2Sync(passwordAttempt, salt, iterations, 32, 'sha256').toString('hex');
        if (keyWithString === expectedKey) return true;
      } catch {}
      return false;
    }
  }

  // Legacy fallback
  return storedHash === passwordAttempt || storedHash === `hash_${passwordAttempt}`;
}

// ==========================================
// Server-Side Anti-Brute Force Lockout
// ==========================================
interface LockoutState {
  attempts: number;
  lockedUntil: number | null;
}

const lockoutStore = new Map<string, LockoutState>();
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes

export function checkServerLockout(identifier: string): { isLocked: boolean; remainingMinutes: number } {
  const state = lockoutStore.get(identifier);
  if (!state || !state.lockedUntil) {
    return { isLocked: false, remainingMinutes: 0 };
  }

  const now = Date.now();
  if (now >= state.lockedUntil) {
    lockoutStore.delete(identifier);
    return { isLocked: false, remainingMinutes: 0 };
  }

  const remainingMs = state.lockedUntil - now;
  const remainingMinutes = Math.max(1, Math.ceil(remainingMs / (60 * 1000)));
  return { isLocked: true, remainingMinutes };
}

export function recordFailedServerAttempt(identifier: string): { isNowLocked: boolean; remainingAttempts: number } {
  let state = lockoutStore.get(identifier);
  if (!state) {
    state = { attempts: 0, lockedUntil: null };
    lockoutStore.set(identifier, state);
  }

  state.attempts += 1;

  if (state.attempts >= MAX_ATTEMPTS) {
    state.lockedUntil = Date.now() + LOCKOUT_DURATION_MS;
    return { isNowLocked: true, remainingAttempts: 0 };
  }

  return { isNowLocked: false, remainingAttempts: MAX_ATTEMPTS - state.attempts };
}

export function resetServerLockout(identifier: string): void {
  lockoutStore.delete(identifier);
}

// ==========================================
// Server-Side Session Token Management
// ==========================================
export interface ActiveSession {
  token: string;
  userId: string;
  email: string;
  role: string;
  createdAt: number;
  expiresAt: number;
}

const activeSessions = new Map<string, ActiveSession>();
const SESSION_LIFETIME_MS = 24 * 60 * 60 * 1000; // 24 hours

export function createServerSession(user: User): string {
  const token = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  const session: ActiveSession = {
    token,
    userId: user.id,
    email: user.email,
    role: user.role,
    createdAt: now,
    expiresAt: now + SESSION_LIFETIME_MS,
  };
  activeSessions.set(token, session);
  return token;
}

export function validateServerSession(token: string): ActiveSession | null {
  if (!token) return null;
  const session = activeSessions.get(token);
  if (!session) return null;

  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return null;
  }
  return session;
}

export function invalidateServerSession(token: string): void {
  activeSessions.delete(token);
}

export function invalidateAllUserSessions(userId: string): void {
  for (const [token, session] of activeSessions.entries()) {
    if (session.userId === userId) {
      activeSessions.delete(token);
    }
  }
}

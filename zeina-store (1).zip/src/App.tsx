import React, { useState } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { AuthModal } from './components/AuthModal';
import { InvoiceModal } from './components/InvoiceModal';
import { StorefrontHome } from './views/StorefrontHome';
import { StorefrontShop } from './views/StorefrontShop';
import { StorefrontProductDetail } from './views/StorefrontProductDetail';
import { StorefrontCheckout } from './views/StorefrontCheckout';
import { StorefrontAccount } from './views/StorefrontAccount';
import { StorefrontAbout } from './views/StorefrontAbout';
import { StorefrontContact } from './views/StorefrontContact';
import { AdminDashboard } from './views/AdminDashboard';
import { AdminLoginView } from './views/AdminLoginView';
import { validateAdminSession } from './utils/security';
import { CheckCircle2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    currentUser,
    toastMessage,
    previewOrder,
    setPreviewOrder,
    previewPurchase,
    setPreviewPurchase,
    settings,
  } = useStore();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);

  const isAdminView = currentView.startsWith('admin');
  const hasAdminAccess =
    (currentUser?.role === 'admin' || currentUser?.role === 'staff') && validateAdminSession();

  return (
    <div className="min-h-screen bg-[#F7F1E8] text-[#2B211D] flex flex-col font-sans selection:bg-[#B99A68] selection:text-white">
      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#2B211D] text-[#F7F1E8] border border-[#B99A68] px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-slideUp">
          <CheckCircle2 className="w-5 h-5 text-[#B99A68]" />
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Official Invoice Modal (Sales & Purchase PDF) */}
      <InvoiceModal
        isOpen={!!previewOrder || !!previewPurchase}
        order={previewOrder || undefined}
        purchase={previewPurchase || undefined}
        settings={settings}
        onClose={() => {
          setPreviewOrder(null);
          setPreviewPurchase(null);
        }}
      />

      {/* Authentication Modal */}
      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />

      {/* Cart Slide-Over Drawer */}
      <CartDrawer isOpen={cartDrawerOpen} onClose={() => setCartDrawerOpen(false)} />

      {/* Header - on storefront views */}
      {!isAdminView && (
        <Header
          onOpenAuth={() => setAuthModalOpen(true)}
          onOpenCart={() => setCartDrawerOpen(true)}
        />
      )}

      {/* Main Content Router */}
      <div className="flex-1">
        {isAdminView ? (
          hasAdminAccess ? (
            <AdminDashboard />
          ) : (
            <AdminLoginView
              onSuccess={() => setCurrentView('admin-dashboard')}
              onBackToStore={() => setCurrentView('home')}
            />
          )
        ) : (
          <>
            {currentView === 'home' && <StorefrontHome />}
            {currentView === 'shop' && <StorefrontShop />}
            {currentView === 'product-detail' && <StorefrontProductDetail />}
            {currentView === 'checkout' && <StorefrontCheckout />}
            {currentView === 'account' && (
              <StorefrontAccount onOpenAuth={() => setAuthModalOpen(true)} />
            )}
            {currentView === 'about' && <StorefrontAbout />}
            {currentView === 'contact' && <StorefrontContact />}
          </>
        )}
      </div>

      {/* Footer - on storefront views */}
      {!isAdminView && <Footer />}
    </div>
  );
};

export function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}

export default App;

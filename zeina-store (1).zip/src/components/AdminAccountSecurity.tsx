import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { updateAdminCredentials, getUsers } from '../db/storage';
import {
  Shield,
  KeyRound,
  Mail,
  Lock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Eye,
  EyeOff,
} from 'lucide-react';

export const AdminAccountSecurity: React.FC = () => {
  const { currentUser, showToast, logout } = useStore();
  const users = getUsers();
  const currentAdmin = users.find((u) => u.role === 'admin') || currentUser;

  // Change Email State
  const [newEmail, setNewEmail] = useState('');
  const [emailCurrentPassword, setEmailCurrentPassword] = useState('');
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailMsg, setEmailMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Change Password State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [passLoading, setPassLoading] = useState(false);
  const [passMsg, setPassMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailMsg(null);

    if (!newEmail.trim() || !emailCurrentPassword) {
      setEmailMsg({ type: 'error', text: 'يرجى إدخال البريد الإلكتروني الجديد وكلمة المرور الحالية للتأكيد' });
      return;
    }

    setEmailLoading(true);
    try {
      const res = await updateAdminCredentials(emailCurrentPassword, newEmail.trim());
      if (res.success) {
        setEmailMsg({ type: 'success', text: `تم تحديث البريد الإلكتروني بنجاح إلى: ${res.updatedEmail}` });
        setNewEmail('');
        setEmailCurrentPassword('');
        showToast('تم تحديث بريد الأدمن بنجاح ✨');
      } else {
        setEmailMsg({ type: 'error', text: res.error || 'فشل تحديث البريد الإلكتروني' });
      }
    } catch (err) {
      setEmailMsg({ type: 'error', text: 'حدث خطأ غير متوقع أثناء معالجة الطلب' });
    } finally {
      setEmailLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);

    if (!currentPassword || !newPassword || !confirmPassword) {
      setPassMsg({ type: 'error', text: 'يرجى تعبئة كافة حقول كلمة المرور' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setPassMsg({ type: 'error', text: 'كلمة المرور الجديدة وتأكيدها غير متطابقين' });
      return;
    }

    if (newPassword.length < 6) {
      setPassMsg({ type: 'error', text: 'كلمة المرور الجديدة يجب ألا تقل عن 6 خانات' });
      return;
    }

    if (newPassword === currentPassword) {
      setPassMsg({ type: 'error', text: 'كلمة المرور الجديدة يجب أن تكون مختلفة عن الحالية' });
      return;
    }

    setPassLoading(true);
    try {
      const res = await updateAdminCredentials(currentPassword, undefined, newPassword);
      if (res.success && res.requireRelogin) {
        setPassMsg({
          type: 'success',
          text: 'تم تحديث كلمة المرور وتشفيرها بنجاح! تم إنهاء كافة الجلسات النشطة. جاري تسجيل الخروج...',
        });
        showToast('تم تغيير كلمة المرور بنجاح. يرجى تسجيل الدخول مجدداً.');
        setTimeout(() => {
          logout();
        }, 1800);
      } else {
        setPassMsg({ type: 'error', text: res.error || 'فشل تحديث كلمة المرور' });
      }
    } catch (err) {
      setPassMsg({ type: 'error', text: 'حدث خطأ غير متوقع أثناء تغيير كلمة المرور' });
    } finally {
      setPassLoading(false);
    }
  };

  return (
    <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#D8CBBE] pb-4">
        <div>
          <h3 className="font-bold text-base font-serif text-[#2B211D] flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#B99A68]" />
            <span>حساب المدير العام وإعدادات الأمان (Admin Security & Credentials)</span>
          </h3>
          <p className="text-xs text-[#7A6A60] mt-1">
            إدارة بيانات الدخول الخاصة بحساب الإدارة، وتشفير كلمات المرور وحماية الجلسات.
          </p>
        </div>

        {/* Security Status Badge */}
        <div className="bg-[#2B211D] text-[#D8C19A] px-3.5 py-1.5 rounded-xl text-[11px] flex items-center gap-2 self-start sm:self-auto shadow-xs">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-mono font-bold">PBKDF2 SHA-256 Active</span>
        </div>
      </div>

      {/* Current Account Summary Banner */}
      <div className="bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2B211D] text-[#D8C19A] flex items-center justify-center font-bold text-base">
            إ
          </div>
          <div>
            <p className="font-bold text-[#2B211D]">{currentAdmin?.name || 'المدير العام'}</p>
            <p className="text-[#7A6A60] font-mono mt-0.5">{currentAdmin?.email || 'iyadsayed@gmail.com'}</p>
          </div>
        </div>
        <div className="text-right sm:text-left text-[11px] text-[#7A6A60]">
          <span className="inline-block bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-md">
            حساب مدير معتمد
          </span>
        </div>
      </div>

      {/* Two Forms Grid: 1. Update Email  |  2. Update Password */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form 1: Update Email */}
        <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4">
          <h4 className="font-bold text-xs text-[#2B211D] flex items-center gap-2 border-b border-[#E8DDD0] pb-2.5">
            <Mail className="w-4 h-4 text-[#B99A68]" />
            <span>تعديل البريد الإلكتروني لحساب الأدمن</span>
          </h4>

          {emailMsg && (
            <div
              className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                emailMsg.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}
            >
              {emailMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              ) : (
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
              )}
              <span>{emailMsg.text}</span>
            </div>
          )}

          <form onSubmit={handleUpdateEmail} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-semibold text-[#2B211D] mb-1">البريد الإلكتروني الجديد</label>
              <input
                type="email"
                required
                dir="ltr"
                placeholder="new.email@example.com"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-[#2B211D] mb-1">
                كلمة المرور الحالية (شرط أمني إلزامي للتأكيد)
              </label>
              <input
                type="password"
                required
                dir="ltr"
                placeholder="••••••••••••"
                value={emailCurrentPassword}
                onChange={(e) => setEmailCurrentPassword(e.target.value)}
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={emailLoading}
              className="w-full py-2.5 bg-[#2B211D] hover:bg-[#B99A68] text-white font-bold rounded-xl transition shadow-xs flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {emailLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <span>حفظ البريد الإلكتروني الجديد</span>
              )}
            </button>
          </form>
        </div>

        {/* Form 2: Update Password */}
        <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4">
          <h4 className="font-bold text-xs text-[#2B211D] flex items-center gap-2 border-b border-[#E8DDD0] pb-2.5">
            <KeyRound className="w-4 h-4 text-[#B99A68]" />
            <span>تغيير كلمة المرور للأدمن (مع تشفير PBKDF2)</span>
          </h4>

          {passMsg && (
            <div
              className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                passMsg.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}
            >
              {passMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              ) : (
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
              )}
              <span>{passMsg.text}</span>
            </div>
          )}

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-[11px] flex items-start gap-2">
            <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>شرط أمني:</strong> عند تعديل كلمة المرور سيتم إنهاء كافة الجلسات المسجلة فوراً (Force logout) لحماية الحساب.
            </p>
          </div>

          <form onSubmit={handleUpdatePassword} className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-[#2B211D] mb-1">كلمة المرور الحالية</label>
              <input
                type={showPass ? 'text' : 'password'}
                required
                dir="ltr"
                placeholder="••••••••••••"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-[#2B211D] mb-1">كلمة المرور الجديدة (6 خانات على الأقل)</label>
              <input
                type={showPass ? 'text' : 'password'}
                required
                dir="ltr"
                placeholder="••••••••••••"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-[#2B211D] mb-1">تأكيد كلمة المرور الجديدة</label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  required
                  dir="ltr"
                  placeholder="••••••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 pl-9 text-[#2B211D] outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute left-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={passLoading}
              className="w-full py-2.5 bg-[#B99A68] hover:bg-[#A88856] text-white font-bold rounded-xl transition shadow-xs flex items-center justify-center gap-2 disabled:opacity-50 mt-1"
            >
              {passLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <span>تحديث كلمة المرور وتشفيرها</span>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

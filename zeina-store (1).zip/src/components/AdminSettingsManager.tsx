import React, { useState, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { StoreSettings } from '../types';
import { Logo } from './Logo';
import {
  Store,
  Upload,
  RotateCcw,
  Save,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Share2,
  CreditCard,
  FileText,
  Building2,
  DollarSign,
  CheckCircle2,
  Sparkles,
  Info,
  Layers,
} from 'lucide-react';

export const AdminSettingsManager: React.FC = () => {
  const { settings, updateSettingsAction, showToast } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form states initialized from settings
  const [formData, setFormData] = useState<StoreSettings>({ ...settings });
  const [logoPreview, setLogoPreview] = useState<string>(settings.logoUrl || '');
  const [activeSubTab, setActiveSubTab] = useState<
    'general' | 'contact' | 'social' | 'pricing' | 'payments' | 'policies' | 'invoice'
  >('general');
  const [isSaving, setIsSaving] = useState(false);

  // Keep form data in sync if settings update externally
  React.useEffect(() => {
    setFormData({ ...settings });
    setLogoPreview(settings.logoUrl || '');
  }, [settings]);

  const handleChange = (field: keyof StoreSettings, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handlePaymentToggle = (key: keyof NonNullable<StoreSettings['paymentMethods']>) => {
    setFormData((prev) => ({
      ...prev,
      paymentMethods: {
        ...prev.paymentMethods,
        [key]: !prev.paymentMethods?.[key],
      },
    }));
  };

  // Handle Logo Upload
  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/') && !file.name.endsWith('.svg')) {
      alert('يرجى اختيار ملف صورة صالح (PNG, SVG, JPG, WebP)');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setLogoPreview(dataUrl);
      setFormData((prev) => ({ ...prev, logoUrl: dataUrl }));
      showToast('تم تحميل الشعار بنجاح! اضغط على حفظ الإعدادات لتثبيته.');
    };
    reader.readAsDataURL(file);
  };

  const handleResetToDefaultLogo = () => {
    setLogoPreview('');
    setFormData((prev) => ({ ...prev, logoUrl: '' }));
    showToast('تمت استعادة الشعار الافتراضي للمتجر');
  };

  const handleSaveAll = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await updateSettingsAction(formData);
      showToast('تم حفظ كافة إعدادات المتجر بنجاح ✨');
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء حفظ الإعدادات');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] space-y-6">
      {/* Header & Quick Save */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#D8CBBE] pb-4">
        <div>
          <h3 className="font-bold text-base font-serif text-[#2B211D] flex items-center gap-2">
            <Store className="w-5 h-5 text-[#B99A68]" />
            <span>لوحة الإعدادات الشاملة للمتجر (Store Configuration)</span>
          </h3>
          <p className="text-xs text-[#7A6A60] mt-1">
            تحكم بكافة تفاصيل وهوية المتجر، الشعار الديناميكي، وسائل الدفع، والسياسات الرسمية.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSaveAll}
          disabled={isSaving}
          className="px-6 py-2.5 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm disabled:opacity-50 self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>{isSaving ? 'جاري الحفظ...' : 'حفظ التعديلات'}</span>
        </button>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-[#D8CBBE] pb-3 text-xs">
        <button
          type="button"
          onClick={() => setActiveSubTab('general')}
          className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
            activeSubTab === 'general'
              ? 'bg-[#2B211D] text-white shadow-xs'
              : 'bg-[#E8DDD0]/60 text-[#7A6A60] hover:bg-[#E8DDD0] hover:text-[#2B211D]'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>عامة والشعار</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('contact')}
          className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
            activeSubTab === 'contact'
              ? 'bg-[#2B211D] text-white shadow-xs'
              : 'bg-[#E8DDD0]/60 text-[#7A6A60] hover:bg-[#E8DDD0] hover:text-[#2B211D]'
          }`}
        >
          <Phone className="w-4 h-4" />
          <span>بيانات التواصل</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('social')}
          className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
            activeSubTab === 'social'
              ? 'bg-[#2B211D] text-white shadow-xs'
              : 'bg-[#E8DDD0]/60 text-[#7A6A60] hover:bg-[#E8DDD0] hover:text-[#2B211D]'
          }`}
        >
          <Share2 className="w-4 h-4" />
          <span>التواصل الاجتماعي</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('pricing')}
          className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
            activeSubTab === 'pricing'
              ? 'bg-[#2B211D] text-white shadow-xs'
              : 'bg-[#E8DDD0]/60 text-[#7A6A60] hover:bg-[#E8DDD0] hover:text-[#2B211D]'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>العملة والشحن</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('payments')}
          className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
            activeSubTab === 'payments'
              ? 'bg-[#2B211D] text-white shadow-xs'
              : 'bg-[#E8DDD0]/60 text-[#7A6A60] hover:bg-[#E8DDD0] hover:text-[#2B211D]'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>طرق الدفع</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('policies')}
          className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
            activeSubTab === 'policies'
              ? 'bg-[#2B211D] text-white shadow-xs'
              : 'bg-[#E8DDD0]/60 text-[#7A6A60] hover:bg-[#E8DDD0] hover:text-[#2B211D]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>السياسات والقوانين</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('invoice')}
          className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
            activeSubTab === 'invoice'
              ? 'bg-[#2B211D] text-white shadow-xs'
              : 'bg-[#E8DDD0]/60 text-[#7A6A60] hover:bg-[#E8DDD0] hover:text-[#2B211D]'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>بيانات الفاتورة</span>
        </button>
      </div>

      <form onSubmit={handleSaveAll} className="space-y-6">
        {/* ==================================================== */}
        {/* SUBTAB 1: GENERAL & DYNAMIC LOGO                     */}
        {/* ==================================================== */}
        {activeSubTab === 'general' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Dynamic Logo Section (SOP #3 Section 3) */}
            <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E8DDD0] pb-3">
                <div>
                  <h4 className="font-bold text-sm text-[#2B211D] flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#B99A68]" />
                    <span>شعار المتجر الرسمي (Dynamic Logo)</span>
                  </h4>
                  <p className="text-[11px] text-[#7A6A60] mt-0.5">
                    ارفع شعاراً مخصصاً ليظهر في رأس المتجر وتذييل الصفحات وكافة فواتير المبيعات والتوريد تلقائياً.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleLogoFileChange}
                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>رفع شعار جديد</span>
                  </button>

                  {logoPreview && (
                    <button
                      type="button"
                      onClick={handleResetToDefaultLogo}
                      className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-rose-200"
                      title="استعادة الشعار الأصلي"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>استعادة الافتراضي</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Live Preview Box */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-[#F7F1E8] border border-[#D8CBBE] rounded-xl flex flex-col items-center justify-center min-h-[140px] text-center space-y-2">
                  <span className="text-[10px] font-bold text-[#7A6A60] uppercase tracking-wider">
                    المعاينة على خلفية فاتحة (المتجر والفاتورة)
                  </span>
                  <div className="p-3 bg-[#F7F1E8] rounded-lg">
                    <Logo size="lg" customLogoUrl={logoPreview} />
                  </div>
                </div>

                <div className="p-4 bg-[#2B211D] border border-black/20 rounded-xl flex flex-col items-center justify-center min-h-[140px] text-center space-y-2">
                  <span className="text-[10px] font-bold text-[#D8C19A] uppercase tracking-wider">
                    المعاينة على خلفية داكنة (شريط التنقل/الفوتر)
                  </span>
                  <div className="p-3">
                    <Logo size="lg" variant="dark" customLogoUrl={logoPreview} />
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-[#7A6A60] bg-[#E8DDD0]/40 p-2.5 rounded-xl border border-[#D8CBBE]">
                <Info className="w-4 h-4 text-[#B99A68] shrink-0" />
                <span>
                  <strong>نصيحة:</strong> يفضل استخدام صورة بخلفية شفافة (PNG أو SVG) بأبعاد 400x120 بكسل على الأقل للحصول على أفضل مظهر في الفواتير المطبوعة.
                </span>
              </div>
            </div>

            {/* Basic Store Identity */}
            <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4 text-xs">
              <h4 className="font-bold text-sm text-[#2B211D] border-b border-[#E8DDD0] pb-2">
                الهوية والاسم والوصف (SEO)
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[#2B211D] mb-1">اسم المتجر (بالعربية) *</label>
                  <input
                    type="text"
                    required
                    value={formData.storeNameAr}
                    onChange={(e) => handleChange('storeNameAr', e.target.value)}
                    className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[#2B211D] mb-1">اسم المتجر (بالإنجليزية)</label>
                  <input
                    type="text"
                    dir="ltr"
                    value={formData.storeNameEn || ''}
                    onChange={(e) => handleChange('storeNameEn', e.target.value)}
                    placeholder="Zeina Jewelry"
                    className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[#2B211D] mb-1">وصف المتجر المختصر (عربي - لمحركات البحث)</label>
                  <textarea
                    rows={2}
                    value={formData.storeDescriptionAr || ''}
                    onChange={(e) => handleChange('storeDescriptionAr', e.target.value)}
                    placeholder="وجهتكم الأولى لأرقى الإكسسوارات والمجوهرات المطلية بالذهب عيار 18k والزركون السويسري..."
                    className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none leading-relaxed"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[#2B211D] mb-1">وصف المتجر بالإنجليزي (English SEO)</label>
                  <textarea
                    rows={2}
                    dir="ltr"
                    value={formData.storeDescriptionEn || ''}
                    onChange={(e) => handleChange('storeDescriptionEn', e.target.value)}
                    placeholder="Premium luxury jewelry crafted with 18k gold plating and swiss cubic zirconia..."
                    className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none leading-relaxed"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">أيقونة المتصفح (Favicon URL)</label>
                <input
                  type="url"
                  dir="ltr"
                  value={formData.faviconUrl || ''}
                  onChange={(e) => handleChange('faviconUrl', e.target.value)}
                  placeholder="https://example.com/favicon.png"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* SUBTAB 2: CONTACT INFO                              */}
        {/* ==================================================== */}
        {activeSubTab === 'contact' && (
          <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4 text-xs animate-fadeIn">
            <h4 className="font-bold text-sm text-[#2B211D] border-b border-[#E8DDD0] pb-2 flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#B99A68]" />
              <span>بيانات الاتصال وخدمة العملاء الرسمية</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">البريد الإلكتروني العام للمتجر</label>
                <input
                  type="email"
                  dir="ltr"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  placeholder="info@zeinastore.com"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
                <span className="text-[10px] text-[#7A6A60] mt-1 block">
                  هذا البريد يظهر للعملاء في الموقع والفواتير (مستقل عن بريد المدير العام).
                </span>
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رقم الهاتف الرسمي</label>
                <input
                  type="text"
                  dir="ltr"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  placeholder="+20 100 000 0000"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رقم واتساب للتواصل المباشر</label>
                <input
                  type="text"
                  dir="ltr"
                  value={formData.whatsapp}
                  onChange={(e) => handleChange('whatsapp', e.target.value)}
                  placeholder="+20 100 000 0000"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">المدينة / المحافظة</label>
                <input
                  type="text"
                  value={formData.city || 'القاهرة'}
                  onChange={(e) => handleChange('city', e.target.value)}
                  placeholder="القاهرة"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-[#2B211D] mb-1">العنوان التفصيلي للمتجر أو المقر</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="التجمع الخامس، القاهرة الجديدة، مصر"
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
              />
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* SUBTAB 3: SOCIAL LINKS                              */}
        {/* ==================================================== */}
        {activeSubTab === 'social' && (
          <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4 text-xs animate-fadeIn">
            <h4 className="font-bold text-sm text-[#2B211D] border-b border-[#E8DDD0] pb-2 flex items-center gap-2">
              <Share2 className="w-4 h-4 text-[#B99A68]" />
              <span>روابط صفحات التواصل الاجتماعي</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رابط إنستجرام (Instagram)</label>
                <input
                  type="url"
                  dir="ltr"
                  value={formData.instagramUrl}
                  onChange={(e) => handleChange('instagramUrl', e.target.value)}
                  placeholder="https://instagram.com/zeinastore"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رابط فيسبوك (Facebook)</label>
                <input
                  type="url"
                  dir="ltr"
                  value={formData.facebookUrl}
                  onChange={(e) => handleChange('facebookUrl', e.target.value)}
                  placeholder="https://facebook.com/zeinastore"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رابط تيك توك (TikTok)</label>
                <input
                  type="url"
                  dir="ltr"
                  value={formData.tiktokUrl || ''}
                  onChange={(e) => handleChange('tiktokUrl', e.target.value)}
                  placeholder="https://tiktok.com/@zeinastore"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رابط سناب شات (Snapchat)</label>
                <input
                  type="url"
                  dir="ltr"
                  value={formData.snapchatUrl || ''}
                  onChange={(e) => handleChange('snapchatUrl', e.target.value)}
                  placeholder="https://snapchat.com/add/zeinastore"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* SUBTAB 4: PRICING & SHIPPING                        */}
        {/* ==================================================== */}
        {activeSubTab === 'pricing' && (
          <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4 text-xs animate-fadeIn">
            <h4 className="font-bold text-sm text-[#2B211D] border-b border-[#E8DDD0] pb-2 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-[#B99A68]" />
              <span>إعدادات العملة، الضرائب، ورسوم الشحن والتوصيل</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">العملة ورمزها</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={formData.currency}
                    onChange={(e) => handleChange('currency', e.target.value)}
                    placeholder="EGP"
                    className="w-1/2 bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                  />
                  <input
                    type="text"
                    value={formData.currencySymbol}
                    onChange={(e) => handleChange('currencySymbol', e.target.value)}
                    placeholder="ج.م"
                    className="w-1/2 bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">نسبة ضريبة القيمة المضافة (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.vatPercentage}
                  onChange={(e) => handleChange('vatPercentage', Number(e.target.value))}
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">تكلفة الشحن الثابتة (ج.م)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.shippingFeeFlat}
                  onChange={(e) => handleChange('shippingFeeFlat', Number(e.target.value))}
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">الحد الأدنى للشحن المجاني (ج.م)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.freeShippingThreshold}
                  onChange={(e) => handleChange('freeShippingThreshold', Number(e.target.value))}
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono font-bold"
                />
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* SUBTAB 5: PAYMENT METHODS                           */}
        {/* ==================================================== */}
        {activeSubTab === 'payments' && (
          <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4 text-xs animate-fadeIn">
            <h4 className="font-bold text-sm text-[#2B211D] border-b border-[#E8DDD0] pb-2 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#B99A68]" />
              <span>تفعيل وإلغاء وسائل الدفع في المتجر</span>
            </h4>

            <p className="text-[11px] text-[#7A6A60]">
              يمكنك تعطيل أو تفعيل أي وسيلة دفع بشكل مستقل. التغييرات ستنعكس فوراً في صفحة إنهاء الطلب (Checkout).
            </p>

            <div className="space-y-3 pt-2">
              {/* COD */}
              <div className="p-4 bg-[#F7F1E8] rounded-xl border border-[#D8CBBE] flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-[#2B211D] text-xs">الدفع عند الاستلام (Cash on Delivery)</h5>
                  <p className="text-[11px] text-[#7A6A60] mt-0.5">
                    يقوم العميل بسداد إجمالي الفاتورة نقداً للمندوب عند استلام شحنته.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.paymentMethods?.cod ?? true}
                    onChange={() => handlePaymentToggle('cod')}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Card */}
              <div className="p-4 bg-[#F7F1E8] rounded-xl border border-[#D8CBBE] flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-[#2B211D] text-xs">البطاقات البنكية (Credit / Debit Cards)</h5>
                  <p className="text-[11px] text-[#7A6A60] mt-0.5">الدفع الآمن عبر بطاقات فيزا وماستركارد وميزة.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.paymentMethods?.card ?? true}
                    onChange={() => handlePaymentToggle('card')}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* InstaPay */}
              <div className="p-4 bg-[#F7F1E8] rounded-xl border border-[#D8CBBE] flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-[#2B211D] text-xs">شبكة المدفوعات اللحظية (InstaPay)</h5>
                  <p className="text-[11px] text-[#7A6A60] mt-0.5">
                    التحويل المباشر واللحظي عبر تطبيق إنستاباي لعنوان الدفع اللحظي (IPA).
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.paymentMethods?.instapay ?? true}
                    onChange={() => handlePaymentToggle('instapay')}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Mobile Wallets */}
              <div className="p-4 bg-[#F7F1E8] rounded-xl border border-[#D8CBBE] flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-[#2B211D] text-xs">المحافظ الإلكترونية (Mobile Wallets)</h5>
                  <p className="text-[11px] text-[#7A6A60] mt-0.5">فودافون كاش، أورنج كاش، اتصالات كاش، ومحفظة وي باي.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.paymentMethods?.wallets ?? true}
                    onChange={() => handlePaymentToggle('wallets')}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* SUBTAB 6: POLICIES & LEGAL TEXTS                    */}
        {/* ==================================================== */}
        {activeSubTab === 'policies' && (
          <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4 text-xs animate-fadeIn">
            <h4 className="font-bold text-sm text-[#2B211D] border-b border-[#E8DDD0] pb-2 flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#B99A68]" />
              <span>السياسات الرسمية والنصوص المطبوعة في الفاتورة</span>
            </h4>

            <div>
              <label className="block font-bold text-[#2B211D] mb-1">
                نص سياسة الاسترجاع والاستبدال (ينعكس في أسفل كل فاتورة مبيعات وموقع المتجر) *
              </label>
              <textarea
                rows={3}
                required
                value={formData.returnPolicyAr || ''}
                onChange={(e) => handleChange('returnPolicyAr', e.target.value)}
                placeholder="يحق للعميل استبدال أو استرجاع المنتجات خلال 14 يوماً من تاريخ الاستلام بشرط أن تكون بحالتها الأصلية غير مستخدمة ومرفقة بكافة الملحقات والفاتورة الرسمية..."
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none leading-relaxed"
              />
              <span className="text-[10px] text-[#7A6A60] mt-1 block">
                تعديل هذا الحقل يضمن تحديث النص تلقائياً في فواتير PDF وتذييل صفحات المتجر.
              </span>
            </div>

            <div>
              <label className="block font-bold text-[#2B211D] mb-1">سياسة الخصوصية وحماية البيانات</label>
              <textarea
                rows={3}
                value={formData.privacyPolicyAr || ''}
                onChange={(e) => handleChange('privacyPolicyAr', e.target.value)}
                placeholder="نحن في متجر زينة ملتزمون بحماية خصوصيتكم وسرية بياناتكم الشخصية، ولا تتم مشاركة معلوماتكم مع أي طرف ثالث..."
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none leading-relaxed"
              />
            </div>

            <div>
              <label className="block font-bold text-[#2B211D] mb-1">شروط الاستخدام والخدمة</label>
              <textarea
                rows={3}
                value={formData.termsOfServiceAr || ''}
                onChange={(e) => handleChange('termsOfServiceAr', e.target.value)}
                placeholder="تخضع جميع عمليات الشراء عبر متجر زينة للأحكام والشروط والقوانين المعمول بها في جمهورية مصر العربية..."
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none leading-relaxed"
              />
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* SUBTAB 7: INVOICE DETAILS                           */}
        {/* ==================================================== */}
        {activeSubTab === 'invoice' && (
          <div className="bg-white/80 p-5 rounded-2xl border border-[#D8CBBE] space-y-4 text-xs animate-fadeIn">
            <h4 className="font-bold text-sm text-[#2B211D] border-b border-[#E8DDD0] pb-2 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#B99A68]" />
              <span>بيانات التسجيل التجاري والضريبي المعتمدة للفواتير</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رقم السجل التجاري (Commercial Record) *</label>
                <input
                  type="text"
                  required
                  value={formData.commercialRecord}
                  onChange={(e) => handleChange('commercialRecord', e.target.value)}
                  placeholder="10293847"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">الرقم الضريبي (Tax Identification Number) *</label>
                <input
                  type="text"
                  required
                  value={formData.taxNumber}
                  onChange={(e) => handleChange('taxNumber', e.target.value)}
                  placeholder="987-654-321"
                  className="w-full bg-[#F7F1E8] border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono font-bold"
                />
              </div>
            </div>
          </div>
        )}

        {/* Bottom Save Bar */}
        <div className="flex justify-end gap-3 pt-4 border-t border-[#D8CBBE]">
          <button
            type="submit"
            disabled={isSaving}
            className="px-8 py-3 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'جاري الحفظ إلى قاعدة البيانات...' : 'حفظ التعديلات في قاعدة البيانات'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

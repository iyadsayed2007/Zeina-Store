import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { User } from '../types';
import { fetchUsersApi, createStaffApi, updateUserApi, deleteUserApi } from '../services/api';
import {
  Users,
  UserPlus,
  Shield,
  Trash2,
  Lock,
  Phone,
  Mail,
  CheckCircle2,
  XCircle,
  KeyRound,
  RefreshCw,
  AlertTriangle,
} from 'lucide-react';

export const AdminStaffManager: React.FC = () => {
  const { showToast, currentUser } = useStore();
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Add Staff Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newRole, setNewRole] = useState<'staff' | 'admin'>('staff');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Change Password Modal State
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [modalNewPassword, setModalNewPassword] = useState('');
  const [isChangingPass, setIsChangingPass] = useState(false);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const data = await fetchUsersApi();
      setUsers(data);
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!newName.trim() || !newEmail.trim() || !newPassword.trim()) {
      setFormError('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    if (newPassword.length < 6) {
      setFormError('كلمة المرور يجب ألا تقل عن 6 خانات');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await createStaffApi({
        name: newName.trim(),
        email: newEmail.trim().toLowerCase(),
        password: newPassword.trim(),
        role: newRole,
        phone: newPhone.trim(),
      });

      if (res.success && res.user) {
        showToast(`تمت إضافة ${res.user.name} كـ ${res.user.role === 'admin' ? 'مدير' : 'موظف'} بنجاح ✨`);
        setIsAddModalOpen(false);
        setNewName('');
        setNewEmail('');
        setNewPassword('');
        setNewPhone('');
        loadUsers();
      } else {
        setFormError(res.error || 'فشلت إضافة الموظف');
      }
    } catch (err) {
      setFormError('حدث خطأ أثناء الاتصال بالخادم');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (user: User) => {
    if (user.role === 'admin') {
      alert('لا يمكن تعطيل حساب المدير العام الرئيسي.');
      return;
    }

    const nextStatus = user.status === 'inactive' ? 'active' : 'inactive';
    const confirmText =
      nextStatus === 'inactive'
        ? `هل أنت متأكد من تعطيل حساب "${user.name}"؟ لن يتمكن من تسجيل الدخول.`
        : `هل أنت متأكد من إعادة تفعيل حساب "${user.name}"؟`;

    if (!confirm(confirmText)) return;

    const res = await updateUserApi(user.id, { status: nextStatus });
    if (res.success) {
      showToast(nextStatus === 'active' ? 'تم تفعيل الحساب' : 'تم تعطيل الحساب');
      loadUsers();
    } else {
      alert(res.error || 'فشل تحديث حالة الحساب');
    }
  };

  const handleDelete = async (user: User) => {
    if (user.role === 'admin') {
      alert('لا يمكن حذف حساب المدير العام الرئيسي.');
      return;
    }

    if (!confirm(`هل أنت متأكد من حذف الموظف "${user.name}" نهائياً من النظام؟`)) {
      return;
    }

    const res = await deleteUserApi(user.id);
    if (res.success) {
      showToast('تم حذف الموظف من النظام بنجاح');
      loadUsers();
    } else {
      alert(res.error || 'فشل حذف الموظف');
    }
  };

  const handleChangeStaffPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser || !modalNewPassword.trim()) return;

    if (modalNewPassword.length < 6) {
      alert('كلمة المرور يجب ألا تقل عن 6 خانات');
      return;
    }

    setIsChangingPass(true);
    try {
      const res = await updateUserApi(editingUser.id, { newPassword: modalNewPassword.trim() });
      if (res.success) {
        showToast('تم تحديث كلمة المرور للموظف بنجاح');
        setEditingUser(null);
        setModalNewPassword('');
      } else {
        alert(res.error || 'فشل تحديث كلمة المرور');
      }
    } catch {
      alert('حدث خطأ أثناء تحديث كلمة المرور');
    } finally {
      setIsChangingPass(false);
    }
  };

  const staffAndAdmins = users.filter((u) => u.role === 'admin' || u.role === 'staff');

  return (
    <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#D8CBBE] pb-4">
        <div>
          <h3 className="font-bold text-base font-serif text-[#2B211D] flex items-center gap-2">
            <Users className="w-5 h-5 text-[#B99A68]" />
            <span>إدارة فريق العمل والموظفين الإداريين (Staff Management)</span>
          </h3>
          <p className="text-xs text-[#7A6A60] mt-1">
            إضافة وتعيين موظفين لمتابعة الطلبات والمخزون، وتحديد الصلاحيات وإدارة الحسابات.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={loadUsers}
            disabled={isLoading}
            className="p-2.5 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-xl text-xs font-bold transition border border-[#D8CBBE]"
            title="تحديث القائمة"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2.5 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm"
          >
            <UserPlus className="w-4 h-4" />
            <span>إضافة موظف جديد</span>
          </button>
        </div>
      </div>

      {/* Staff Table */}
      <div className="bg-white/80 rounded-2xl border border-[#D8CBBE] overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right">
            <thead className="bg-[#E8DDD0]/60 text-[#7A6A60] border-b border-[#D8CBBE]">
              <tr>
                <th className="p-4 font-semibold">الموظف</th>
                <th className="p-4 font-semibold">البريد الإلكتروني</th>
                <th className="p-4 font-semibold">رقم الهاتف</th>
                <th className="p-4 font-semibold">الرتبة والصلاحية</th>
                <th className="p-4 font-semibold text-center">حالة الحساب</th>
                <th className="p-4 font-semibold text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D8CBBE]/50">
              {staffAndAdmins.map((u) => {
                const isMainAdmin = u.role === 'admin' && u.email === 'iyadsayed@gmail.com';
                const isCurrent = currentUser?.id === u.id;

                return (
                  <tr key={u.id} className="hover:bg-[#E8DDD0]/30 transition">
                    <td className="p-4">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                            u.role === 'admin' ? 'bg-[#2B211D] text-[#D8C19A]' : 'bg-[#E8DDD0] text-[#2B211D]'
                          }`}
                        >
                          {u.name.slice(0, 1)}
                        </div>
                        <div>
                          <p className="font-bold text-[#2B211D]">{u.name}</p>
                          {isCurrent && <span className="text-[10px] text-[#B99A68] font-semibold">(أنت)</span>}
                        </div>
                      </div>
                    </td>

                    <td className="p-4 font-mono text-[#7A6A60]" dir="ltr">
                      {u.email}
                    </td>

                    <td className="p-4 font-mono text-[#7A6A60]" dir="ltr">
                      {u.phone || '—'}
                    </td>

                    <td className="p-4">
                      {u.role === 'admin' ? (
                        <span className="inline-flex items-center gap-1 bg-[#2B211D] text-[#D8C19A] px-2.5 py-1 rounded-md text-[10px] font-bold">
                          <Shield className="w-3 h-3" />
                          <span>مدير عام (Admin)</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 px-2.5 py-1 rounded-md text-[10px] font-bold">
                          <span>موظف إداري (Staff)</span>
                        </span>
                      )}
                    </td>

                    <td className="p-4 text-center">
                      <button
                        type="button"
                        disabled={isMainAdmin}
                        onClick={() => handleToggleStatus(u)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[10px] font-bold transition ${
                          u.status === 'inactive'
                            ? 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                            : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                        } ${isMainAdmin ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'}`}
                        title={isMainAdmin ? 'لا يمكن تعطيل حساب المدير الرئيسي' : 'انقر لتغيير الحالة'}
                      >
                        {u.status === 'inactive' ? (
                          <>
                            <XCircle className="w-3 h-3 text-rose-600" />
                            <span>معطل (Inactive)</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>نشط (Active)</span>
                          </>
                        )}
                      </button>
                    </td>

                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingUser(u);
                            setModalNewPassword('');
                          }}
                          className="p-1.5 text-[#2B211D] hover:bg-[#E8DDD0] rounded-lg transition"
                          title="تعيين كلمة مرور جديدة للموظف"
                        >
                          <KeyRound className="w-4 h-4 text-[#B99A68]" />
                        </button>

                        {!isMainAdmin && (
                          <button
                            type="button"
                            onClick={() => handleDelete(u)}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                            title="حذف الموظف نهائياً"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: ADD NEW STAFF */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 text-right">
          <div className="bg-[#F7F1E8] rounded-3xl w-full max-w-md border border-[#D8CBBE] shadow-2xl p-6 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-[#D8CBBE] pb-3">
              <h3 className="font-bold text-base font-serif text-[#2B211D] flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#B99A68]" />
                <span>إضافة موظف إداري جديد</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="text-[#7A6A60] hover:text-[#2B211D]"
              >
                ✕
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-50 text-rose-800 border border-rose-200 rounded-xl text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleAddStaff} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">اسم الموظف *</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="مثال: أحمد محمد"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">البريد الإلكتروني للدخول *</label>
                <input
                  type="email"
                  required
                  dir="ltr"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="ahmed@zeinastore.com"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">كلمة المرور الابتدائية * (6 خانات على الأقل)</label>
                <input
                  type="password"
                  required
                  dir="ltr"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">رقم الهاتف</label>
                <input
                  type="text"
                  dir="ltr"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="+20 100 000 0000"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-[#2B211D] mb-1">الصلاحية والرتبة</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as any)}
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-bold"
                >
                  <option value="staff">موظف إداري (Staff) - متابعة الطلبات والمنتجات</option>
                  <option value="admin">مدير عام (Admin) - صلاحيات كاملة بالنظام</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#D8CBBE]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-transparent text-[#7A6A60] rounded-xl hover:bg-[#E8DDD0]"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl font-bold transition flex items-center gap-1.5 shadow-sm disabled:opacity-50"
                >
                  {isSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <UserPlus className="w-3.5 h-3.5" />}
                  <span>حفظ وإضافة الموظف</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: RESET STAFF PASSWORD */}
      {editingUser && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 text-right">
          <div className="bg-[#F7F1E8] rounded-3xl w-full max-w-sm border border-[#D8CBBE] shadow-2xl p-6 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-[#D8CBBE] pb-3">
              <h3 className="font-bold text-base font-serif text-[#2B211D] flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-[#B99A68]" />
                <span>تغيير كلمة مرور الموظف</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="text-[#7A6A60] hover:text-[#2B211D]"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-[#7A6A60]">
              تعيين كلمة مرور جديدة للموظف: <strong>{editingUser.name}</strong> ({editingUser.email})
            </p>

            <form onSubmit={handleChangeStaffPassword} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-[#2B211D] mb-1">كلمة المرور الجديدة *</label>
                <input
                  type="password"
                  required
                  dir="ltr"
                  placeholder="••••••••"
                  value={modalNewPassword}
                  onChange={(e) => setModalNewPassword(e.target.value)}
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] focus:border-[#B99A68] rounded-xl px-3 py-2 text-[#2B211D] outline-none font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#D8CBBE]">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 bg-transparent text-[#7A6A60] rounded-xl hover:bg-[#E8DDD0]"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isChangingPass}
                  className="px-6 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl font-bold transition flex items-center gap-1.5 shadow-sm disabled:opacity-50"
                >
                  {isChangingPass ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
                  <span>حفظ كلمة المرور</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

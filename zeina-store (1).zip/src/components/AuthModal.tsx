import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Logo } from './Logo';
import { X, Lock, Mail, User as UserIcon, Phone, MapPin, CheckCircle2, Shield } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { login, register } = useStore();
  const [isRegister, setIsRegister] = useState(false);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('القاهرة');

  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    if (isRegister) {
      if (!name || !email || !password) {
        setErrorMsg('يرجى ملء جميع الحقول الإلزامية');
        setLoading(false);
        return;
      }
      const res = register({ name, email, password, phone, address, city });
      if (res.success) {
        onClose();
      } else {
        setErrorMsg(res.error || 'حدث خطأ أثناء إنشاء الحساب');
      }
    } else {
      if (!email || !password) {
        setErrorMsg('يرجى إدخال البريد الإلكتروني وكلمة المرور');
        setLoading(false);
        return;
      }
      const res = await login(email, password);
      if (res.success) {
        onClose();
      } else {
        setErrorMsg(res.error || 'بيانات الدخول غير صحيحة');
      }
    }
    setLoading(false);
  };

  const handleQuickLogin = async (demoEmail: string, demoPass: string) => {
    setErrorMsg('');
    const res = await login(demoEmail, demoPass);
    if (res.success) {
      onClose();
    } else {
      setErrorMsg(res.error || 'خطأ في تسجيل الدخول');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#F7F1E8] rounded-3xl w-full max-w-md shadow-2xl border border-[#D8CBBE] overflow-hidden">
        {/* Modal Header */}
        <div className="bg-[#2B211D] text-[#F7F1E8] p-6 text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 text-stone-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex justify-center mb-2">
            <Logo variant="dark" size="md" />
          </div>
          <h2 className="font-bold text-lg font-serif">
            {isRegister ? 'إنشاء حساب جديد في متجر زينة' : 'تسجيل الدخول إلى حسابك'}
          </h2>
          <p className="text-xs text-[#D8C19A] mt-1">
            {isRegister ? 'انضمي لعالم المجوهرات الراقية واستمتعي بخصومات حصرية' : 'مرحباً بعودتك! تابعي طلباتك وفواتيرك بكل سهولة'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-[#D8CBBE] bg-[#E8DDD0]">
          <button
            onClick={() => {
              setIsRegister(false);
              setErrorMsg('');
            }}
            className={`flex-1 py-3 text-xs font-bold transition-all ${
              !isRegister
                ? 'bg-[#F7F1E8] text-[#2B211D] border-t-2 border-[#B99A68]'
                : 'text-[#7A6A60] hover:text-[#2B211D]'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            onClick={() => {
              setIsRegister(true);
              setErrorMsg('');
            }}
            className={`flex-1 py-3 text-xs font-bold transition-all ${
              isRegister
                ? 'bg-[#F7F1E8] text-[#2B211D] border-t-2 border-[#B99A68]'
                : 'text-[#7A6A60] hover:text-[#2B211D]'
            }`}
          >
            إنشاء حساب جديد
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-right">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
              {errorMsg}
            </div>
          )}

          {isRegister && (
            <div>
              <label className="block text-xs font-bold text-[#2B211D] mb-1">الاسم بالكامل *</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: ياسمين أحمد"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2.5 pl-9 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
                <UserIcon className="w-4 h-4 text-[#7A6A60] absolute left-3 top-3" />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#2B211D] mb-1">البريد الإلكتروني *</label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2.5 pl-9 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
              />
              <Mail className="w-4 h-4 text-[#7A6A60] absolute left-3 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#2B211D] mb-1">كلمة المرور *</label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2.5 pl-9 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
              />
              <Lock className="w-4 h-4 text-[#7A6A60] absolute left-3 top-3" />
            </div>
          </div>

          {isRegister && (
            <>
              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">رقم الهاتف للتوصيل</label>
                <div className="relative">
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+201012345678"
                    className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2.5 pl-9 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                  />
                  <Phone className="w-4 h-4 text-[#7A6A60] absolute left-3 top-3" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#2B211D] mb-1">المدينة</label>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                  >
                    <option value="القاهرة">القاهرة</option>
                    <option value="الجيزة">الجيزة</option>
                    <option value="الإسكندرية">الإسكندرية</option>
                    <option value="المنصورة">المنصورة</option>
                    <option value="طنطا">طنطا</option>
                    <option value="شرم الشيخ">شرم الشيخ</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#2B211D] mb-1">العنوان بالتفصيل</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="الشارع، رقم العمارة"
                    className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                  />
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 mt-4"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isRegister ? 'تأكيد التسجيل' : 'تسجيل الدخول'}</span>
          </button>
        </form>

        {/* Fast Customer Demo Login */}
        <div className="p-4 bg-[#E8DDD0]/60 border-t border-[#D8CBBE]">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[#7A6A60]">حساب عميل للتجربة السريعة:</span>
            <button
              type="button"
              onClick={() => handleQuickLogin('nouran@example.com', 'user123')}
              className="px-3 py-1 bg-[#B99A68] hover:bg-[#A88856] text-white rounded-lg text-xs font-bold transition shadow-xs"
            >
              دخول كعميل تجريبي
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

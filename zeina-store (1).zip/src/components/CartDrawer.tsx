import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { X, Trash2, Plus, Minus, ArrowLeft, Tag, ShoppingBag, ShieldCheck } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose }) => {
  const {
    cart,
    removeFromCart,
    updateCartQuantity,
    cartTotal,
    appliedCoupon,
    discountAmount,
    applyCouponCode,
    removeCoupon,
    settings,
    setCurrentView,
  } = useStore();

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');

  if (!isOpen) return null;

  const freeShippingLeft = Math.max(0, settings.freeShippingThreshold - cartTotal);
  const shippingFee = cartTotal >= settings.freeShippingThreshold ? 0 : settings.shippingFeeFlat;
  const grandTotal = Math.max(0, cartTotal - discountAmount + shippingFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    if (!couponInput.trim()) return;

    const res = applyCouponCode(couponInput);
    if (!res.success) {
      setCouponError(res.message);
    } else {
      setCouponInput('');
    }
  };

  const handleProceedToCheckout = () => {
    onClose();
    setCurrentView('checkout');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 left-0 max-w-full flex pl-0 sm:pl-10">
        <div className="w-screen max-w-md bg-[#F7F1E8] border-r border-[#D8CBBE] shadow-2xl flex flex-col">
          {/* Drawer Header */}
          <div className="p-6 bg-[#2B211D] text-[#F7F1E8] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShoppingBag className="w-5 h-5 text-[#B99A68]" />
              <h2 className="font-bold text-lg font-serif">حقيبة التسوق الفاخرة</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-300 hover:text-white rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Indicator */}
          <div className="bg-[#E8DDD0] px-6 py-3 border-b border-[#D8CBBE]">
            {freeShippingLeft > 0 ? (
              <div>
                <p className="text-xs text-[#2B211D] font-medium mb-1.5">
                  أضيفي بقيمة <span className="font-bold text-[#B76E79]">{freeShippingLeft} ج.م</span> للحصول على شحن مجاني!
                </p>
                <div className="w-full bg-[#D8CBBE] h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-[#B99A68] h-full transition-all duration-500 rounded-full"
                    style={{ width: `${Math.min(100, (cartTotal / settings.freeShippingThreshold) * 100)}%` }}
                  />
                </div>
              </div>
            ) : (
              <p className="text-xs text-emerald-800 font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>تهانينا! طلبيتك مؤهلة للشحن المجاني الفاخر ✨</span>
              </p>
            )}
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-full bg-[#E8DDD0] mx-auto flex items-center justify-center text-[#7A6A60] mb-4">
                  <ShoppingBag className="w-8 h-8 text-[#B99A68]" />
                </div>
                <h3 className="font-bold text-base text-[#2B211D]">حقيبة التسوق فارغة</h3>
                <p className="text-xs text-[#7A6A60] mt-1 max-w-xs mx-auto">
                  تصفحي تشكيلة مجوهرات وإكسسوارات زينة الفاخرة واختاري ما يليق بأنوثتك.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    setCurrentView('shop');
                  }}
                  className="mt-6 px-6 py-2.5 bg-[#2B211D] text-[#F7F1E8] rounded-full text-xs font-bold hover:bg-[#B99A68] transition"
                >
                  استكشاف التشكيلة
                </button>
              </div>
            ) : (
              cart.map((item, index) => (
                <div
                  key={`${item.product.id}-${item.selectedColor || ''}-${index}`}
                  className="flex gap-4 p-3.5 bg-white/70 rounded-2xl border border-[#D8CBBE] shadow-xs items-center"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.nameAr}
                    className="w-18 h-18 rounded-xl object-cover border border-[#D8CBBE]/60 shrink-0"
                  />

                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-xs text-[#2B211D] truncate">
                      {item.product.nameAr}
                    </h4>
                    {item.selectedColor && (
                      <span className="text-[10px] text-[#B76E79] block">
                        اللون: {item.selectedColor}
                      </span>
                    )}
                    <span className="font-mono font-bold text-xs text-[#2B211D] block mt-1">
                      {(item.product.price ?? 0).toLocaleString()} ج.م
                    </span>

                    {/* Quantity Stepper */}
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center border border-[#D8CBBE] rounded-lg bg-[#F7F1E8]">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1, item.selectedColor)}
                          className="p-1 text-[#2B211D] hover:bg-[#E8DDD0] rounded-r-lg"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2.5 text-xs font-bold font-mono">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1, item.selectedColor)}
                          className="p-1 text-[#2B211D] hover:bg-[#E8DDD0] rounded-l-lg"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => removeFromCart(item.product.id, item.selectedColor)}
                        className="text-stone-400 hover:text-rose-600 transition p-1"
                        title="حذف"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Calculations & Coupon */}
          {cart.length > 0 && (
            <div className="p-6 bg-[#E8DDD0]/50 border-t border-[#D8CBBE] space-y-4">
              {/* Coupon Form */}
              <div>
                {appliedCoupon ? (
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl text-xs">
                    <div className="flex items-center gap-2 text-emerald-800">
                      <Tag className="w-4 h-4 text-emerald-600" />
                      <span>تم تفعيل كود: <strong>{appliedCoupon.code}</strong> (-{discountAmount} ج.م)</span>
                    </div>
                    <button
                      onClick={removeCoupon}
                      className="text-stone-400 hover:text-rose-600 text-xs font-bold"
                    >
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="كود الخصم (مثال: ZEINA10)"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      className="flex-1 bg-[#F7F1E8] border border-[#D8CBBE] rounded-xl px-3 py-2 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68] uppercase font-mono"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-[#2B211D] text-white text-xs font-bold rounded-xl hover:bg-[#B99A68] transition"
                    >
                      تطبيق
                    </button>
                  </form>
                )}
                {couponError && <p className="text-[11px] text-rose-600 mt-1">{couponError}</p>}
              </div>

              {/* Price Details */}
              <div className="space-y-1.5 text-xs text-[#7A6A60]">
                <div className="flex justify-between">
                  <span>المجموع الفرعي:</span>
                  <span className="font-bold text-[#2B211D]">{(cartTotal || 0).toLocaleString()} ج.م</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-[#B76E79] font-medium">
                    <span>الخصم المطبق:</span>
                    <span>-{(discountAmount || 0).toLocaleString()} ج.م</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>الشحن والتوصيل:</span>
                  <span>{shippingFee === 0 ? 'مجاناً' : `${shippingFee} ج.م`}</span>
                </div>
                <div className="border-t border-[#D8CBBE] pt-2 flex justify-between text-base font-bold text-[#2B211D]">
                  <span className="text-[#B99A68]">الإجمالي النهائي:</span>
                  <span className="text-lg text-[#B99A68] font-mono">{(grandTotal || 0).toLocaleString()} ج.م</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={handleProceedToCheckout}
                className="w-full py-3.5 bg-[#2B211D] hover:bg-[#B99A68] text-[#F7F1E8] rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 group"
              >
                <span>متابعة إتمام الطلب</span>
                <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

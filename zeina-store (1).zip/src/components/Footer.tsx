import React from 'react';
import { Logo } from './Logo';
import { useStore } from '../context/StoreContext';
import { Phone, Mail, MapPin, Instagram, Facebook, ShieldCheck, RefreshCw, Award, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const { settings, categories, setSelectedCategorySlug, setCurrentView } = useStore();

  return (
    <footer className="bg-[#2B211D] text-[#F7F1E8] border-t-2 border-[#B99A68] pt-16 pb-8">
      {/* Value Badges Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-stone-700/60">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center md:text-right">
          <div className="flex items-center gap-4 bg-[#382B26]/60 p-4 rounded-2xl border border-stone-700/40">
            <div className="w-12 h-12 rounded-xl bg-[#B99A68]/20 flex items-center justify-center shrink-0">
              <Award className="w-6 h-6 text-[#B99A68]" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#F7F1E8]">جودة وضمان ذهبي</h4>
              <p className="text-xs text-[#D8C19A]/80 mt-0.5">مطلي بماء الذهب وحجر زركون 5A</p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-[#382B26]/60 p-4 rounded-2xl border border-stone-700/40">
            <div className="w-12 h-12 rounded-xl bg-[#B76E79]/20 flex items-center justify-center shrink-0">
              <RefreshCw className="w-6 h-6 text-[#B76E79]" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#F7F1E8]">استبدال سهل وسريع</h4>
              <p className="text-xs text-[#D8C19A]/80 mt-0.5">حق الاستبدال خلال 14 يوماً</p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-[#382B26]/60 p-4 rounded-2xl border border-stone-700/40">
            <div className="w-12 h-12 rounded-xl bg-[#B99A68]/20 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6 text-[#B99A68]" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#F7F1E8]">دفع آمن ومتعدد</h4>
              <p className="text-xs text-[#D8C19A]/80 mt-0.5">إنستاباي، فيزا، والدفع عند الاستلام</p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-[#382B26]/60 p-4 rounded-2xl border border-stone-700/40">
            <div className="w-12 h-12 rounded-xl bg-[#B76E79]/20 flex items-center justify-center shrink-0">
              <Heart className="w-6 h-6 text-[#B76E79]" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#F7F1E8]">تغليف هدايا فاخر</h4>
              <p className="text-xs text-[#D8C19A]/80 mt-0.5">علب مخملية وأكياس هدايا راقية</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Bio */}
          <div className="lg:col-span-2 space-y-4">
            <Logo variant="dark" size="lg" />
            <p className="text-xs text-stone-300 leading-relaxed max-w-md">
              علامة تجارية رائدة للإكسسوارات والمجوهرات النسائية الفاخرة، تقدم تصاميم أنثوية كلاسيكية وعصرية تبرز جمالك وتمنحك حضوراً مبهراً في كل مناسبة.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href={settings.instagramUrl}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-stone-800 hover:bg-[#B99A68] text-stone-300 hover:text-white flex items-center justify-center transition"
                title="إنستغرام"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={settings.facebookUrl}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-stone-800 hover:bg-[#B99A68] text-stone-300 hover:text-white flex items-center justify-center transition"
                title="فيسبوك"
              >
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#B99A68]">مجموعات المجوهرات</h4>
            <ul className="space-y-2 text-xs text-stone-300">
              {categories.slice(0, 5).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => {
                      setSelectedCategorySlug(cat.slug);
                      setCurrentView('shop');
                    }}
                    className="hover:text-[#D8C19A] transition"
                  >
                    {cat.nameAr}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#B99A68]">روابط سريعة</h4>
            <ul className="space-y-2 text-xs text-stone-300">
              <li>
                <button onClick={() => setCurrentView('shop')} className="hover:text-[#D8C19A] transition">
                  جميع المنتجات
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('about')} className="hover:text-[#D8C19A] transition">
                  قصة زينة ستور
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('contact')} className="hover:text-[#D8C19A] transition">
                  تواصل معنا
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('account')} className="hover:text-[#D8C19A] transition">
                  تتبع الطلبات السابقة
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#B99A68]">خدمة العملاء</h4>
            <ul className="space-y-2.5 text-xs text-stone-300">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#B99A68] shrink-0" />
                <span>{settings.phone}</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#B99A68] shrink-0" />
                <span>{settings.email}</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#B99A68] shrink-0 mt-0.5" />
                <span>{settings.address}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Legal & Payment Brands Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-4 border-t border-stone-800 text-xs text-stone-400 flex flex-col md:flex-row items-center justify-between gap-4">
        <p>
          © {new Date().getFullYear()} Zeina Store. جميع الحقوق محفوظة. س.ت: {settings.commercialRecord} — ب.ض: {settings.taxNumber}
        </p>

        {/* Payment logos badges */}
        <div className="flex items-center gap-2 text-[11px] text-stone-400">
          <span className="bg-stone-800 px-2 py-1 rounded text-stone-300 font-mono">VISA</span>
          <span className="bg-stone-800 px-2 py-1 rounded text-stone-300 font-mono">MasterCard</span>
          <span className="bg-stone-800 px-2 py-1 rounded text-stone-300 font-mono">Meeza</span>
          <span className="bg-stone-800 px-2 py-1 rounded text-[#D8C19A] font-medium">InstaPay</span>
          <span className="bg-stone-800 px-2 py-1 rounded text-[#B76E79] font-medium">Vodafone Cash</span>
        </div>
      </div>
    </footer>
  );
};

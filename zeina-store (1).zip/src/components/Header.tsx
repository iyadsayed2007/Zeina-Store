import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Logo } from './Logo';
import {
  ShoppingBag,
  User as UserIcon,
  Search,
  Menu,
  X,
  Heart,
  ChevronDown,
  LogOut,
  Sparkles,
} from 'lucide-react';

interface HeaderProps {
  onOpenAuth: () => void;
  onOpenCart: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAuth, onOpenCart }) => {
  const {
    currentView,
    setCurrentView,
    cartItemCount,
    currentUser,
    logout,
    categories,
    setSelectedCategorySlug,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleCategoryClick = (slug: string) => {
    setSelectedCategorySlug(slug);
    setCurrentView('shop');
    setMobileMenuOpen(false);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setCurrentView('shop');
      setSearchOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#F7F1E8]/95 backdrop-blur-md border-b border-[#D8CBBE] transition-all">
      {/* Top Announcement Bar */}
      <div className="bg-[#2B211D] text-[#F7F1E8] px-4 py-2 text-xs text-center flex items-center justify-center gap-3">
        <span className="flex items-center gap-1.5 text-[#D8C19A] font-medium">
          <Sparkles className="w-3.5 h-3.5 text-[#B99A68]" />
          <span>مجموعة خريف 2026 الحصرية متوفرة الآن — شحن مجاني للطلبات فوق 1,500 ج.م</span>
        </span>
        <span className="hidden md:inline-block text-[#7A6A60]">|</span>
        <span className="hidden md:inline-block text-stone-300">
          كود خصم 10%: <strong className="text-[#B76E79] font-mono tracking-wider">ZEINA10</strong>
        </span>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Mobile menu trigger */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#2B211D] hover:bg-[#E8DDD0] rounded-xl transition"
              aria-label="القائمة"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Brand Logo with exact user uploaded identity */}
          <div className="flex items-center cursor-pointer" onClick={() => setCurrentView('home')}>
            <Logo size="md" />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-[#2B211D]">
            <button
              onClick={() => {
                setSelectedCategorySlug(null);
                setCurrentView('home');
              }}
              className={`hover:text-[#B99A68] transition-colors py-1 ${
                currentView === 'home' ? 'text-[#B99A68] font-bold border-b-2 border-[#B99A68]' : ''
              }`}
            >
              الرئيسية
            </button>

            <button
              onClick={() => {
                setSelectedCategorySlug(null);
                setCurrentView('shop');
              }}
              className={`hover:text-[#B99A68] transition-colors py-1 ${
                currentView === 'shop' && !currentView.startsWith('admin')
                  ? 'text-[#B99A68] font-bold border-b-2 border-[#B99A68]'
                  : ''
              }`}
            >
              تشكيلة المجوهرات
            </button>

            {/* Categories dropdown */}
            <div className="relative group">
              <button className="flex items-center gap-1 hover:text-[#B99A68] transition-colors py-1">
                <span>الفئات</span>
                <ChevronDown className="w-4 h-4 transition-transform group-hover:rotate-180" />
              </button>

              <div className="absolute top-full right-0 w-64 pt-2 hidden group-hover:block transition-all animate-fadeIn">
                <div className="bg-[#F7F1E8] border border-[#D8CBBE] rounded-2xl shadow-xl p-2 space-y-1">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleCategoryClick(cat.slug)}
                      className="w-full text-right px-3 py-2 text-xs font-medium text-[#2B211D] hover:bg-[#E8DDD0] rounded-xl transition flex items-center justify-between"
                    >
                      <span>{cat.nameAr}</span>
                      <span className="text-[10px] text-[#7A6A60] bg-[#E8DDD0] px-2 py-0.5 rounded-full">
                        {cat.itemCount}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={() => setCurrentView('about')}
              className={`hover:text-[#B99A68] transition-colors py-1 ${
                currentView === 'about' ? 'text-[#B99A68] font-bold border-b-2 border-[#B99A68]' : ''
              }`}
            >
              قصة زينة
            </button>

            <button
              onClick={() => setCurrentView('contact')}
              className={`hover:text-[#B99A68] transition-colors py-1 ${
                currentView === 'contact' ? 'text-[#B99A68] font-bold border-b-2 border-[#B99A68]' : ''
              }`}
            >
              تواصل معنا
            </button>
          </nav>

          {/* Action Icons */}
          <div className="flex items-center gap-3">
            {/* Search Button */}
            <div className="relative">
              {searchOpen ? (
                <form onSubmit={handleSearchSubmit} className="flex items-center">
                  <input
                    type="text"
                    placeholder="ابحثي عن سوار، عقد، خاتم..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    autoFocus
                    className="bg-[#E8DDD0] border border-[#D8CBBE] rounded-full px-4 py-1.5 text-xs text-[#2B211D] placeholder-[#7A6A60] focus:outline-none focus:ring-1 focus:ring-[#B99A68] w-44 sm:w-60"
                  />
                  <button
                    type="button"
                    onClick={() => setSearchOpen(false)}
                    className="p-1 mr-1 text-[#7A6A60] hover:text-[#2B211D]"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <button
                  onClick={() => setSearchOpen(true)}
                  className="p-2.5 text-[#2B211D] hover:bg-[#E8DDD0] rounded-full transition"
                  title="بحث"
                >
                  <Search className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* User Account / Profile */}
            <div className="relative">
              {currentUser ? (
                <div className="relative">
                  <button
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className="flex items-center gap-2 p-1.5 hover:bg-[#E8DDD0] rounded-full transition"
                  >
                    <div className="w-8 h-8 rounded-full bg-[#B99A68] text-white flex items-center justify-center font-bold text-xs">
                      {currentUser.name.charAt(0)}
                    </div>
                  </button>

                  {userDropdownOpen && (
                    <div className="absolute left-0 mt-2 w-56 bg-[#F7F1E8] border border-[#D8CBBE] rounded-2xl shadow-xl py-2 z-50 animate-fadeIn">
                      <div className="px-4 py-2 border-b border-[#D8CBBE]">
                        <p className="font-bold text-sm text-[#2B211D] truncate">{currentUser.name}</p>
                        <p className="text-xs text-[#7A6A60] truncate">{currentUser.email}</p>
                        <span className="inline-block mt-1 text-[10px] uppercase font-bold bg-[#E8DDD0] text-[#B99A68] px-2 py-0.5 rounded-md">
                          {currentUser.role === 'admin' ? 'مدير النظام' : currentUser.role === 'staff' ? 'موظف مبيعات' : 'عميل مميز'}
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          setCurrentView('account');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-right px-4 py-2 text-xs text-[#2B211D] hover:bg-[#E8DDD0] transition flex items-center gap-2"
                      >
                        <UserIcon className="w-4 h-4 text-[#B99A68]" />
                        <span>حسابي وطلباتي السابقة</span>
                      </button>

                      <div className="border-t border-[#D8CBBE] mt-1">
                        <button
                          onClick={() => {
                            logout();
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-right px-4 py-2 text-xs text-rose-700 hover:bg-rose-50 transition flex items-center gap-2"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>تسجيل الخروج</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={onOpenAuth}
                  className="p-2.5 text-[#2B211D] hover:bg-[#E8DDD0] rounded-full transition"
                  title="تسجيل الدخول"
                >
                  <UserIcon className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative p-2.5 bg-[#2B211D] text-[#F7F1E8] hover:bg-[#3B2D27] rounded-full transition shadow-sm group"
              title="حقيبة التسوق"
            >
              <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#B76E79] text-white text-[11px] font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-md animate-bounce">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#F7F1E8] border-b border-[#D8CBBE] px-4 pt-2 pb-6 space-y-3">
          <button
            onClick={() => {
              setCurrentView('home');
              setMobileMenuOpen(false);
            }}
            className="block w-full text-right py-2 text-sm font-semibold text-[#2B211D] border-b border-[#E8DDD0]"
          >
            الرئيسية
          </button>
          <button
            onClick={() => {
              setCurrentView('shop');
              setMobileMenuOpen(false);
            }}
            className="block w-full text-right py-2 text-sm font-semibold text-[#2B211D] border-b border-[#E8DDD0]"
          >
            تشكيلة المجوهرات
          </button>
          <button
            onClick={() => {
              setCurrentView('about');
              setMobileMenuOpen(false);
            }}
            className="block w-full text-right py-2 text-sm font-semibold text-[#2B211D] border-b border-[#E8DDD0]"
          >
            قصة زينة
          </button>
          <button
            onClick={() => {
              setCurrentView('contact');
              setMobileMenuOpen(false);
            }}
            className="block w-full text-right py-2 text-sm font-semibold text-[#2B211D] border-b border-[#E8DDD0]"
          >
            تواصل معنا
          </button>
        </div>
      )}
    </header>
  );
};

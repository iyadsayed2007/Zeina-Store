import React from 'react';
import { Order, PurchaseInvoice, StoreSettings } from '../types';
import { Logo } from './Logo';
import { exportSalesInvoicePDF, exportPurchaseInvoicePDF } from '../utils/invoiceGenerator';
import { Printer, Download, X, CheckCircle, ShieldCheck } from 'lucide-react';

interface InvoiceModalProps {
  order?: Order;
  purchase?: PurchaseInvoice;
  settings: StoreSettings;
  isOpen: boolean;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  order,
  purchase,
  settings,
  isOpen,
  onClose,
}) => {
  if (!isOpen || (!order && !purchase)) return null;

  const isSale = !!order;
  const invNumber = isSale ? order?.invoiceNumber : purchase?.invoiceNumber;
  const dateStr = isSale
    ? new Date(order!.createdAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })
    : purchase?.date;

  const [isExporting, setIsExporting] = React.useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    if (isExporting) return;
    setIsExporting(true);
    try {
      if (isSale && order) {
        await exportSalesInvoicePDF(order, settings);
      } else if (purchase) {
        await exportPurchaseInvoicePDF(purchase, settings);
      }
    } catch (err) {
      console.error('Failed to export PDF:', err);
      alert('حدث خطأ أثناء تصدير الفاتورة بصيغة PDF');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#F7F1E8] rounded-2xl w-full max-w-3xl shadow-2xl border border-[#D8CBBE] overflow-hidden flex flex-col max-h-[92vh]">
        {/* Action Header bar */}
        <div className="bg-[#2B211D] text-[#F7F1E8] px-6 py-4 flex items-center justify-between no-print">
          <div className="flex items-center gap-3">
            <span className="bg-[#B99A68] text-white text-xs px-3 py-1 rounded-full font-medium">
              {isSale ? 'فاتورة بيع رسمية' : 'فاتورة شراء وتوريد'}
            </span>
            <h3 className="font-semibold text-lg">فاتورة رقم #{invNumber}</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#3B2D27] hover:bg-[#4A3932] text-white rounded-lg text-sm transition"
              title="طباعة الفاتورة"
            >
              <Printer className="w-4 h-4 text-[#D8C19A]" />
              <span>طباعة</span>
            </button>
            <button
              onClick={handleDownloadPDF}
              disabled={isExporting}
              className={`flex items-center gap-1.5 px-3 py-1.5 bg-[#B99A68] hover:bg-[#A88856] text-white rounded-lg text-sm font-medium transition shadow-sm ${
                isExporting ? 'opacity-70 cursor-not-allowed' : ''
              }`}
              title="تصدير PDF"
            >
              <Download className={`w-4 h-4 ${isExporting ? 'animate-bounce' : ''}`} />
              <span>{isExporting ? 'جارٍ التصدير...' : 'تحميل PDF'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-300 hover:text-white rounded-lg hover:bg-stone-700/40 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paper Area */}
        <div id="printable-invoice" className="p-8 overflow-y-auto flex-1 bg-[#F7F1E8] text-[#2B211D] text-right font-sans">
          {/* Header Brand Bar */}
          <div className="flex flex-row-reverse justify-between items-start border-b-2 border-[#D8CBBE] pb-6 mb-6">
            <div className="text-left">
              <span className="inline-block px-3 py-1 bg-[#E8DDD0] text-[#2B211D] font-bold text-xs uppercase tracking-widest rounded-md mb-2">
                {isSale ? 'OFFICIAL SALES INVOICE' : 'PURCHASE INVOICE'}
              </span>
              <h2 className="text-2xl font-bold font-serif text-[#2B211D]">#{invNumber}</h2>
              <p className="text-xs text-[#7A6A60] mt-1">التاريخ: {dateStr}</p>
              {isSale && (
                <p className="text-xs text-[#7A6A60]">رقم الطلب: {order?.orderNumber}</p>
              )}
            </div>

            <div className="flex flex-col items-start">
              <Logo size="lg" />
              <p className="text-xs text-[#7A6A60] mt-2 font-medium">
                {settings.storeNameAr} — إكسسوارات ومجوهرات فاخرة
              </p>
              <p className="text-xs text-[#7A6A60]">
                السجل التجاري: {settings.commercialRecord} | البطاقة الضريبية: {settings.taxNumber}
              </p>
            </div>
          </div>

          {/* Parties Info Grid */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-[#E8DDD0]/50 p-4 rounded-xl border border-[#D8CBBE]">
              <p className="text-xs font-bold text-[#B99A68] uppercase mb-1">
                {isSale ? 'بيانات العميل المستلم' : 'بيانات المورّد'}
              </p>
              <p className="font-bold text-base text-[#2B211D]">
                {isSale ? order?.customerName : purchase?.supplierName}
              </p>
              <p className="text-xs text-[#7A6A60] mt-1">
                الهاتف: {isSale ? order?.customerPhone : purchase?.supplierPhone}
              </p>
              {isSale ? (
                <p className="text-xs text-[#7A6A60]">
                  العنوان: {order?.city} — {order?.shippingAddress}
                </p>
              ) : (
                purchase?.supplierTaxId && (
                  <p className="text-xs text-[#7A6A60]">
                    الرقم الضريبي للمورد: {purchase.supplierTaxId}
                  </p>
                )
              )}
            </div>

            <div className="bg-[#E8DDD0]/50 p-4 rounded-xl border border-[#D8CBBE]">
              <p className="text-xs font-bold text-[#B99A68] uppercase mb-1">بيانات المتجر والتسليم</p>
              <p className="font-bold text-base text-[#2B211D]">{settings.storeName}</p>
              <p className="text-xs text-[#7A6A60] mt-1">العنوان: {settings.address}, {settings.city}</p>
              <p className="text-xs text-[#7A6A60]">خدمة العملاء: {settings.phone}</p>
              {isSale && (
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-xs bg-[#B99A68]/15 text-[#8E7142] px-2 py-0.5 rounded font-medium">
                    طريقة الدفع: {order?.paymentMethod === 'cod' ? 'الدفع عند الاستلام' : order?.paymentMethod === 'card' ? 'بطاقة بنكية' : order?.paymentMethod === 'instapay' ? 'إنستاباي' : 'فودافون كاش'}
                  </span>
                  <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded flex items-center gap-1 font-medium">
                    <CheckCircle className="w-3 h-3" />
                    {order?.paymentStatus === 'paid' ? 'تم السداد' : 'قيد السداد'}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Table */}
          <div className="rounded-xl border border-[#D8CBBE] overflow-hidden mb-6">
            <table className="w-full text-right text-sm">
              <thead className="bg-[#2B211D] text-[#F7F1E8]">
                <tr>
                  <th className="py-3 px-4 text-xs font-semibold">م</th>
                  <th className="py-3 px-4 text-xs font-semibold">البيان / المنتج</th>
                  <th className="py-3 px-4 text-xs font-semibold text-center">الكمية</th>
                  <th className="py-3 px-4 text-xs font-semibold">
                    {isSale ? 'السعر الفردي' : 'سعر التكلفة'}
                  </th>
                  <th className="py-3 px-4 text-xs font-semibold text-left">الإجمالي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D8CBBE]">
                {isSale &&
                  order?.items.map((item, idx) => (
                    <tr key={idx} className={idx % 2 === 1 ? 'bg-[#E8DDD0]/20' : 'bg-transparent'}>
                      <td className="py-3 px-4 text-xs text-[#7A6A60]">{idx + 1}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#2B211D]">{item.nameAr || item.name}</div>
                        {item.selectedColor && (
                          <span className="text-xs text-[#B76E79]">اللون: {item.selectedColor}</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center font-bold text-[#2B211D]">{item.quantity}</td>
                      <td className="py-3 px-4 text-[#7A6A60]">{(item.price ?? 0).toLocaleString()} ج.م</td>
                      <td className="py-3 px-4 font-bold text-[#2B211D] text-left">
                        {((item.price ?? 0) * (item.quantity ?? 1)).toLocaleString()} ج.م
                      </td>
                    </tr>
                  ))}

                {!isSale &&
                  purchase?.items.map((item, idx) => (
                    <tr key={idx} className={idx % 2 === 1 ? 'bg-[#E8DDD0]/20' : 'bg-transparent'}>
                      <td className="py-3 px-4 text-xs text-[#7A6A60]">{idx + 1}</td>
                      <td className="py-3 px-4 font-semibold text-[#2B211D]">{item.productName}</td>
                      <td className="py-3 px-4 text-center font-bold text-[#2B211D]">{item.quantity}</td>
                      <td className="py-3 px-4 text-[#7A6A60]">{(item.costPrice ?? 0).toLocaleString()} ج.م</td>
                      <td className="py-3 px-4 font-bold text-[#2B211D] text-left">
                        {(item.total ?? 0).toLocaleString()} ج.م
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>

          {/* Totals Section */}
          <div className="flex justify-end mb-8">
            <div className="w-72 bg-[#E8DDD0]/60 p-4 rounded-xl border border-[#D8CBBE] space-y-2 text-sm">
              {isSale ? (
                <>
                  <div className="flex justify-between text-[#7A6A60]">
                    <span>المجموع الفرعي:</span>
                    <span className="font-bold text-[#2B211D]">{(order?.subtotal ?? 0).toLocaleString()} ج.م</span>
                  </div>
                  {order?.discount ? (
                    <div className="flex justify-between text-[#B76E79] font-medium">
                      <span>الخصم ({order.discountCode || 'كوبون'}):</span>
                      <span>-{(order.discount ?? 0).toLocaleString()} ج.م</span>
                    </div>
                  ) : null}
                  <div className="flex justify-between text-[#7A6A60]">
                    <span>رسوم الشحن والتوصيل:</span>
                    <span>{order?.shippingFee === 0 ? 'مجاناً' : `${order?.shippingFee ?? 0} ج.م`}</span>
                  </div>
                  <div className="border-t border-[#D8CBBE] pt-2 flex justify-between items-center text-base font-bold text-[#2B211D]">
                    <span className="text-[#B99A68]">المبلغ الإجمالي:</span>
                    <span className="text-xl text-[#B99A68]">{(order?.total ?? 0).toLocaleString()} ج.م</span>
                  </div>
                </>
              ) : (
                <div className="flex justify-between items-center text-base font-bold text-[#2B211D]">
                  <span className="text-[#B99A68]">إجمالي التكلفة:</span>
                  <span className="text-xl text-[#B99A68]">{(purchase?.totalAmount ?? 0).toLocaleString()} ج.م</span>
                </div>
              )}
            </div>
          </div>

          {/* Footer note */}
          <div className="border-t border-[#D8CBBE] pt-4 text-center text-xs text-[#7A6A60] space-y-1">
            <div className="flex items-center justify-center gap-2 text-[#B99A68] font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>فاتورة معتمدة ومسجلة في نظام Zeina Store الإلكتروني</span>
            </div>
            <p>نشكركم لاختياركم متجر زينة. استمتعي ببريق وفخامة إكسسواراتك الفريدة.</p>
            <p className="text-[11px] text-[#A6978C]">
              سياسة الاستبدال والاسترجاع: يُسمح بالاستبدال خلال 14 يوماً مع الحفاظ على العلبة والملصقات بحالتها الأصلية.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

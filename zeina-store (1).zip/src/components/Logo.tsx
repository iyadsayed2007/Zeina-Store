import React from 'react';
import { useStore } from '../context/StoreContext';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'custom';
  variant?: 'light' | 'dark' | 'auto';
  showSubtitle?: boolean;
  customLogoUrl?: string;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  variant = 'auto',
  showSubtitle = true,
  customLogoUrl,
}) => {
  const sizeMap = {
    sm: 'h-9 w-auto',
    md: 'h-12 w-auto',
    lg: 'h-16 w-auto',
    xl: 'h-24 w-auto',
    custom: '',
  };

  // Check if store settings have a dynamic uploaded logo
  let storeLogoUrl = '';
  try {
    const store = useStore();
    storeLogoUrl = store?.settings?.logoUrl || '';
  } catch {
    // Rendered outside StoreProvider
  }

  const activeLogo = customLogoUrl || storeLogoUrl;

  if (activeLogo && activeLogo.trim() !== '') {
    return (
      <div className={`inline-flex items-center select-none ${className}`}>
        <img
          src={activeLogo}
          alt="Zeina Store Logo"
          className={`${sizeMap[size]} object-contain`}
        />
      </div>
    );
  }

  const isDark = variant === 'dark';
  const textColor = isDark ? '#F7F1E8' : '#2B211D';
  const roseColor = '#C47B86';
  const roseSoft = '#D898A2';

  return (
    <div className={`inline-flex items-center select-none ${className}`}>
      <svg
        viewBox="0 0 540 320"
        className={`${sizeMap[size]} transition-transform duration-300`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id={`roseGrad-${variant}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#DF9EA8" />
            <stop offset="60%" stopColor="#C47B86" />
            <stop offset="100%" stopColor="#B36974" />
          </linearGradient>
          <linearGradient id={`ribbonGrad-${variant}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F5D8DC" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#C47B86" stopOpacity="0.7" />
          </linearGradient>
        </defs>

        <g transform="translate(20, -40)">
          {/* Shopping Bag Handles */}
          <path
            d="M 172 130 C 172 65, 218 52, 238 52 C 258 52, 280 65, 280 130"
            stroke={`url(#roseGrad-${variant})`}
            strokeWidth="9"
            strokeLinecap="round"
            fill="none"
          />
          <circle cx="172" cy="132" r="6.5" fill={roseColor} />
          <circle cx="280" cy="132" r="6.5" fill={roseColor} />

          {/* Bag Outline with tilted perspective and left ribbon fold */}
          <path
            d="M 125 255 L 160 130 L 320 130 L 345 255"
            stroke={`url(#roseGrad-${variant})`}
            strokeWidth="8.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />

          {/* Left Ribbon / Fold 3D edge */}
          <path
            d="M 125 255 L 144 145 L 160 130 L 142 245 Z"
            fill={`url(#ribbonGrad-${variant})`}
          />
          <path
            d="M 125 255 C 135 264, 150 266, 160 262 L 155 248 Z"
            fill={roseSoft}
          />

          {/* Zeina brand text with elegant serif typography */}
          <g>
            {/* Custom stylized Serif 'Z' with swooping luxury cuts */}
            <path
              d="M 152 150 L 260 150 L 260 164 C 238 165, 222 168, 208 177 L 168 234 L 272 234 L 284 252 L 152 252 L 152 238 C 174 237, 190 233, 202 225 L 240 170 L 165 170 L 152 150 Z"
              fill={textColor}
            />

            {/* Letters "eina" in high-contrast luxury serif typeface */}
            <text
              x="262"
              y="253"
              fontFamily="'Playfair Display', 'Cormorant Garamond', 'Times New Roman', serif"
              fontSize="106"
              fontWeight="800"
              fill={textColor}
              letterSpacing="-2"
            >
              eina
            </text>

            {/* Heart symbol replacing the dot over the letter 'i' */}
            <g transform="translate(338, 178) scale(0.95)">
              <path
                d="M 0 4.5 C -7 -7, -18 2, 0 18 C 18 2, 7 -7, 0 4.5 Z"
                fill={roseColor}
              />
            </g>
          </g>

          {/* STORE with flanking thin accent lines */}
          {showSubtitle && (
            <g>
              <line
                x1="88"
                y1="305"
                x2="170"
                y2="305"
                stroke={roseColor}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <text
                x="250"
                y="312"
                fontFamily="'Plus Jakarta Sans', 'Cairo', sans-serif"
                fontSize="22"
                fontWeight="700"
                fill={textColor}
                letterSpacing="9"
                textAnchor="middle"
              >
                STORE
              </text>
              <line
                x1="330"
                y1="305"
                x2="412"
                y2="305"
                stroke={roseColor}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};

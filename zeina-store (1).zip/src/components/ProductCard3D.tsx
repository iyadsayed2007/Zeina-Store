import React, { useState, useRef } from 'react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';
import { ShoppingBag, Star, Eye } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard3D: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { addToCart, setSelectedProductId, setCurrentView } = useStore();
  const cardRef = useRef<HTMLDivElement>(null);

  // 3D Tilt calculation
  const [transformStyle, setTransformStyle] = useState<string>('');
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [addedAnimation, setAddedAnimation] = useState<boolean>(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / centerY) * -7; // max 7 deg
    const rotateY = ((x - centerX) / centerX) * 7;

    setTransformStyle(`perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setTransformStyle('perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)');
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleCardClick = () => {
    setSelectedProductId(product.id);
    setCurrentView('product-detail');
  };

  const handleAddToCartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1, product.colors?.[0]);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 800);
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={handleCardClick}
      style={{
        transform: transformStyle,
        transition: isHovered ? 'transform 0.1s ease-out' : 'transform 0.4s ease-out',
      }}
      className="group relative bg-[#F7F1E8] rounded-2xl border border-[#D8CBBE] overflow-hidden shadow-xs hover:shadow-xl transition-shadow cursor-pointer flex flex-col"
    >
      {/* Product Image Stage */}
      <div className="relative aspect-square w-full overflow-hidden bg-[#E8DDD0]">
        <img
          src={product.images[0]}
          alt={product.nameAr}
          className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 ease-out"
          loading="lazy"
        />

        {/* Secondary image on hover if available */}
        {product.images[1] && (
          <img
            src={product.images[1]}
            alt={product.nameAr}
            className={`absolute inset-0 w-full h-full object-cover object-center transition-opacity duration-500 ${
              isHovered ? 'opacity-100' : 'opacity-0'
            }`}
          />
        )}

        {/* Badges */}
        <div className="absolute top-3 right-3 flex flex-col gap-1.5 z-10">
          {product.isBestSeller && (
            <span className="bg-[#B76E79] text-white text-[11px] font-bold px-2.5 py-1 rounded-full shadow-md backdrop-blur-xs">
              الأكثر طلباً
            </span>
          )}
          {product.isFeatured && (
            <span className="bg-[#B99A68] text-white text-[11px] font-bold px-2.5 py-1 rounded-full shadow-md">
              مميز
            </span>
          )}
        </div>

        {/* Low Stock Alert */}
        {product.stock <= 5 && product.stock > 0 && (
          <div className="absolute bottom-3 right-3 bg-[#2B211D]/80 backdrop-blur-xs text-[#D8C19A] text-[10px] font-medium px-2 py-0.5 rounded-md">
            متبقي {product.stock} قطع فقط
          </div>
        )}

        {/* Quick View Button overlay */}
        <div
          className={`absolute inset-0 bg-[#2B211D]/20 backdrop-blur-xs flex items-center justify-center gap-2 transition-opacity duration-300 ${
            isHovered ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (onQuickView) onQuickView(product);
              else handleCardClick();
            }}
            className="p-2.5 bg-white text-[#2B211D] rounded-full shadow-lg hover:bg-[#B99A68] hover:text-white transition transform hover:scale-110"
            title="نظرة سريعة"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Details Box */}
      <div className="p-4 flex flex-col flex-1 justify-between bg-gradient-to-b from-[#F7F1E8] to-[#E8DDD0]/40">
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-[#7A6A60] font-medium">{product.categoryName}</span>
            <div className="flex items-center gap-1 text-[#B99A68]">
              <Star className="w-3.5 h-3.5 fill-[#B99A68]" />
              <span className="text-[11px] font-bold">{product.rating.toFixed(1)}</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="font-bold text-sm text-[#2B211D] group-hover:text-[#B99A68] transition-colors line-clamp-1 leading-snug">
            {product.nameAr}
          </h3>

          <p className="text-[11px] text-[#7A6A60] line-clamp-1 mt-0.5 font-sans">
            {product.material || 'مطلي بماء الذهب وحجر الزركونيا'}
          </p>
        </div>

        {/* Price and Cart Action */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-[#D8CBBE]/60">
          <div>
            <span className="text-xs text-[#7A6A60] block -mb-1">السعر</span>
            <span className="font-bold text-base text-[#2B211D] font-mono">
              {(product.price ?? 0).toLocaleString()} <span className="text-xs font-sans text-[#7A6A60]">ج.م</span>
            </span>
          </div>

          <button
            onClick={handleAddToCartClick}
            className={`p-2.5 rounded-full transition-all duration-300 shadow-sm flex items-center justify-center ${
              addedAnimation
                ? 'bg-emerald-600 text-white scale-110'
                : 'bg-[#2B211D] text-[#F7F1E8] hover:bg-[#B99A68] active:scale-95'
            }`}
            title="أضيفي للسلة"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

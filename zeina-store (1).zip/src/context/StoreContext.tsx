import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Product,
  Category,
  Order,
  PurchaseInvoice,
  DiscountCoupon,
  Review,
  Banner,
  StoreSettings,
} from '../types';
import {
  fetchServerData,
  saveProductApi,
  deleteProductApi,
  createOrderApi,
  updateOrderApi,
  savePurchaseApi,
  saveCategoryApi,
  deleteCategoryApi,
  saveDiscountApi,
  deleteDiscountApi,
  addReviewApi,
  updateReviewApi,
  deleteReviewApi,
  saveBannerApi,
  deleteBannerApi,
  saveSettingsApi,
  loginApi,
  validateSessionApi,
  resetDatabaseApi,
  restoreBackupApi,
} from '../services/api';
import {
  initializeDatabase,
  getProducts,
  getCategories,
  getOrders,
  getPurchases,
  getDiscounts,
  getReviews,
  getBanners,
  getStoreSettings,
  getCurrentUser,
  loginUser,
  loginUserAsync,
  registerUser,
  logoutUser,
  createOrder,
  createPurchaseInvoice,
  saveProduct,
  deleteProduct,
  saveCategory,
  deleteCategory,
  saveDiscount,
  deleteDiscount,
  validateCoupon,
  addReview,
  updateReviewStatus,
  deleteReview,
  saveBanner,
  deleteBanner,
  updateStoreSettings,
  updateOrderStatus,
  updateUserProfile,
  exportBackupToFile,
  restoreBackupFromJSON,
  exportProductsToExcel,
  exportOrdersToExcel,
  importProductsFromExcel,
} from '../db/storage';

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
}

interface StoreContextType {
  // Navigation & View
  currentView: string;
  setCurrentView: (view: string) => void;
  selectedProductId: string | null;
  setSelectedProductId: (id: string | null) => void;
  selectedCategorySlug: string | null;
  setSelectedCategorySlug: (slug: string | null) => void;

  // Data
  products: Product[];
  categories: Category[];
  orders: Order[];
  purchases: PurchaseInvoice[];
  discounts: DiscountCoupon[];
  reviews: Review[];
  banners: Banner[];
  settings: StoreSettings;
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedColor?: string) => void;
  removeFromCart: (productId: string, selectedColor?: string) => void;
  updateCartQuantity: (productId: string, quantity: number, selectedColor?: string) => void;
  clearCart: () => void;
  cartTotal: number;
  cartItemCount: number;
  appliedCoupon: DiscountCoupon | null;
  discountAmount: number;
  applyCouponCode: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;

  // Operations
  placeOrder: (orderData: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    shippingAddress: string;
    city: string;
    paymentMethod: Order['paymentMethod'];
    notes?: string;
  }) => Order;
  refreshData: () => void;

  // Auth
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: { name: string; email: string; password: string; phone?: string; address?: string; city?: string }) => { success: boolean; error?: string };
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;

  // Admin Actions
  saveProductAction: (prod: Partial<Product> & { name: string; price: number }) => void;
  deleteProductAction: (id: string) => void;
  updateOrderStatusAction: (orderId: string, status: Order['status'], paymentStatus?: Order['paymentStatus']) => void;
  createPurchaseAction: (data: { supplierName: string; supplierPhone: string; supplierTaxId?: string; items: PurchaseInvoice['items']; notes?: string }) => void;
  saveCategoryAction: (cat: Partial<Category> & { nameAr: string }) => void;
  deleteCategoryAction: (id: string) => void;
  saveDiscountAction: (disc: Partial<DiscountCoupon> & { code: string; value: number }) => void;
  deleteDiscountAction: (id: string) => void;
  addReviewAction: (rev: Omit<Review, 'id' | 'date' | 'status'>) => void;
  updateReviewStatusAction: (id: string, status: 'approved' | 'pending') => void;
  deleteReviewAction: (id: string) => void;
  saveBannerAction: (banner: Partial<Banner> & { titleAr: string; subtitleAr: string }) => void;
  deleteBannerAction: (id: string) => void;
  updateSettingsAction: (settings: Partial<StoreSettings>) => void;

  // Backup & Excel
  exportBackup: () => void;
  restoreBackup: (jsonStr: string) => { success: boolean; message: string; count?: number };
  resetDatabaseToDefault: () => void;
  exportProductsExcel: () => void;
  exportOrdersExcel: () => void;
  importProductsExcel: (file: File) => Promise<{ success: boolean; message: string; count?: number }>;

  // Active Invoice preview modal
  previewOrder: Order | null;
  setPreviewOrder: (order: Order | null) => void;
  previewPurchase: PurchaseInvoice | null;
  setPreviewPurchase: (purchase: PurchaseInvoice | null) => void;

  // Toast / Alerts
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

const getInitialView = (): string => {
  if (typeof window !== 'undefined') {
    const hash = window.location.hash.toLowerCase();
    const search = new URLSearchParams(window.location.search);
    const path = window.location.pathname.toLowerCase();
    if (
      hash === '#admin' ||
      hash === '#/admin' ||
      search.get('portal') === 'admin' ||
      search.get('view') === 'admin' ||
      path.endsWith('/admin')
    ) {
      return 'admin-dashboard';
    }
  }
  return 'home';
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<string>(getInitialView);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string | null>(null);

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [purchases, setPurchases] = useState<PurchaseInvoice[]>([]);
  const [discounts, setDiscounts] = useState<DiscountCoupon[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [settings, setSettings] = useState<StoreSettings>(getStoreSettings());
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('zeina_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedCoupon, setAppliedCoupon] = useState<DiscountCoupon | null>(null);
  const [discountAmount, setDiscountAmount] = useState<number>(0);

  // Invoice modal
  const [previewOrder, setPreviewOrder] = useState<Order | null>(null);
  const [previewPurchase, setPreviewPurchase] = useState<PurchaseInvoice | null>(null);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 4000);
  };

  const loadAll = async () => {
    // 1. Instant local state load
    initializeDatabase();
    setProducts(getProducts());
    setCategories(getCategories());
    setOrders(getOrders());
    setPurchases(getPurchases());
    setDiscounts(getDiscounts());
    setReviews(getReviews());
    setBanners(getBanners());
    setSettings(getStoreSettings());
    setCurrentUser(getCurrentUser());

    // 2. Fetch authoritative central server-side persistence
    try {
      const serverData = await fetchServerData();
      if (serverData) {
        if (serverData.products?.length) setProducts(serverData.products);
        if (serverData.categories?.length) setCategories(serverData.categories);
        if (serverData.orders) setOrders(serverData.orders);
        if (serverData.purchases) setPurchases(serverData.purchases);
        if (serverData.discounts) setDiscounts(serverData.discounts);
        if (serverData.reviews) setReviews(serverData.reviews);
        if (serverData.banners) setBanners(serverData.banners);
        if (serverData.settings) setSettings(serverData.settings);
      }
      const sessionUser = await validateSessionApi();
      if (sessionUser) {
        setCurrentUser(sessionUser);
      }
    } catch (err) {
      console.warn('Server sync skipped, local state active:', err);
    }
  };

  useEffect(() => {
    loadAll();
    const handleDbChange = () => loadAll();
    window.addEventListener('zeina_db_change', handleDbChange);
    return () => window.removeEventListener('zeina_db_change', handleDbChange);
  }, []);

  useEffect(() => {
    localStorage.setItem('zeina_cart', JSON.stringify(cart));
  }, [cart]);

  // Recalculate discount if coupon applied
  useEffect(() => {
    if (!appliedCoupon) {
      setDiscountAmount(0);
      return;
    }
    const sub = cart.reduce((sum, it) => sum + it.product.price * it.quantity, 0);
    const result = validateCoupon(appliedCoupon.code, sub);
    if (result.valid) {
      setDiscountAmount(result.discountAmount);
    } else {
      setAppliedCoupon(null);
      setDiscountAmount(0);
      showToast(`تم إلغاء الكوبون: ${result.message}`);
    }
  }, [cart, appliedCoupon]);

  const addToCart = (product: Product, quantity = 1, selectedColor?: string) => {
    setCart((prev) => {
      const existing = prev.find(
        (it) => it.product.id === product.id && it.selectedColor === selectedColor
      );
      if (existing) {
        return prev.map((it) =>
          it.product.id === product.id && it.selectedColor === selectedColor
            ? { ...it, quantity: it.quantity + quantity }
            : it
        );
      }
      return [...prev, { product, quantity, selectedColor }];
    });
    showToast(`تمت إضافة "${product.nameAr}" إلى حقيبة التسوق ✨`);
  };

  const removeFromCart = (productId: string, selectedColor?: string) => {
    setCart((prev) =>
      prev.filter((it) => !(it.product.id === productId && it.selectedColor === selectedColor))
    );
  };

  const updateCartQuantity = (productId: string, quantity: number, selectedColor?: string) => {
    if (quantity <= 0) {
      removeFromCart(productId, selectedColor);
      return;
    }
    setCart((prev) =>
      prev.map((it) =>
        it.product.id === productId && it.selectedColor === selectedColor
          ? { ...it, quantity }
          : it
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
    setDiscountAmount(0);
  };

  const cartTotal = cart.reduce((sum, it) => sum + it.product.price * it.quantity, 0);
  const cartItemCount = cart.reduce((sum, it) => sum + it.quantity, 0);

  const applyCouponCode = (code: string) => {
    const res = validateCoupon(code, cartTotal);
    if (res.valid && res.coupon) {
      setAppliedCoupon(res.coupon);
      setDiscountAmount(res.discountAmount);
      showToast(res.message);
      return { success: true, message: res.message };
    }
    return { success: false, message: res.message };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setDiscountAmount(0);
    showToast('تمت إزالة كود الخصم');
  };

  const placeOrder = (data: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    shippingAddress: string;
    city: string;
    paymentMethod: Order['paymentMethod'];
    notes?: string;
  }) => {
    const subtotal = cartTotal;
    const shippingFee = subtotal >= settings.freeShippingThreshold ? 0 : settings.shippingFeeFlat;
    const total = Math.max(0, subtotal - discountAmount + shippingFee);

    const items = cart.map((it) => ({
      productId: it.product.id,
      name: it.product.name,
      nameAr: it.product.nameAr,
      price: it.product.price,
      costPrice: it.product.costPrice,
      quantity: it.quantity,
      image: it.product.images[0] || '',
      selectedColor: it.selectedColor,
    }));

    const newOrder = createOrder({
      customerId: currentUser?.id || `guest-${Date.now()}`,
      customerName: data.customerName,
      customerEmail: data.customerEmail,
      customerPhone: data.customerPhone,
      shippingAddress: data.shippingAddress,
      city: data.city,
      items,
      subtotal,
      discount: discountAmount,
      discountCode: appliedCoupon?.code,
      shippingFee,
      total,
      paymentMethod: data.paymentMethod,
      notes: data.notes,
    });

    // Synchronize to backend database
    createOrderApi(newOrder).catch((e) => console.warn('Order sync to backend failed:', e));

    clearCart();
    loadAll();
    setPreviewOrder(newOrder);
    showToast(`تم تأكيد طلبك بنجاح رقم #${newOrder.orderNumber}! تم إصدار الفاتورة ✨`);
    return newOrder;
  };

  const login = async (email: string, pass: string) => {
    try {
      const serverRes = await loginApi(email, pass);
      if (serverRes.success && serverRes.user) {
        setCurrentUser(serverRes.user);
        showToast(`مرحباً بك مجدداً، ${serverRes.user.name}`);
        return { success: true };
      }
      if (serverRes.error) {
        return { success: false, error: serverRes.error };
      }
    } catch {
      // Fallback to local storage verification
    }

    const res = await loginUserAsync(email, pass);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      showToast(`مرحباً بك مجدداً، ${res.user.name}`);
      return { success: true };
    }
    return { success: false, error: res.error };
  };

  const register = (data: { name: string; email: string; password: string; phone?: string; address?: string; city?: string }) => {
    const res = registerUser(data);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      showToast(`أهلاً بك في عائلة زينة ستور، ${res.user.name} ✨`);
      return { success: true };
    }
    return { success: false, error: res.error };
  };

  const logout = () => {
    logoutUser();
    setCurrentUser(null);
    setCurrentView('home');
    if (typeof window !== 'undefined' && (window.location.hash.includes('admin') || window.location.search.includes('admin'))) {
      window.location.hash = '';
    }
    showToast('تم تسجيل الخروج بنجاح');
  };

  const handleSetCurrentUser = (user: User | null) => {
    setCurrentUser(user);
    if (typeof window !== 'undefined') {
      try {
        if (user) {
          localStorage.setItem('zeina_current_user', JSON.stringify(user));
        } else {
          localStorage.removeItem('zeina_current_user');
        }
      } catch (e) {
        console.warn('Failed to persist current user locally:', e);
      }
    }
  };

  const updateProfile = (data: Partial<User>) => {
    if (!currentUser) return;
    const updated = updateUserProfile(currentUser.id, data);
    if (updated) {
      handleSetCurrentUser(updated);
      showToast('تم تحديث البيانات الشخصية بنجاح');
    }
  };

  // Admin Actions with Server Synchronization
  const saveProductAction = (prod: Partial<Product> & { name: string; price: number }) => {
    const saved = saveProduct(prod);
    saveProductApi(saved).catch((e) => console.warn('Product sync to backend failed:', e));
    loadAll();
    showToast('تم حفظ بيانات المنتج بنجاح');
  };

  const deleteProductAction = (id: string) => {
    deleteProduct(id);
    deleteProductApi(id).catch((e) => console.warn('Delete product sync failed:', e));
    loadAll();
    showToast('تم حذف المنتج بنجاح');
  };

  const updateOrderStatusAction = (orderId: string, status: Order['status'], paymentStatus?: Order['paymentStatus']) => {
    updateOrderStatus(orderId, status, paymentStatus);
    updateOrderApi(orderId, { status, paymentStatus }).catch((e) => console.warn('Order status sync failed:', e));
    loadAll();
    showToast(`تم تحديث حالة الطلب إلى "${status}" بنجاح`);
  };

  const createPurchaseAction = (data: { supplierName: string; supplierPhone: string; supplierTaxId?: string; items: PurchaseInvoice['items']; notes?: string }) => {
    const newPur = createPurchaseInvoice(data);
    savePurchaseApi(newPur).catch((e) => console.warn('Purchase sync failed:', e));
    loadAll();
    setPreviewPurchase(newPur);
    showToast(`تم تسجيل فاتورة الشراء #${newPur.invoiceNumber} وتحديث المخزون بنجاح!`);
  };

  const saveCategoryAction = (cat: Partial<Category> & { nameAr: string }) => {
    const saved = saveCategory(cat);
    saveCategoryApi(saved).catch((e) => console.warn('Category sync failed:', e));
    loadAll();
    showToast('تم حفظ الفئة بنجاح');
  };

  const deleteCategoryAction = (id: string) => {
    deleteCategory(id);
    deleteCategoryApi(id).catch((e) => console.warn('Delete category sync failed:', e));
    loadAll();
    showToast('تم حذف الفئة بنجاح');
  };

  const saveDiscountAction = (disc: Partial<DiscountCoupon> & { code: string; value: number }) => {
    const saved = saveDiscount(disc);
    saveDiscountApi(saved).catch((e) => console.warn('Discount sync failed:', e));
    loadAll();
    showToast('تم حفظ كود الخصم بنجاح');
  };

  const deleteDiscountAction = (id: string) => {
    deleteDiscount(id);
    deleteDiscountApi(id).catch((e) => console.warn('Delete discount sync failed:', e));
    loadAll();
    showToast('تم حذف كود الخصم');
  };

  const addReviewAction = (rev: Omit<Review, 'id' | 'date' | 'status'>) => {
    const saved = addReview(rev);
    addReviewApi(saved).catch((e) => console.warn('Review sync failed:', e));
    loadAll();
    showToast('شكراً لتقييمك! تم نشر التقييم بنجاح');
  };

  const updateReviewStatusAction = (id: string, status: 'approved' | 'pending') => {
    updateReviewStatus(id, status);
    updateReviewApi(id, { status }).catch((e) => console.warn('Review update sync failed:', e));
    loadAll();
  };

  const deleteReviewAction = (id: string) => {
    deleteReview(id);
    deleteReviewApi(id).catch((e) => console.warn('Delete review sync failed:', e));
    loadAll();
  };

  const saveBannerAction = (banner: Partial<Banner> & { titleAr: string; subtitleAr: string }) => {
    const saved = saveBanner(banner);
    saveBannerApi(saved).catch((e) => console.warn('Banner sync failed:', e));
    loadAll();
    showToast('تم حفظ البانر الإعلاني بنجاح');
  };

  const deleteBannerAction = (id: string) => {
    deleteBanner(id);
    deleteBannerApi(id).catch((e) => console.warn('Delete banner sync failed:', e));
    loadAll();
    showToast('تم حذف البانر');
  };

  const updateSettingsAction = (newSettings: Partial<StoreSettings>) => {
    updateStoreSettings(newSettings);
    saveSettingsApi(newSettings).catch((e) => console.warn('Settings sync failed:', e));
    loadAll();
    showToast('تم تحديث إعدادات المتجر بنجاح');
  };

  const exportBackup = () => {
    exportBackupToFile();
    showToast('تم تصدير النسخة الاحتياطية بنجاح!');
  };

  const restoreBackup = (jsonStr: string) => {
    const res = restoreBackupFromJSON(jsonStr);
    try {
      const parsed = JSON.parse(jsonStr);
      restoreBackupApi(parsed).catch((e) => console.warn('Backup sync to server failed:', e));
    } catch (e) {
      console.warn('Invalid JSON for server sync:', e);
    }
    if (res.success) {
      loadAll();
      showToast(res.message);
    } else {
      showToast(res.message);
    }
    return res;
  };

  const resetDatabaseToDefault = () => {
    localStorage.clear();
    resetDatabaseApi().catch((e) => console.warn('Server reset failed:', e));
    initializeDatabase();
    loadAll();
    showToast('تمت إعادة ضبط بيانات المتجر إلى الحالة الأصلية بنجاح!');
  };

  const exportProductsExcel = () => {
    exportProductsToExcel();
    showToast('تم تصدير ملف إكسيل للمنتجات بنجاح');
  };

  const exportOrdersExcel = () => {
    exportOrdersToExcel();
    showToast('تم تصدير ملف إكسيل للطلبات والمبيعات بنجاح');
  };

  const importProductsExcel = async (file: File) => {
    const res = await importProductsFromExcel(file);
    if (res.success) {
      loadAll();
      showToast(res.message);
    } else {
      showToast(res.message);
    }
    return res;
  };

  return (
    <StoreContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedProductId,
        setSelectedProductId,
        selectedCategorySlug,
        setSelectedCategorySlug,

        products,
        categories,
        orders,
        purchases,
        discounts,
        reviews,
        banners,
        settings,
        currentUser,
        setCurrentUser: handleSetCurrentUser,

        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartTotal,
        cartItemCount,
        appliedCoupon,
        discountAmount,
        applyCouponCode,
        removeCoupon,

        placeOrder,
        refreshData: loadAll,

        login,
        register,
        logout,
        updateProfile,

        saveProductAction,
        deleteProductAction,
        updateOrderStatusAction,
        createPurchaseAction,
        saveCategoryAction,
        deleteCategoryAction,
        saveDiscountAction,
        deleteDiscountAction,
        addReviewAction,
        updateReviewStatusAction,
        deleteReviewAction,
        saveBannerAction,
        deleteBannerAction,
        updateSettingsAction,

        exportBackup,
        restoreBackup,
        resetDatabaseToDefault,
        exportProductsExcel,
        exportOrdersExcel,
        importProductsExcel,

        previewOrder,
        setPreviewOrder,
        previewPurchase,
        setPreviewPurchase,

        toastMessage,
        showToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within a StoreProvider');
  return ctx;
};

import {
  User,
  Product,
  Category,
  Order,
  PurchaseInvoice,
  DiscountCoupon,
  Review,
  Banner,
  StoreSettings,
  BackupData,
} from '../types';
import * as XLSX from 'xlsx';
import {
  hashPassword,
  verifyPassword,
  checkAccountLockout,
  recordFailedLoginAttempt,
  resetFailedLoginAttempts,
  createAdminSession,
  clearAdminSession,
} from '../utils/security';

const STORAGE_KEYS = {
  USERS: 'zeina_db_users',
  PRODUCTS: 'zeina_db_products',
  CATEGORIES: 'zeina_db_categories',
  ORDERS: 'zeina_db_orders',
  PURCHASES: 'zeina_db_purchases',
  DISCOUNTS: 'zeina_db_discounts',
  REVIEWS: 'zeina_db_reviews',
  BANNERS: 'zeina_db_banners',
  SETTINGS: 'zeina_db_settings',
  CURRENT_USER: 'zeina_current_user',
};

// Seed Categories
const initialCategories: Category[] = [
  {
    id: 'cat-1',
    name: 'Luxury Jewelry Sets',
    nameAr: 'أطقم مجوهرات فاخرة',
    slug: 'jewelry-sets',
    iconName: 'Sparkles',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80',
    itemCount: 4,
  },
  {
    id: 'cat-2',
    name: 'Necklaces & Pendants',
    nameAr: 'سلاسل وعقود زركون',
    slug: 'necklaces',
    iconName: 'Gem',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=600&q=80',
    itemCount: 6,
  },
  {
    id: 'cat-3',
    name: 'Bracelets & Bangles',
    nameAr: 'أساور وبناجر ذهبية',
    slug: 'bracelets',
    iconName: 'Watch',
    image: 'https://images.unsplash.com/photo-1611591475887-2172a50a6234?auto=format&fit=crop&w=600&q=80',
    itemCount: 5,
  },
  {
    id: 'cat-4',
    name: 'Statement & Solitaire Rings',
    nameAr: 'خواتم سوليتير ومرصعة',
    slug: 'rings',
    iconName: 'CircleDot',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=600&q=80',
    itemCount: 7,
  },
  {
    id: 'cat-5',
    name: 'Earrings & Drops',
    nameAr: 'أقراط وحلقان لؤلؤ',
    slug: 'earrings',
    iconName: 'Disc',
    image: 'https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=600&q=80',
    itemCount: 5,
  },
  {
    id: 'cat-6',
    name: 'Evening Clutches',
    nameAr: 'حقائب سهرة ومحافظ مخملية',
    slug: 'bags',
    iconName: 'ShoppingBag',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80',
    itemCount: 3,
  },
];

// Seed Products
const initialProducts: Product[] = [
  {
    id: 'prod-1',
    sku: 'ZN-SET-001',
    name: 'Royal Champagne Diamond Set',
    nameAr: 'طقم الزفاف الملكي المطلي ذهب عيار 18 مع أحجار زركونيا',
    description: 'A breathtaking bridal luxury jewelry set featuring sparkling micropave cubic zirconia and soft champagne gold plating.',
    descriptionAr: 'طقم ملكي متكامل يضم عقداً فخماً، أقراطاً متدلية، سواراً راقياً وخاتماً قابلاً للتعديل. مطلي بماء الذهب الوردي وعيار 18 مع ترصيع زركون سويسري براق.',
    price: 3450,
    costPrice: 1950,
    stock: 14,
    categoryId: 'cat-1',
    categoryName: 'أطقم مجوهرات فاخرة',
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.9,
    reviewsCount: 28,
    isFeatured: true,
    isBestSeller: true,
    colors: ['ذهب وردي', 'ذهب أصفر', 'فضي بلاتيني'],
    material: 'نحاس نقي مطلي ذهب 18k وحجر زركون 5A',
    createdAt: '2026-08-15T10:00:00Z',
  },
  {
    id: 'prod-2',
    sku: 'ZN-NCK-002',
    name: 'Zeina Signature Heart Pendant',
    nameAr: 'عقد زينة الأيقوني بقلب الورد ولمسات الذهب الوردي',
    description: 'Exquisite signature necklace with a dusty rose crystal heart and delicate chain matching Zeina aesthetic.',
    descriptionAr: 'العقد المميز المستوحى من هوية متجر زينة، بتعليقة قلب من الكريستال الوردي الداكن وحلقات انسيابية تعكس الأنوثة والجاذبية.',
    price: 1250,
    costPrice: 620,
    stock: 26,
    categoryId: 'cat-2',
    categoryName: 'سلاسل وعقود زركون',
    images: [
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 5.0,
    reviewsCount: 42,
    isFeatured: true,
    isBestSeller: true,
    colors: ['روز جولد', 'ذهبي شامبين'],
    material: 'فضة إسترليني 925 مطلية روز جولد',
    createdAt: '2026-08-18T14:30:00Z',
  },
  {
    id: 'prod-3',
    sku: 'ZN-BRC-003',
    name: 'Serpentine Diamond Tennis Bracelet',
    nameAr: 'إسوارة التنس الكلاسيكية الفاخرة بحبات الزركون المزدوجة',
    description: 'Double strand tennis bracelet offering timeless elegance for evening soirees and everyday luxury.',
    descriptionAr: 'إسوارة تنس مميزة مصممة بخط مزدوج من أحجار الزركون المتلألئة، قفل أمان مزدوج ولمعان لا يتغير مع مرور الوقت.',
    price: 1650,
    costPrice: 850,
    stock: 19,
    categoryId: 'cat-3',
    categoryName: 'أساور وبناجر ذهبية',
    images: [
      'https://images.unsplash.com/photo-1611591475887-2172a50a6234?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.8,
    reviewsCount: 19,
    isFeatured: true,
    isBestSeller: false,
    colors: ['شامبين جولد', 'فضي ناصع'],
    material: 'ستانلس ستيل 316L مقاوم للماء',
    createdAt: '2026-08-20T11:20:00Z',
  },
  {
    id: 'prod-4',
    sku: 'ZN-RNG-004',
    name: 'Emerald Cut Solitaire Ring',
    nameAr: 'خاتم سوليتير مستطيل القطع الزمردي (Emerald Cut)',
    description: 'Statement emerald cut faux-diamond ring embraced by micropave band for mesmerizing brilliance.',
    descriptionAr: 'خاتم السوليتير الأيقوني بحجر رئيسي 3 قيراط بقطع زمردي فريد مع أحجار جانبية دقيقة، يمنح اليد مظهراً راقياً لا يقاوم.',
    price: 1100,
    costPrice: 520,
    stock: 31,
    categoryId: 'cat-4',
    categoryName: 'خواتم سوليتير ومرصعة',
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.9,
    reviewsCount: 35,
    isFeatured: true,
    isBestSeller: true,
    colors: ['ذهبي عيار 18', 'بلاتيني'],
    material: 'فضة 925 وحجر مويسانيتي برّاق',
    createdAt: '2026-08-22T16:00:00Z',
  },
  {
    id: 'prod-5',
    sku: 'ZN-EAR-005',
    name: 'Baroque Pearl Cascading Drops',
    nameAr: 'أقراط لؤلؤ المياه العذبة الباروكية المتدلية',
    description: 'Organic shaped baroque freshwater pearls suspended from delicate champagne gold twigs.',
    descriptionAr: 'أقراط مميزة مستوحاة من الطبيعة بلآلئ باروكية طبيعية غير منتظمة الشكل، تمنح حضوراً فريداً ومميزاً في المناسبات السعيدة.',
    price: 980,
    costPrice: 420,
    stock: 22,
    categoryId: 'cat-5',
    categoryName: 'أقراط وحلقان لؤلؤ',
    images: [
      'https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.7,
    reviewsCount: 16,
    isFeatured: false,
    isBestSeller: false,
    colors: ['لؤلؤي كريمي مع ذهب شامبين'],
    material: 'لؤلؤ طبيعي مستزرع ونحاس مطلي',
    createdAt: '2026-08-25T09:15:00Z',
  },
  {
    id: 'prod-6',
    sku: 'ZN-BAG-006',
    name: 'Velvet Midnight Rose Clutch',
    nameAr: 'كلتش سهرة مخملي بلون الدستي روز مع سلسلة ذهبية',
    description: 'Rich velvet hardcase evening clutch with jeweled clasp and detachable snake chain.',
    descriptionAr: 'حقيبة يد مسائية مصنوعة من المخمل الفاخر بدرجة الروز المطفأ مع إبزيم مرصع بحبات الكريستال وسلسلة كتف أنيقة قابلة للفك.',
    price: 1850,
    costPrice: 950,
    stock: 8,
    categoryId: 'cat-6',
    categoryName: 'حقائب سهرة ومحافظ مخملية',
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.9,
    reviewsCount: 14,
    isFeatured: true,
    isBestSeller: false,
    colors: ['دستي روز', 'أسود إسبريسو', 'بيج شامبين'],
    material: 'مخمل إيطالي ناعم وإكسسوار معدني ذهبي',
    createdAt: '2026-08-28T12:00:00Z',
  },
  {
    id: 'prod-7',
    sku: 'ZN-SET-007',
    name: 'Celestial Star & Moon Necklace & Earring Set',
    nameAr: 'طقم القمر والنجوم المتلألئة (سلسال + حلق)',
    description: 'Delicate celestial themed jewelry set designed for subtle everyday glam.',
    descriptionAr: 'طقم ناعم وعصري يجمع هلال القمر مع النجوم الماسية الصغيرة، اختيار مثالي للإهداء أو الارتداء اليومي الأنيق.',
    price: 1450,
    costPrice: 700,
    stock: 18,
    categoryId: 'cat-1',
    categoryName: 'أطقم مجوهرات فاخرة',
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.8,
    reviewsCount: 22,
    isFeatured: false,
    isBestSeller: true,
    colors: ['ذهبي أصفر', 'فضي'],
    material: 'معدن مطلي بالذهب وبلورات سواروفسكي بديلة',
    createdAt: '2026-08-30T10:45:00Z',
  },
  {
    id: 'prod-8',
    sku: 'ZN-BRC-008',
    name: 'Roman Empress Bangle',
    nameAr: 'بنجرة كارتييه ستايل المنحوتة بالأرقام الرومانية',
    description: 'Iconic structured bangle with high polish finish and screw accent motifs.',
    descriptionAr: 'بنجرة عصرية صلبة بتصميم الأرقام الرومانية المحفورة بدقة، مريحة في الارتداء وتناسب التكديس مع أساور أخرى.',
    price: 890,
    costPrice: 380,
    stock: 35,
    categoryId: 'cat-3',
    categoryName: 'أساور وبناجر ذهبية',
    images: [
      'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1611591475887-2172a50a6234?auto=format&fit=crop&w=800&q=80',
    ],
    status: 'active',
    rating: 4.9,
    reviewsCount: 51,
    isFeatured: false,
    isBestSeller: true,
    colors: ['شامبين جولد', 'روز جولد', 'فضي'],
    material: 'تيتانيوم مقاوم للخدش وتغير اللون',
    createdAt: '2026-09-01T08:30:00Z',
  },
];

// Seed Users
const initialUsers: User[] = [
  {
    id: 'user-admin',
    name: 'إياد سيد (المدير العام)',
    email: 'iyadsayed@gmail.com',
    // Salted PBKDF2 SHA-256 hash for iyadsayed2007 (100,000 iterations)
    passwordHash: 'pbkdf2:100000:82190f63b23d16fff76e4725b9f36b08:b05001e87faaa5fa9469af7e4bc6daefc2ce14796d5fef03a7ca5e792808162d',
    role: 'admin',
    phone: '+201012345678',
    address: 'الشيخ زايد، بيفرلي هيلز',
    city: 'الجيزة',
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'user-staff',
    name: 'مريم الصاوي (مسؤولة المبيعات)',
    email: 'staff@zeinastore.com',
    passwordHash: 'pbkdf2:100000:7d1db067eb7f3a2122f326a1082afcf7:2070a281a0999d81bef898451fdd79a3cacf39037fcf4bb8f3c62b69ee54f8a7',
    role: 'staff',
    phone: '+201123456789',
    address: 'المعادي دجلة، شارع 200',
    city: 'القاهرة',
    createdAt: '2026-02-15T00:00:00Z',
  },
  {
    id: 'user-cust-1',
    name: 'نوران الشاذلي',
    email: 'nouran@example.com',
    passwordHash: 'pbkdf2:100000:7d1db067eb7f3a2122f326a1082afcf7:2070a281a0999d81bef898451fdd79a3cacf39037fcf4bb8f3c62b69ee54f8a7',
    role: 'customer',
    phone: '+201098765432',
    address: 'التجمع الخامس، شارع التسعين الشمالي، كمبوند ماونتن فيو',
    city: 'القاهرة الجديدة',
    createdAt: '2026-08-01T00:00:00Z',
  },
  {
    id: 'user-cust-2',
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@example.com',
    passwordHash: 'pbkdf2:100000:7d1db067eb7f3a2122f326a1082afcf7:2070a281a0999d81bef898451fdd79a3cacf39037fcf4bb8f3c62b69ee54f8a7',
    role: 'customer',
    phone: '+201287654321',
    address: 'Beverly Hills, Villa 12',
    city: 'Giza',
    createdAt: '2026-08-10T00:00:00Z',
  },
];

// Seed Orders
const initialOrders: Order[] = [
  {
    id: 'ord-1001',
    orderNumber: 'ZN-2026-1001',
    invoiceNumber: 'INV-2026-0089',
    customerId: 'user-cust-1',
    customerName: 'نوران الشاذلي',
    customerEmail: 'nouran@example.com',
    customerPhone: '+201098765432',
    shippingAddress: 'كمبوند ماونتن فيو 1، فيلا 24B',
    city: 'القاهرة الجديدة',
    items: [
      {
        productId: 'prod-1',
        name: 'Royal Champagne Diamond Set',
        nameAr: 'طقم الزفاف الملكي المطلي ذهب عيار 18',
        price: 3450,
        costPrice: 1950,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=400&q=80',
        selectedColor: 'ذهب وردي',
      },
      {
        productId: 'prod-2',
        name: 'Zeina Signature Heart Pendant',
        nameAr: 'عقد زينة الأيقوني بقلب الورد',
        price: 1250,
        costPrice: 620,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=400&q=80',
        selectedColor: 'روز جولد',
      },
    ],
    subtotal: 4700,
    discount: 470,
    discountCode: 'ZEINA10',
    shippingFee: 0,
    tax: 0,
    total: 4230,
    totalAmount: 4230,
    status: 'delivered',
    paymentMethod: 'card',
    paymentStatus: 'paid',
    notes: 'برجاء التوصيل بالفترة المسائية مع علبة الهدايا المخملية',
    createdAt: '2026-09-02T11:30:00Z',
    deliveredAt: '2026-09-04T15:00:00Z',
  },
  {
    id: 'ord-1002',
    orderNumber: 'ZN-2026-1002',
    invoiceNumber: 'INV-2026-0090',
    customerId: 'user-cust-2',
    customerName: 'Sarah Jenkins',
    customerEmail: 'sarah.jenkins@example.com',
    customerPhone: '+201287654321',
    shippingAddress: 'Beverly Hills, Villa 12, Compound Gate 3',
    city: 'Giza',
    items: [
      {
        productId: 'prod-4',
        name: 'Emerald Cut Solitaire Ring',
        nameAr: 'خاتم سوليتير مستطيل القطع الزمردي',
        price: 1100,
        costPrice: 520,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=400&q=80',
        selectedColor: 'بلاتيني',
      },
    ],
    subtotal: 2200,
    discount: 0,
    shippingFee: 70,
    tax: 0,
    total: 2270,
    totalAmount: 2270,
    status: 'shipped',
    paymentMethod: 'instapay',
    paymentStatus: 'paid',
    createdAt: '2026-09-06T14:15:00Z',
  },
  {
    id: 'ord-1003',
    orderNumber: 'ZN-2026-1003',
    invoiceNumber: 'INV-2026-0091',
    customerId: 'user-cust-1',
    customerName: 'نوران الشاذلي - VIP Client',
    customerEmail: 'houda.m@example.com',
    customerPhone: '+201145678901',
    shippingAddress: 'الدقي، شارع مصدق أمام بنك مصر',
    city: 'الجيزة',
    items: [
      {
        productId: 'prod-6',
        name: 'Velvet Midnight Rose Clutch',
        nameAr: 'كلتش سهرة مخملي بلون الدستي روز',
        price: 1850,
        costPrice: 950,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=400&q=80',
      },
    ],
    subtotal: 1850,
    discount: 0,
    shippingFee: 50,
    tax: 0,
    total: 1900,
    totalAmount: 1900,
    status: 'processing',
    paymentMethod: 'cod',
    paymentStatus: 'pending',
    createdAt: '2026-09-07T18:40:00Z',
  },
];

// Seed Purchases (Purchases from suppliers for stock management)
const initialPurchases: PurchaseInvoice[] = [
  {
    id: 'pur-501',
    invoiceNumber: 'PUR-2026-0045',
    supplierName: 'دار الجوهرة الإيطالية للتوريدات الفاخرة',
    supplierPhone: '+201005544332',
    supplierTaxId: 'EG-984-772-109',
    items: [
      {
        productId: 'prod-1',
        productName: 'طقم الزفاف الملكي المطلي ذهب عيار 18',
        costPrice: 1950,
        quantity: 15,
        total: 29250,
      },
      {
        productId: 'prod-2',
        productName: 'عقد زينة الأيقوني بقلب الورد',
        costPrice: 620,
        quantity: 30,
        total: 18600,
      },
    ],
    totalAmount: 47850,
    notes: 'شحنة الكولكشن الخريفي الدفعة الأولى - حالة ممتازة',
    date: '2026-08-10',
    status: 'received',
    createdAt: '2026-08-10T09:00:00Z',
  },
  {
    id: 'pur-502',
    invoiceNumber: 'PUR-2026-0046',
    supplierName: 'مصنع الشرق للأحجار الكريمة والفضة 925',
    supplierPhone: '+201122334455',
    supplierTaxId: 'EG-331-402-990',
    items: [
      {
        productId: 'prod-4',
        productName: 'خاتم سوليتير مستطيل القطع الزمردي',
        costPrice: 520,
        quantity: 35,
        total: 18200,
      },
      {
        productId: 'prod-3',
        productName: 'إسوارة التنس الكلاسيكية الفاخرة',
        costPrice: 850,
        quantity: 20,
        total: 17000,
      },
    ],
    totalAmount: 35200,
    notes: 'توريد دفعة الخواتم والأساور لموسم الخطوبة والزفاف',
    date: '2026-08-25',
    status: 'received',
    createdAt: '2026-08-25T11:30:00Z',
  },
];

// Seed Discounts
const initialDiscounts: DiscountCoupon[] = [
  {
    id: 'disc-1',
    code: 'ZEINA10',
    description: 'خصم ترحيبي 10% لعملاء المتجر الجدد',
    type: 'percent',
    value: 10,
    minOrder: 500,
    validUntil: '2026-12-31',
    isActive: true,
    usageCount: 47,
    usageLimit: 500,
  },
  {
    id: 'disc-2',
    code: 'VIP500',
    description: 'خصم فوري 500 جنيه عند الشراء بقيمة 3000 جنيه أو أكثر',
    type: 'fixed',
    value: 500,
    minOrder: 3000,
    validUntil: '2026-10-31',
    isActive: true,
    usageCount: 12,
    usageLimit: 100,
  },
  {
    id: 'disc-3',
    code: 'GOLDEN20',
    description: 'عرض خاص 20% على أطقم المجوهرات الفاخرة',
    type: 'percent',
    value: 20,
    minOrder: 2000,
    validUntil: '2026-11-15',
    isActive: true,
    usageCount: 19,
    usageLimit: 50,
  },
];

// Seed Reviews
const initialReviews: Review[] = [
  {
    id: 'rev-1',
    productId: 'prod-1',
    productName: 'طقم الزفاف الملكي المطلي ذهب عيار 18',
    customerName: 'سلمى العبد',
    rating: 5,
    comment: 'الطقم تحفة وفخامة لا توصف! ارتدته في خطوبتي وكل الضيوف سألوني عنه. التغليف والعلبة المخملية أكثر من رائعة.',
    date: '2026-09-01',
    status: 'approved',
  },
  {
    id: 'rev-2',
    productId: 'prod-2',
    productName: 'عقد زينة الأيقوني بقلب الورد',
    customerName: 'مريم الشريف',
    rating: 5,
    comment: 'اللوجو والقلب الوردي رقيق جداً وناعم، لمعانه حقيقي ولا يغير لونه أبداً حتى مع العطور والماء.',
    date: '2026-09-03',
    status: 'approved',
  },
  {
    id: 'rev-3',
    productId: 'prod-4',
    productName: 'خاتم سوليتير مستطيل القطع الزمردي',
    customerName: 'أميرة عبد الرحمن',
    rating: 5,
    comment: 'حجر السوليتير قاطع الضوء بشكل ساحر، الحجم مناسب جداً والمقاس دقيق للغاية.',
    date: '2026-09-05',
    status: 'approved',
  },
];

// Seed Banners
const initialBanners: Banner[] = [
  {
    id: 'ban-1',
    titleAr: 'مجموعة النقاء والأناقة الملكية',
    subtitleAr: 'تألقي ببريق لا يخبو مع تشكيلة الإكسسوارات الفاخرة المطلية بالذهب وأحجار الزركون السويسرية الراقية',
    tagAr: 'مجموعة خريف 2026 الحصرية',
    titleEn: 'Royal Purity & Splendor',
    subtitleEn: 'Indulge in timeless brilliance crafted with 18k champagne gold plating and 5A Swiss zircon stones',
    ctaTextAr: 'اكتشفي المجموعة الفاخرة',
    ctaLink: '/shop',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1200&q=85',
    badge: 'توصيل مجاني فوق 2000 ج.م',
    active: true,
    order: 1,
  },
  {
    id: 'ban-2',
    titleAr: 'سحر القلوب وعطور الأنوثة',
    subtitleAr: 'عقد زينة الأيقوني بقلب الورد وتصاميم ناعمة صُممت لتلامس مشاعرك في كل لحظة مميزة',
    tagAr: 'الإصدار المحدود لمتجر زينة',
    titleEn: 'Signature Heart Charm',
    subtitleEn: 'The iconic Zeina blush pink heart pendant tailored for memorable occasions',
    ctaTextAr: 'تسوقي العقد الأيقوني',
    ctaLink: '/shop?cat=cat-2',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=1200&q=85',
    badge: 'الأكثر طلباً هذا الأسبوع',
    active: true,
    order: 2,
  },
];

// Store Settings
const initialSettings: StoreSettings = {
  storeName: 'Zeina Store',
  storeNameAr: 'متجر زينة للإكسسوارات الفاخرة',
  taxNumber: 'EG-928-117-450',
  commercialRecord: 'CR-1098234',
  phone: '+20 10 9988 7766',
  email: 'contact@zeinastore.com',
  address: 'ممشى أهل مصر، كورنيش النيل، حي الزمالك الفاخر',
  city: 'القاهرة، جمهورية مصر العربية',
  currency: 'EGP',
  currencySymbol: 'ج.م',
  shippingFeeFlat: 50,
  freeShippingThreshold: 1500,
  taxPercentage: 0,
  instagramUrl: 'https://instagram.com/zeinastore',
  facebookUrl: 'https://facebook.com/zeinastore',
  whatsappNumber: '+201099887766',
};

// Storage helper functions
function getStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.error(`Error reading ${key} from storage:`, err);
    return fallback;
  }
}

function setStorage<T>(key: string, val: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(val));
    window.dispatchEvent(new Event('zeina_db_change'));
  } catch (err) {
    console.error(`Error saving ${key} to storage:`, err);
  }
}

// Initialization check
export function initializeDatabase(): void {
  if (!localStorage.getItem(STORAGE_KEYS.PRODUCTS)) {
    setStorage(STORAGE_KEYS.PRODUCTS, initialProducts);
  }
  if (!localStorage.getItem(STORAGE_KEYS.CATEGORIES)) {
    setStorage(STORAGE_KEYS.CATEGORIES, initialCategories);
  }
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    setStorage(STORAGE_KEYS.USERS, initialUsers);
  } else {
    // Auto-migrate stored users: ensure admin uses iyadsayed@gmail.com and PBKDF2 hash
    try {
      const storedUsers = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]') as User[];
      const adminIdx = storedUsers.findIndex((u) => u.role === 'admin');
      const targetHash = 'pbkdf2:100000:82190f63b23d16fff76e4725b9f36b08:b05001e87faaa5fa9469af7e4bc6daefc2ce14796d5fef03a7ca5e792808162d';
      
      if (adminIdx !== -1) {
        const admin = storedUsers[adminIdx];
        if (admin.email === 'admin@zeinastore.com' || !admin.passwordHash.startsWith('pbkdf2:')) {
          storedUsers[adminIdx] = {
            ...admin,
            email: 'iyadsayed@gmail.com',
            name: 'إياد سيد (المدير العام)',
            passwordHash: targetHash,
          };
          setStorage(STORAGE_KEYS.USERS, storedUsers);
        }
      } else {
        storedUsers.unshift(initialUsers[0]);
        setStorage(STORAGE_KEYS.USERS, storedUsers);
      }
    } catch {
      setStorage(STORAGE_KEYS.USERS, initialUsers);
    }
  }
  if (!localStorage.getItem(STORAGE_KEYS.ORDERS)) {
    setStorage(STORAGE_KEYS.ORDERS, initialOrders);
  }
  if (!localStorage.getItem(STORAGE_KEYS.PURCHASES)) {
    setStorage(STORAGE_KEYS.PURCHASES, initialPurchases);
  }
  if (!localStorage.getItem(STORAGE_KEYS.DISCOUNTS)) {
    setStorage(STORAGE_KEYS.DISCOUNTS, initialDiscounts);
  }
  if (!localStorage.getItem(STORAGE_KEYS.REVIEWS)) {
    setStorage(STORAGE_KEYS.REVIEWS, initialReviews);
  }
  if (!localStorage.getItem(STORAGE_KEYS.BANNERS)) {
    setStorage(STORAGE_KEYS.BANNERS, initialBanners);
  }
  if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
    setStorage(STORAGE_KEYS.SETTINGS, initialSettings);
  }
}

// ---------------- PRODUCTS ----------------
export function getProducts(): Product[] {
  const prods = getStorage<Product[]>(STORAGE_KEYS.PRODUCTS, initialProducts);
  return prods.map((p) => ({
    ...p,
    price: typeof p.price === 'number' && !isNaN(p.price) ? p.price : Number(p.price) || 0,
    costPrice: typeof p.costPrice === 'number' && !isNaN(p.costPrice) ? p.costPrice : Number(p.costPrice) || 0,
    stock: typeof p.stock === 'number' && !isNaN(p.stock) ? p.stock : Number(p.stock) || 0,
  }));
}

export function getProductById(id: string): Product | undefined {
  return getProducts().find((p) => p.id === id);
}

export function saveProduct(product: Partial<Product> & { name: string; price: number }): Product {
  const products = getProducts();
  const now = new Date().toISOString();

  if (product.id) {
    const idx = products.findIndex((p) => p.id === product.id);
    if (idx !== -1) {
      products[idx] = { ...products[idx], ...product };
      setStorage(STORAGE_KEYS.PRODUCTS, products);
      return products[idx];
    }
  }

  const newProduct: Product = {
    id: `prod-${Date.now()}`,
    sku: product.sku || `ZN-${Math.floor(1000 + Math.random() * 9000)}`,
    name: product.name,
    nameAr: product.nameAr || product.name,
    description: product.description || '',
    descriptionAr: product.descriptionAr || product.description || '',
    price: Number(product.price),
    costPrice: Number(product.costPrice) || Math.round(Number(product.price) * 0.5),
    stock: Number(product.stock) || 0,
    categoryId: product.categoryId || 'cat-1',
    categoryName: product.categoryName || 'مجوهرات فاخرة',
    images: product.images && product.images.length > 0 ? product.images : [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80',
    ],
    status: product.status || 'active',
    rating: product.rating || 5.0,
    reviewsCount: product.reviewsCount || 0,
    isFeatured: !!product.isFeatured,
    isBestSeller: !!product.isBestSeller,
    isNewArrival: true,
    colors: product.colors || ['شامبين جولد'],
    material: product.material || 'نحاس مطلي عيار 18k وزركون سويسري',
    createdAt: now,
  };

  products.unshift(newProduct);
  setStorage(STORAGE_KEYS.PRODUCTS, products);
  return newProduct;
}

export function deleteProduct(id: string): void {
  const products = getProducts().filter((p) => p.id !== id);
  setStorage(STORAGE_KEYS.PRODUCTS, products);
}

// Update stock quantities
export function adjustProductStock(productId: string, quantityDelta: number): boolean {
  const products = getProducts();
  const idx = products.findIndex((p) => p.id === productId);
  if (idx === -1) return false;

  const currentStock = products[idx].stock;
  const newStock = Math.max(0, currentStock + quantityDelta);
  products[idx].stock = newStock;
  setStorage(STORAGE_KEYS.PRODUCTS, products);
  return true;
}

// ---------------- CATEGORIES ----------------
export function getCategories(): Category[] {
  return getStorage<Category[]>(STORAGE_KEYS.CATEGORIES, initialCategories);
}

export function saveCategory(category: Partial<Category> & { nameAr: string }): Category {
  const categories = getCategories();
  if (category.id) {
    const idx = categories.findIndex((c) => c.id === category.id);
    if (idx !== -1) {
      categories[idx] = { ...categories[idx], ...category };
      setStorage(STORAGE_KEYS.CATEGORIES, categories);
      return categories[idx];
    }
  }

  const newCat: Category = {
    id: `cat-${Date.now()}`,
    name: category.name || category.nameAr,
    nameAr: category.nameAr,
    slug: category.slug || `cat-${Date.now()}`,
    iconName: category.iconName || 'Gem',
    image: category.image || 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80',
    itemCount: 0,
  };

  categories.push(newCat);
  setStorage(STORAGE_KEYS.CATEGORIES, categories);
  return newCat;
}

export function deleteCategory(id: string): void {
  const categories = getCategories().filter((c) => c.id !== id);
  setStorage(STORAGE_KEYS.CATEGORIES, categories);
}

// ---------------- ORDERS (Sales) ----------------
export function getOrders(): Order[] {
  const orders = getStorage<Order[]>(STORAGE_KEYS.ORDERS, initialOrders);
  return orders.map((o) => {
    const tot =
      typeof o.total === 'number' && !isNaN(o.total)
        ? o.total
        : typeof (o as any).totalAmount === 'number' && !isNaN((o as any).totalAmount)
        ? (o as any).totalAmount
        : 0;
    const subtot = typeof o.subtotal === 'number' && !isNaN(o.subtotal) ? o.subtotal : tot;
    const disc = typeof o.discount === 'number' && !isNaN(o.discount) ? o.discount : 0;
    const ship = typeof o.shippingFee === 'number' && !isNaN(o.shippingFee) ? o.shippingFee : 0;
    return {
      ...o,
      subtotal: subtot,
      discount: disc,
      shippingFee: ship,
      total: tot,
      totalAmount: tot,
      items: Array.isArray(o.items)
        ? o.items.map((it) => ({
            ...it,
            price: typeof it.price === 'number' && !isNaN(it.price) ? it.price : 0,
            costPrice: typeof it.costPrice === 'number' && !isNaN(it.costPrice) ? it.costPrice : 0,
            quantity: typeof it.quantity === 'number' && !isNaN(it.quantity) ? it.quantity : 1,
          }))
        : [],
    };
  });
}

export function getOrderById(id: string): Order | undefined {
  return getOrders().find((o) => o.id === id || o.orderNumber === id || o.invoiceNumber === id);
}

export function createOrder(data: {
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  city: string;
  items: Order['items'];
  subtotal: number;
  discount?: number;
  discountCode?: string;
  shippingFee: number;
  total: number;
  paymentMethod: Order['paymentMethod'];
  notes?: string;
}): Order {
  const orders = getOrders();
  const nextNumber = 1000 + orders.length + 1;
  const invNumber = 100 + orders.length + 1;

  const newOrder: Order = {
    id: `ord-${Date.now()}`,
    orderNumber: `ZN-2026-${nextNumber}`,
    invoiceNumber: `INV-2026-0${invNumber}`,
    customerId: data.customerId,
    customerName: data.customerName,
    customerEmail: data.customerEmail,
    customerPhone: data.customerPhone,
    shippingAddress: data.shippingAddress,
    city: data.city,
    items: data.items,
    subtotal: data.subtotal,
    discount: data.discount || 0,
    discountCode: data.discountCode,
    shippingFee: data.shippingFee,
    tax: 0,
    total: data.total,
    totalAmount: data.total,
    status: 'pending',
    paymentMethod: data.paymentMethod,
    paymentStatus: data.paymentMethod === 'cod' ? 'pending' : 'paid',
    notes: data.notes,
    createdAt: new Date().toISOString(),
  };

  // Automatic Stock Deduction (as mandated by SOP)
  data.items.forEach((item) => {
    adjustProductStock(item.productId, -item.quantity);
  });

  orders.unshift(newOrder);
  setStorage(STORAGE_KEYS.ORDERS, orders);

  // If a discount code was used, increment its usage
  if (data.discountCode) {
    incrementDiscountUsage(data.discountCode);
  }

  return newOrder;
}

export function updateOrderStatus(orderId: string, status: Order['status'], paymentStatus?: Order['paymentStatus']): Order | undefined {
  const orders = getOrders();
  const idx = orders.findIndex((o) => o.id === orderId);
  if (idx === -1) return undefined;

  orders[idx].status = status;
  if (paymentStatus) {
    orders[idx].paymentStatus = paymentStatus;
  }
  if (status === 'delivered') {
    orders[idx].deliveredAt = new Date().toISOString();
  }

  setStorage(STORAGE_KEYS.ORDERS, orders);
  return orders[idx];
}

// ---------------- PURCHASES (Suppliers) ----------------
export function getPurchases(): PurchaseInvoice[] {
  const purs = getStorage<PurchaseInvoice[]>(STORAGE_KEYS.PURCHASES, initialPurchases);
  return purs.map((pur) => ({
    ...pur,
    totalAmount: typeof pur.totalAmount === 'number' && !isNaN(pur.totalAmount) ? pur.totalAmount : 0,
    items: Array.isArray(pur.items)
      ? pur.items.map((it) => ({
          ...it,
          costPrice: typeof it.costPrice === 'number' && !isNaN(it.costPrice) ? it.costPrice : 0,
          total:
            typeof it.total === 'number' && !isNaN(it.total)
              ? it.total
              : (Number(it.costPrice) || 0) * (Number(it.quantity) || 1),
        }))
      : [],
  }));
}

export function createPurchaseInvoice(data: {
  supplierName: string;
  supplierPhone: string;
  supplierTaxId?: string;
  items: PurchaseInvoice['items'];
  notes?: string;
  date?: string;
}): PurchaseInvoice {
  const purchases = getPurchases();
  const purNumber = 50 + purchases.length + 1;
  const totalAmount = data.items.reduce((sum, item) => sum + item.total, 0);

  const newPurchase: PurchaseInvoice = {
    id: `pur-${Date.now()}`,
    invoiceNumber: `PUR-2026-00${purNumber}`,
    supplierName: data.supplierName,
    supplierPhone: data.supplierPhone,
    supplierTaxId: data.supplierTaxId,
    items: data.items,
    totalAmount,
    notes: data.notes,
    date: data.date || new Date().toISOString().split('T')[0],
    status: 'received',
    createdAt: new Date().toISOString(),
  };

  // Automatic Stock Addition (as mandated by SOP)
  data.items.forEach((item) => {
    adjustProductStock(item.productId, item.quantity);
  });

  purchases.unshift(newPurchase);
  setStorage(STORAGE_KEYS.PURCHASES, purchases);
  return newPurchase;
}

// ---------------- DISCOUNTS ----------------
export function getDiscounts(): DiscountCoupon[] {
  return getStorage<DiscountCoupon[]>(STORAGE_KEYS.DISCOUNTS, initialDiscounts);
}

export function saveDiscount(discount: Partial<DiscountCoupon> & { code: string; value: number }): DiscountCoupon {
  const discounts = getDiscounts();
  const upperCode = discount.code.toUpperCase().trim();

  if (discount.id) {
    const idx = discounts.findIndex((d) => d.id === discount.id);
    if (idx !== -1) {
      discounts[idx] = { ...discounts[idx], ...discount, code: upperCode };
      setStorage(STORAGE_KEYS.DISCOUNTS, discounts);
      return discounts[idx];
    }
  }

  const newDisc: DiscountCoupon = {
    id: `disc-${Date.now()}`,
    code: upperCode,
    description: discount.description || `كوبون خصم ${upperCode}`,
    type: discount.type || 'percent',
    value: Number(discount.value),
    minOrder: Number(discount.minOrder) || 0,
    validUntil: discount.validUntil || '2026-12-31',
    isActive: discount.isActive ?? true,
    usageCount: 0,
    usageLimit: Number(discount.usageLimit) || 100,
  };

  discounts.unshift(newDisc);
  setStorage(STORAGE_KEYS.DISCOUNTS, discounts);
  return newDisc;
}

export function deleteDiscount(id: string): void {
  const discounts = getDiscounts().filter((d) => d.id !== id);
  setStorage(STORAGE_KEYS.DISCOUNTS, discounts);
}

export function validateCoupon(code: string, subtotal: number): { valid: boolean; discountAmount: number; message: string; coupon?: DiscountCoupon } {
  const cleanCode = code.toUpperCase().trim();
  const coupon = getDiscounts().find((d) => d.code === cleanCode);

  if (!coupon) {
    return { valid: false, discountAmount: 0, message: 'كود الخصم غير موجود أو غير صالح' };
  }
  if (!coupon.isActive) {
    return { valid: false, discountAmount: 0, message: 'هذا الكوبون متوقف حالياً' };
  }
  if (coupon.usageCount >= coupon.usageLimit) {
    return { valid: false, discountAmount: 0, message: 'وصل هذا الكوبون للحد الأقصى من مرات الاستخدام' };
  }
  if (subtotal < coupon.minOrder) {
    return {
      valid: false,
      discountAmount: 0,
      message: `الحد الأدنى للطلب لتفعيل هذا الكوبون هو ${coupon.minOrder} ج.م`,
    };
  }

  let discountAmount = 0;
  if (coupon.type === 'percent') {
    discountAmount = Math.round((subtotal * coupon.value) / 100);
  } else {
    discountAmount = Math.min(coupon.value, subtotal);
  }

  return {
    valid: true,
    discountAmount,
    message: `تم تطبيق الخصم بنجاح: خصم ${discountAmount} ج.م`,
    coupon,
  };
}

function incrementDiscountUsage(code: string): void {
  const discounts = getDiscounts();
  const idx = discounts.findIndex((d) => d.code === code.toUpperCase().trim());
  if (idx !== -1) {
    discounts[idx].usageCount += 1;
    setStorage(STORAGE_KEYS.DISCOUNTS, discounts);
  }
}

// ---------------- REVIEWS ----------------
export function getReviews(): Review[] {
  return getStorage<Review[]>(STORAGE_KEYS.REVIEWS, initialReviews);
}

export function addReview(review: Omit<Review, 'id' | 'date' | 'status'>): Review {
  const reviews = getReviews();
  const newRev: Review = {
    ...review,
    id: `rev-${Date.now()}`,
    date: new Date().toISOString().split('T')[0],
    status: 'approved',
  };
  reviews.unshift(newRev);
  setStorage(STORAGE_KEYS.REVIEWS, reviews);
  return newRev;
}

export function updateReviewStatus(id: string, status: 'approved' | 'pending'): void {
  const reviews = getReviews();
  const idx = reviews.findIndex((r) => r.id === id);
  if (idx !== -1) {
    reviews[idx].status = status;
    setStorage(STORAGE_KEYS.REVIEWS, reviews);
  }
}

export function deleteReview(id: string): void {
  const reviews = getReviews().filter((r) => r.id !== id);
  setStorage(STORAGE_KEYS.REVIEWS, reviews);
}

// ---------------- BANNERS ----------------
export function getBanners(): Banner[] {
  return getStorage<Banner[]>(STORAGE_KEYS.BANNERS, initialBanners);
}

export function saveBanner(banner: Partial<Banner> & { titleAr: string; subtitleAr: string }): Banner {
  const banners = getBanners();
  if (banner.id) {
    const idx = banners.findIndex((b) => b.id === banner.id);
    if (idx !== -1) {
      banners[idx] = { ...banners[idx], ...banner };
      setStorage(STORAGE_KEYS.BANNERS, banners);
      return banners[idx];
    }
  }

  const newBanner: Banner = {
    id: `ban-${Date.now()}`,
    titleAr: banner.titleAr,
    subtitleAr: banner.subtitleAr,
    tagAr: banner.tagAr || 'جديد متجر زينة',
    titleEn: banner.titleEn || 'Zeina Luxury',
    subtitleEn: banner.subtitleEn || 'Finest Jewelry & Accessories',
    ctaTextAr: banner.ctaTextAr || 'تسوقي الآن',
    ctaLink: banner.ctaLink || '/shop',
    image: banner.image || 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1200&q=85',
    badge: banner.badge,
    active: banner.active ?? true,
    order: banners.length + 1,
  };

  banners.push(newBanner);
  setStorage(STORAGE_KEYS.BANNERS, banners);
  return newBanner;
}

export function deleteBanner(id: string): void {
  const banners = getBanners().filter((b) => b.id !== id);
  setStorage(STORAGE_KEYS.BANNERS, banners);
}

// ---------------- STORE SETTINGS ----------------
export function getStoreSettings(): StoreSettings {
  return getStorage<StoreSettings>(STORAGE_KEYS.SETTINGS, initialSettings);
}

export function updateStoreSettings(settings: Partial<StoreSettings>): StoreSettings {
  const current = getStoreSettings();
  const updated = { ...current, ...settings };
  setStorage(STORAGE_KEYS.SETTINGS, updated);
  return updated;
}

// ---------------- AUTHENTICATION & USERS ----------------
export function getUsers(): User[] {
  return getStorage<User[]>(STORAGE_KEYS.USERS, initialUsers);
}

export function getCurrentUser(): User | null {
  return getStorage<User | null>(STORAGE_KEYS.CURRENT_USER, null);
}

export async function loginUserAsync(
  email: string,
  passwordAttempt: string
): Promise<{ success: boolean; user?: User; error?: string; remainingAttempts?: number; isLocked?: boolean }> {
  // 1. Check brute-force lockout status
  const lockout = checkAccountLockout();
  if (lockout.isLocked) {
    return {
      success: false,
      isLocked: true,
      error: `تم قفل محاولات تسجيل الدخول مؤقتاً لحماية الحساب بعد عدة محاولات خاطئة. يرجى الانتظار ${lockout.remainingMinutes} دقيقة والمحاولة لاحقاً.`,
    };
  }

  const users = getUsers();
  const cleanEmail = email.toLowerCase().trim();
  const found = users.find((u) => u.email.toLowerCase() === cleanEmail);

  if (!found) {
    const lockInfo = recordFailedLoginAttempt();
    return {
      success: false,
      remainingAttempts: lockInfo.remainingAttempts,
      error: lockInfo.isNowLocked
        ? 'تم قفل الحساب مؤقتاً لمدة 15 دقيقة بعد تكرار المحاولات الخاطئة.'
        : `بيانات الدخول غير صحيحة. المحاولات المتبقية: ${lockInfo.remainingAttempts}`,
    };
  }

  // 2. Validate password securely (PBKDF2 or legacy upgrade)
  let isValid = false;
  if (found.passwordHash.startsWith('pbkdf2:')) {
    isValid = await verifyPassword(passwordAttempt, found.passwordHash);
  } else {
    // Legacy fallback comparison
    isValid = found.passwordHash === passwordAttempt || found.passwordHash === `hash_${passwordAttempt}`;
    if (isValid) {
      // Auto upgrade to PBKDF2
      found.passwordHash = await hashPassword(passwordAttempt);
      const all = getUsers();
      const idx = all.findIndex((u) => u.id === found.id);
      if (idx !== -1) {
        all[idx] = found;
        setStorage(STORAGE_KEYS.USERS, all);
      }
    }
  }

  if (!isValid) {
    const lockInfo = recordFailedLoginAttempt();
    return {
      success: false,
      remainingAttempts: lockInfo.remainingAttempts,
      error: lockInfo.isNowLocked
        ? 'تم قفل الحساب مؤقتاً لمدة 15 دقيقة بعد 5 محاولات خاطئة متتالية.'
        : `كلمة المرور غير صحيحة. المحاولات المتبقية: ${lockInfo.remainingAttempts}`,
    };
  }

  // 3. Reset lockout on successful credentials
  resetFailedLoginAttempts();

  // 4. Create secure admin session if admin or staff
  if (found.role === 'admin' || found.role === 'staff') {
    createAdminSession(found.email);
  }

  setStorage(STORAGE_KEYS.CURRENT_USER, found);
  return { success: true, user: found };
}

export function loginUser(email: string, passwordAttempt: string): { success: boolean; user?: User; error?: string } {
  const users = getUsers();
  const cleanEmail = email.toLowerCase().trim();
  const found = users.find((u) => u.email.toLowerCase() === cleanEmail);

  if (!found) {
    return { success: false, error: 'البريد الإلكتروني غير مسجل في النظام' };
  }

  // Synchronous check fallback
  const isMatch =
    found.passwordHash === passwordAttempt ||
    found.passwordHash === `hash_${passwordAttempt}` ||
    found.passwordHash.startsWith('pbkdf2:'); // in sync fallback, if hashed, caller should prefer loginUserAsync

  if (!isMatch) {
    return { success: false, error: 'كلمة المرور غير صحيحة، يرجى المحاولة ثانية' };
  }

  if (found.role === 'admin' || found.role === 'staff') {
    createAdminSession(found.email);
  }

  setStorage(STORAGE_KEYS.CURRENT_USER, found);
  return { success: true, user: found };
}

export async function updateAdminCredentials(
  currentPasswordAttempt: string,
  newEmail?: string,
  newPassword?: string
): Promise<{ success: boolean; error?: string; requireRelogin?: boolean; updatedEmail?: string }> {
  const users = getUsers();
  const adminIdx = users.findIndex((u) => u.role === 'admin');
  if (adminIdx === -1) {
    return { success: false, error: 'لم يتم العثور على حساب المدير في النظام' };
  }

  const admin = users[adminIdx];

  // Verify current password first (mandatory security check)
  const isPassValid = await verifyPassword(currentPasswordAttempt, admin.passwordHash);
  if (!isPassValid) {
    return { success: false, error: 'كلمة المرور الحالية غير صحيحة! تم رفض حفظ التعديلات لأسباب أمنية.' };
  }

  // Update email if provided
  if (newEmail && newEmail.trim() !== '') {
    const cleanEmail = newEmail.toLowerCase().trim();
    if (!cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, error: 'صيغة البريد الإلكتروني الجديد غير صالحة' };
    }
    const conflict = users.find((u) => u.id !== admin.id && u.email.toLowerCase() === cleanEmail);
    if (conflict) {
      return { success: false, error: 'البريد الإلكتروني المدخل مستخدم بالفعل بحساب آخر' };
    }
    admin.email = cleanEmail;
  }

  // Update password if provided
  let requireRelogin = false;
  if (newPassword && newPassword.trim() !== '') {
    if (newPassword.length < 6) {
      return { success: false, error: 'كلمة المرور الجديدة يجب ألا تقل عن 6 خانات' };
    }
    admin.passwordHash = await hashPassword(newPassword);
    requireRelogin = true;
  }

  users[adminIdx] = admin;
  setStorage(STORAGE_KEYS.USERS, users);

  if (requireRelogin) {
    // Force terminate all active admin sessions
    clearAdminSession();
    logoutUser();
    return {
      success: true,
      requireRelogin: true,
      updatedEmail: admin.email,
    };
  } else {
    // Update active user in storage
    const current = getCurrentUser();
    if (current && current.role === 'admin') {
      setStorage(STORAGE_KEYS.CURRENT_USER, admin);
      createAdminSession(admin.email);
    }
    return {
      success: true,
      requireRelogin: false,
      updatedEmail: admin.email,
    };
  }
}

export function registerUser(userData: {
  name: string;
  email: string;
  password: string;
  phone?: string;
  address?: string;
  city?: string;
}): { success: boolean; user?: User; error?: string } {
  const users = getUsers();
  const cleanEmail = userData.email.toLowerCase().trim();

  if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
    return { success: false, error: 'هذا البريد الإلكتروني مسجل بالفعل' };
  }

  const newUser: User = {
    id: `user-${Date.now()}`,
    name: userData.name,
    email: cleanEmail,
    passwordHash: userData.password,
    role: 'customer',
    phone: userData.phone,
    address: userData.address,
    city: userData.city,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  setStorage(STORAGE_KEYS.USERS, users);
  setStorage(STORAGE_KEYS.CURRENT_USER, newUser);
  return { success: true, user: newUser };
}

export function logoutUser(): void {
  clearAdminSession();
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  window.dispatchEvent(new Event('zeina_db_change'));
}

export function updateUserProfile(id: string, update: Partial<User>): User | undefined {
  const users = getUsers();
  const idx = users.findIndex((u) => u.id === id);
  if (idx === -1) return undefined;

  users[idx] = { ...users[idx], ...update };
  setStorage(STORAGE_KEYS.USERS, users);

  const currentUser = getCurrentUser();
  if (currentUser && currentUser.id === id) {
    setStorage(STORAGE_KEYS.CURRENT_USER, users[idx]);
  }
  return users[idx];
}

// ---------------- DATA BACKUP & RESTORE (RealmDB / JSON Schema) ----------------
export function generateBackupData(): BackupData {
  return {
    version: '1.0.0-realm-sync',
    timestamp: new Date().toISOString(),
    storeName: 'Zeina Store',
    users: getUsers(),
    products: getProducts(),
    categories: getCategories(),
    orders: getOrders(),
    purchases: getPurchases(),
    discounts: getDiscounts(),
    reviews: getReviews(),
    banners: getBanners(),
    settings: getStoreSettings(),
  };
}

export function exportBackupToFile(): void {
  const data = generateBackupData();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const dateStr = new Date().toISOString().replace(/[:.]/g, '-');
  link.href = url;
  link.download = `zeina-store-backup-${dateStr}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function restoreBackupFromJSON(jsonString: string): { success: boolean; message: string; count?: number } {
  try {
    const parsed = JSON.parse(jsonString) as Partial<BackupData>;

    if (!parsed.products || !Array.isArray(parsed.products)) {
      return { success: false, message: 'ملف النسخة الاحتياطية غير صالح أو تالف (ينقصه جدول المنتجات)' };
    }

    if (parsed.products) setStorage(STORAGE_KEYS.PRODUCTS, parsed.products);
    if (parsed.categories) setStorage(STORAGE_KEYS.CATEGORIES, parsed.categories);
    if (parsed.users) setStorage(STORAGE_KEYS.USERS, parsed.users);
    if (parsed.orders) setStorage(STORAGE_KEYS.ORDERS, parsed.orders);
    if (parsed.purchases) setStorage(STORAGE_KEYS.PURCHASES, parsed.purchases);
    if (parsed.discounts) setStorage(STORAGE_KEYS.DISCOUNTS, parsed.discounts);
    if (parsed.reviews) setStorage(STORAGE_KEYS.REVIEWS, parsed.reviews);
    if (parsed.banners) setStorage(STORAGE_KEYS.BANNERS, parsed.banners);
    if (parsed.settings) setStorage(STORAGE_KEYS.SETTINGS, parsed.settings);

    return {
      success: true,
      message: `تم استعادة قاعدة البيانات بنجاح! (${parsed.products.length} منتج، ${parsed.orders?.length || 0} طلب)`,
      count: parsed.products.length,
    };
  } catch (err: any) {
    return { success: false, message: `فشل استيراد النسخة الاحتياطية: ${err.message || 'صيغة JSON غير صحيحة'}` };
  }
}

// ---------------- EXCEL EXPORT & IMPORT (xlsx) ----------------
export function exportProductsToExcel(): void {
  const products = getProducts();
  const worksheetData = products.map((p) => ({
    'كود المنتج (SKU)': p.sku,
    'اسم المنتج بالعربي': p.nameAr,
    'اسم المنتج بالإنجليزي': p.name,
    'الفئة': p.categoryName || '',
    'سعر البيع (ج.م)': p.price,
    'سعر التكلفة (ج.م)': p.costPrice,
    'المخزون المتاح': p.stock,
    'الحالة': p.status === 'active' ? 'نشط' : 'مسودة',
    'الخامة': p.material || '',
    'تاريخ الإضافة': p.createdAt,
  }));

  const worksheet = XLSX.utils.json_to_sheet(worksheetData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'المنتجات');
  XLSX.writeFile(workbook, `Zeina_Products_${new Date().toISOString().split('T')[0]}.xlsx`);
}

export function exportOrdersToExcel(): void {
  const orders = getOrders();
  const worksheetData = orders.map((o) => ({
    'رقم الطلب': o.orderNumber,
    'رقم الفاتورة': o.invoiceNumber,
    'اسم العميل': o.customerName,
    'رقم الهاتف': o.customerPhone,
    'المدينة': o.city,
    'العنوان': o.shippingAddress,
    'إجمالي الطلب': o.total,
    'طريقة الدفع': o.paymentMethod,
    'حالة الدفع': o.paymentStatus === 'paid' ? 'مدفوع' : 'معلق',
    'حالة الطلب': o.status,
    'تاريخ الطلب': o.createdAt,
  }));

  const worksheet = XLSX.utils.json_to_sheet(worksheetData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'الطلبات والمبيعات');
  XLSX.writeFile(workbook, `Zeina_Orders_${new Date().toISOString().split('T')[0]}.xlsx`);
}

export async function importProductsFromExcel(file: File): Promise<{ success: boolean; message: string; count?: number }> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<any>(worksheet);

    if (!rows || rows.length === 0) {
      return { success: false, message: 'ملف الإكسيل فارغ ولا يحتوي على صفوف بيانات' };
    }

    let importedCount = 0;
    const currentProducts = getProducts();

    rows.forEach((row) => {
      const nameAr = row['اسم المنتج بالعربي'] || row['NameAr'] || row['اسم المنتج'] || row['Name'];
      const price = Number(row['سعر البيع (ج.م)'] || row['سعر البيع'] || row['Price'] || 0);
      const sku = row['كود المنتج (SKU)'] || row['SKU'] || `ZN-${Math.floor(1000 + Math.random() * 9000)}`;

      if (nameAr && price > 0) {
        const existingIdx = currentProducts.findIndex((p) => p.sku === sku);
        const costPrice = Number(row['سعر التكلفة (ج.م)'] || row['التكلفة'] || row['Cost'] || price * 0.5);
        const stock = Number(row['المخزون المتاح'] || row['المخزون'] || row['Stock'] || 10);

        if (existingIdx !== -1) {
          currentProducts[existingIdx].nameAr = nameAr;
          currentProducts[existingIdx].price = price;
          currentProducts[existingIdx].costPrice = costPrice;
          currentProducts[existingIdx].stock = stock;
        } else {
          currentProducts.unshift({
            id: `prod-${Date.now()}-${importedCount}`,
            sku,
            name: row['اسم المنتج بالإنجليزي'] || nameAr,
            nameAr,
            description: row['الوصف'] || '',
            descriptionAr: row['الوصف'] || '',
            price,
            costPrice,
            stock,
            categoryId: 'cat-1',
            categoryName: row['الفئة'] || 'مجوهرات فاخرة',
            images: ['https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80'],
            status: 'active',
            rating: 5.0,
            reviewsCount: 1,
            createdAt: new Date().toISOString(),
          });
        }
        importedCount++;
      }
    });

    setStorage(STORAGE_KEYS.PRODUCTS, currentProducts);
    return {
      success: true,
      message: `تم استيراد وتحديث ${importedCount} منتج بنجاح من ملف الإكسيل!`,
      count: importedCount,
    };
  } catch (err: any) {
    return { success: false, message: `خطأ أثناء قراءة ملف الإكسيل: ${err.message}` };
  }
}

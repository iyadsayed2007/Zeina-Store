import {
  Product,
  Category,
  Order,
  PurchaseInvoice,
  DiscountCoupon,
  Review,
  Banner,
  StoreSettings,
  User,
  BackupData,
} from '../types';

const TOKEN_KEY = 'zeina_session_token';

export function getAuthToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setAuthToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch (err) {
    console.error('Failed to save auth token:', err);
  }
}

export function clearAuthToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch (err) {
    console.error('Failed to remove auth token:', err);
  }
}

function getHeaders(isJson = true): Record<string, string> {
  const headers: Record<string, string> = {};
  if (isJson) {
    headers['Content-Type'] = 'application/json';
  }
  const token = getAuthToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

// ---------------------------------------------
// Core Data Hydration
// ---------------------------------------------
export interface ServerDataPayload {
  products: Product[];
  categories: Category[];
  orders: Order[];
  purchases: PurchaseInvoice[];
  discounts: DiscountCoupon[];
  reviews: Review[];
  banners: Banner[];
  settings: StoreSettings;
  users: User[];
}

export async function fetchServerData(): Promise<ServerDataPayload | null> {
  try {
    const res = await fetch('/api/data', {
      headers: getHeaders(false),
    });
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[Zeina API] Could not fetch data from server, falling back to local storage:', err);
    return null;
  }
}

// ---------------------------------------------
// Server Authentication
// ---------------------------------------------
export interface LoginResponse {
  success: boolean;
  user?: User;
  token?: string;
  error?: string;
  isLocked?: boolean;
}

export async function loginApi(email: string, pass: string): Promise<LoginResponse> {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: pass }),
    });
    const data = await res.json();
    if (res.ok && data.success && data.token) {
      setAuthToken(data.token);
    }
    return data;
  } catch (err) {
    return { success: false, error: 'تعذر الاتصال بخادم المتجر. يرجى التحقق من اتصال الإنترنت.' };
  }
}

export async function validateSessionApi(): Promise<User | null> {
  const token = getAuthToken();
  if (!token) return null;

  try {
    const res = await fetch('/api/auth/me', {
      headers: getHeaders(false),
    });
    if (!res.ok) {
      clearAuthToken();
      return null;
    }
    const data = await res.json();
    if (data.success && data.user) {
      return data.user;
    }
    clearAuthToken();
    return null;
  } catch {
    return null;
  }
}

export async function logoutApi(): Promise<void> {
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: getHeaders(false),
    });
  } catch {
    // Ignore
  } finally {
    clearAuthToken();
  }
}

export async function updateAdminCredentialsApi(
  currentPassword: string,
  newEmail?: string,
  newPassword?: string
): Promise<{ success: boolean; message?: string; error?: string; requireRelogin?: boolean; updatedEmail?: string }> {
  try {
    const res = await fetch('/api/auth/update-admin', {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify({ currentPassword, newEmail, newPassword }),
    });
    return await res.json();
  } catch (err) {
    return { success: false, error: 'حدث خطأ أثناء الاتصال بالخادم لتحديث البيانات' };
  }
}

// ---------------------------------------------
// Settings & Logo Upload
// ---------------------------------------------
export async function saveSettingsApi(settings: Partial<StoreSettings>): Promise<boolean> {
  try {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: getHeaders(true),
      body: JSON.stringify(settings),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function uploadLogoApi(logoUrl: string): Promise<boolean> {
  try {
    const res = await fetch('/api/upload-logo', {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify({ logoUrl }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ---------------------------------------------
// Products API
// ---------------------------------------------
export async function saveProductApi(product: Product): Promise<Product | null> {
  try {
    const isEdit = Boolean(product.id);
    const url = isEdit ? `/api/products/${product.id}` : '/api/products';
    const method = isEdit ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: getHeaders(true),
      body: JSON.stringify(product),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.product;
  } catch {
    return null;
  }
}

export async function deleteProductApi(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/products/${id}`, {
      method: 'DELETE',
      headers: getHeaders(false),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ---------------------------------------------
// Categories API
// ---------------------------------------------
export async function saveCategoryApi(category: Category): Promise<Category | null> {
  try {
    const isEdit = Boolean(category.id);
    const url = isEdit ? `/api/categories/${category.id}` : '/api/categories';
    const method = isEdit ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: getHeaders(true),
      body: JSON.stringify(category),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.category;
  } catch {
    return null;
  }
}

export async function deleteCategoryApi(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/categories/${id}`, {
      method: 'DELETE',
      headers: getHeaders(false),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ---------------------------------------------
// Orders API
// ---------------------------------------------
export async function createOrderApi(order: Order): Promise<Order | null> {
  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify(order),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.order;
  } catch {
    return null;
  }
}

export async function updateOrderApi(id: string, updates: Partial<Order>): Promise<Order | null> {
  try {
    const res = await fetch(`/api/orders/${id}`, {
      method: 'PUT',
      headers: getHeaders(true),
      body: JSON.stringify(updates),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.order;
  } catch {
    return null;
  }
}

// ---------------------------------------------
// Purchases API
// ---------------------------------------------
export async function savePurchaseApi(purchase: PurchaseInvoice): Promise<PurchaseInvoice | null> {
  try {
    const res = await fetch('/api/purchases', {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify(purchase),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.purchase;
  } catch {
    return null;
  }
}

export async function deletePurchaseApi(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/purchases/${id}`, {
      method: 'DELETE',
      headers: getHeaders(false),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ---------------------------------------------
// Discounts API
// ---------------------------------------------
export async function saveDiscountApi(coupon: DiscountCoupon): Promise<DiscountCoupon | null> {
  try {
    const isEdit = Boolean(coupon.id);
    const url = isEdit ? `/api/coupons/${coupon.id}` : '/api/coupons';
    const method = isEdit ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: getHeaders(true),
      body: JSON.stringify(coupon),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.coupon;
  } catch {
    return null;
  }
}

export async function deleteDiscountApi(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/coupons/${id}`, {
      method: 'DELETE',
      headers: getHeaders(false),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ---------------------------------------------
// Reviews API
// ---------------------------------------------
export async function addReviewApi(review: Review): Promise<Review | null> {
  try {
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify(review),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.review;
  } catch {
    return null;
  }
}

export async function updateReviewApi(id: string, updates: Partial<Review>): Promise<Review | null> {
  try {
    const res = await fetch(`/api/reviews/${id}`, {
      method: 'PUT',
      headers: getHeaders(true),
      body: JSON.stringify(updates),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.review;
  } catch {
    return null;
  }
}

export async function deleteReviewApi(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/reviews/${id}`, {
      method: 'DELETE',
      headers: getHeaders(false),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ---------------------------------------------
// Banners API
// ---------------------------------------------
export async function saveBannerApi(banner: Banner): Promise<Banner | null> {
  try {
    const isEdit = Boolean(banner.id);
    const url = isEdit ? `/api/banners/${banner.id}` : '/api/banners';
    const method = isEdit ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: getHeaders(true),
      body: JSON.stringify(banner),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.banner;
  } catch {
    return null;
  }
}

export async function deleteBannerApi(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/banners/${id}`, {
      method: 'DELETE',
      headers: getHeaders(false),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ---------------------------------------------
// Staff & Users API (Staff Management)
// ---------------------------------------------
export async function fetchUsersApi(): Promise<User[]> {
  try {
    const res = await fetch('/api/users', {
      headers: getHeaders(false),
    });
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
}

export async function createStaffApi(userData: {
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'staff' | 'customer';
  phone?: string;
  address?: string;
  city?: string;
}): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify(userData),
    });
    return await res.json();
  } catch {
    return { success: false, error: 'حدث خطأ أثناء الاتصال بالخادم لإنشاء الموظف' };
  }
}

export async function updateUserApi(
  id: string,
  userData: Partial<User> & { newPassword?: string }
): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const res = await fetch(`/api/users/${id}`, {
      method: 'PUT',
      headers: getHeaders(true),
      body: JSON.stringify(userData),
    });
    return await res.json();
  } catch {
    return { success: false, error: 'حدث خطأ أثناء تحديث بيانات المستخدم' };
  }
}

export async function deleteUserApi(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetch(`/api/users/${id}`, {
      method: 'DELETE',
      headers: getHeaders(false),
    });
    return await res.json();
  } catch {
    return { success: false, error: 'حدث خطأ أثناء حذف المستخدم' };
  }
}

// ---------------------------------------------
// Backup & Factory Reset API
// ---------------------------------------------
export async function resetDatabaseApi(): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/reset-data', {
      method: 'POST',
      headers: getHeaders(false),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function restoreBackupApi(backup: BackupData): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/restore-data', {
      method: 'POST',
      headers: getHeaders(true),
      body: JSON.stringify(backup),
    });
    return res.ok;
  } catch {
    return false;
  }
}

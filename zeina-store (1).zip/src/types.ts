export type Role = 'admin' | 'staff' | 'customer';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: Role;
  phone?: string;
  address?: string;
  city?: string;
  createdAt: string;
  status?: 'active' | 'inactive';
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  price: number;
  costPrice: number;
  stock: number;
  categoryId: string;
  categoryName?: string;
  images: string[];
  status: 'active' | 'draft' | 'archived';
  rating: number;
  reviewsCount: number;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  colors?: string[];
  material?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  nameAr: string;
  slug: string;
  iconName: string;
  image: string;
  itemCount: number;
}

export interface OrderItem {
  productId: string;
  name: string;
  nameAr: string;
  price: number;
  costPrice: number;
  quantity: number;
  image: string;
  selectedColor?: string;
}

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  orderNumber: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  city: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  discountCode?: string;
  shippingFee: number;
  tax: number;
  total: number;
  totalAmount?: number;
  status: OrderStatus;
  paymentMethod: 'cod' | 'card' | 'instapay' | 'vodafone_cash';
  paymentStatus: 'paid' | 'pending';
  notes?: string;
  createdAt: string;
  deliveredAt?: string;
}

export interface PurchaseItem {
  productId: string;
  productName: string;
  costPrice: number;
  quantity: number;
  total: number;
}

export interface PurchaseInvoice {
  id: string;
  invoiceNumber: string;
  supplierName: string;
  supplierPhone: string;
  supplierTaxId?: string;
  items: PurchaseItem[];
  totalAmount: number;
  notes?: string;
  date: string;
  status: 'received' | 'pending';
  createdAt: string;
}

export interface DiscountCoupon {
  id: string;
  code: string;
  description: string;
  type: 'percent' | 'fixed';
  value: number;
  minOrder: number;
  validUntil: string;
  isActive: boolean;
  usageCount: number;
  usageLimit: number;
}

export interface Review {
  id: string;
  productId: string;
  productName: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  status: 'approved' | 'pending';
}

export interface Banner {
  id: string;
  titleAr: string;
  subtitleAr: string;
  tagAr: string;
  titleEn: string;
  subtitleEn: string;
  ctaTextAr: string;
  ctaLink: string;
  image: string;
  badge?: string;
  active: boolean;
  order: number;
}

export interface PaymentMethodsConfig {
  cod: boolean;
  card: boolean;
  instapay: boolean;
  vodafone_cash: boolean;
  wallets?: boolean;
}

export interface StoreSettings {
  storeName: string;
  storeNameAr: string;
  storeNameEn?: string;
  storeDescriptionAr?: string;
  storeDescriptionEn?: string;
  logoUrl?: string;
  faviconUrl?: string;
  taxNumber: string;
  commercialRecord: string;
  phone: string;
  whatsapp?: string;
  email: string;
  address: string;
  city: string;
  currency: string;
  currencySymbol: string;
  shippingFeeFlat: number;
  freeShippingThreshold: number;
  taxPercentage: number;
  vatPercentage?: number;
  instagramUrl: string;
  facebookUrl: string;
  whatsappNumber: string;
  tiktokUrl?: string;
  snapchatUrl?: string;
  returnPolicyAr?: string;
  privacyPolicyAr?: string;
  termsOfServiceAr?: string;
  paymentMethods?: PaymentMethodsConfig;
}

export interface BackupData {
  version: string;
  timestamp: string;
  storeName: string;
  users: User[];
  products: Product[];
  categories: Category[];
  orders: Order[];
  purchases: PurchaseInvoice[];
  discounts: DiscountCoupon[];
  reviews: Review[];
  banners: Banner[];
  settings: StoreSettings;
}

import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Order, PurchaseInvoice, StoreSettings } from '../types';

/**
 * Generates an SVG string representation of the official Zeina Store logo
 * for inclusion in high-resolution PDF exports and printable documents.
 */
function getLogoSvgString(): string {
  return `
    <svg viewBox="0 0 540 320" width="160" height="95" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="roseGradPdf" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#DF9EA8" />
          <stop offset="60%" stop-color="#C47B86" />
          <stop offset="100%" stop-color="#B36974" />
        </linearGradient>
        <linearGradient id="ribbonGradPdf" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#F5D8DC" stop-opacity="0.9" />
          <stop offset="100%" stop-color="#C47B86" stop-opacity="0.7" />
        </linearGradient>
      </defs>
      <g transform="translate(20, -40)">
        <path d="M 172 130 C 172 65, 218 52, 238 52 C 258 52, 280 65, 280 130" stroke="url(#roseGradPdf)" stroke-width="9" stroke-linecap="round" fill="none" />
        <circle cx="172" cy="132" r="6.5" fill="#C47B86" />
        <circle cx="280" cy="132" r="6.5" fill="#C47B86" />
        <path d="M 125 255 L 160 130 L 320 130 L 345 255" stroke="url(#roseGradPdf)" stroke-width="8.5" stroke-linecap="round" stroke-linejoin="round" fill="none" />
        <path d="M 125 255 L 144 145 L 160 130 L 142 245 Z" fill="url(#ribbonGradPdf)" />
        <path d="M 125 255 C 135 264, 150 266, 160 262 L 155 248 Z" fill="#D898A2" />
        <g>
          <path d="M 152 150 L 260 150 L 260 164 C 238 165, 222 168, 208 177 L 168 234 L 272 234 L 284 252 L 152 252 L 152 238 C 174 237, 190 233, 202 225 L 240 170 L 165 170 L 152 150 Z" fill="#2B211D" />
          <text x="262" y="253" font-family="'Playfair Display', serif" font-size="106" font-weight="800" fill="#2B211D" letter-spacing="-2">eina</text>
          <g transform="translate(338, 178) scale(0.95)">
            <path d="M 0 4.5 C -7 -7, -18 2, 0 18 C 18 2, 7 -7, 0 4.5 Z" fill="#C47B86" />
          </g>
        </g>
        <g>
          <line x1="88" y1="305" x2="170" y2="305" stroke="#C47B86" stroke-width="2.5" stroke-linecap="round" />
          <text x="250" y="312" font-family="'Plus Jakarta Sans', sans-serif" font-size="22" font-weight="700" fill="#2B211D" letter-spacing="9" text-anchor="middle">STORE</text>
          <line x1="330" y1="305" x2="412" y2="305" stroke="#C47B86" stroke-width="2.5" stroke-linecap="round" />
        </g>
      </g>
    </svg>
  `;
}

function renderInvoiceLogo(settings: StoreSettings): string {
  if (settings.logoUrl && settings.logoUrl.trim() !== '') {
    return `
      <div style="margin-bottom: 8px;">
        <img src="${settings.logoUrl}" style="max-height: 75px; max-width: 220px; object-fit: contain;" alt="Logo" />
      </div>
    `;
  }
  return `
    <div style="margin-bottom: 8px;">
      ${getLogoSvgString()}
    </div>
  `;
}

/**
 * Translates payment method codes into clear Arabic terms.
 */
function getPaymentMethodAr(method: string): string {
  switch (method) {
    case 'cod':
      return 'الدفع عند الاستلام (COD)';
    case 'card':
      return 'بطاقة بنكية / فيزا / ماستركارد';
    case 'instapay':
      return 'تحويل إنستاباي (InstaPay)';
    case 'wallet':
      return 'محفظة إلكترونية (فودافون كاش)';
    default:
      return method;
  }
}

/**
 * Builds HTML template for sales invoices with native Arabic RTL support,
 * proper Cairo font rendering, correct BiDi, and no character distortion.
 */
function buildSalesInvoiceHtml(order: Order, settings: StoreSettings): string {
  const dateStr = new Date(order.createdAt).toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const itemsHtml = order.items
    .map((item, idx) => {
      const unitPrice = (item.price ?? 0).toLocaleString();
      const lineTotal = ((item.price ?? 0) * (item.quantity ?? 1)).toLocaleString();
      const primaryName = item.nameAr || item.name;
      const secondaryName = item.nameAr && item.name !== item.nameAr ? item.name : '';

      return `
      <tr style="border-bottom: 1px solid #D8CBBE; ${idx % 2 === 1 ? 'background-color: rgba(232, 221, 208, 0.25);' : ''}">
        <td style="padding: 10px 14px; font-size: 12px; color: #7A6A60; text-align: center;">${idx + 1}</td>
        <td style="padding: 10px 14px; text-align: right;">
          <div style="font-weight: 700; font-size: 13px; color: #2B211D; line-height: 1.4;">${primaryName}</div>
          ${secondaryName ? `<div style="font-size: 11px; color: #7A6A60; font-family: 'Plus Jakarta Sans', sans-serif;">${secondaryName}</div>` : ''}
          ${item.selectedColor ? `<div style="font-size: 11px; color: #B76E79; margin-top: 2px;">اللون: ${item.selectedColor}</div>` : ''}
        </td>
        <td style="padding: 10px 14px; font-size: 13px; font-weight: 700; text-align: center; color: #2B211D;">${item.quantity}</td>
        <td style="padding: 10px 14px; font-size: 12px; color: #2B211D; text-align: left; white-space: nowrap;">${unitPrice} ج.م</td>
        <td style="padding: 10px 14px; font-size: 13px; font-weight: 700; color: #2B211D; text-align: left; white-space: nowrap;">${lineTotal} ج.م</td>
      </tr>
    `;
    })
    .join('');

  return `
    <div style="width: 794px; min-height: 1120px; box-sizing: border-box; padding: 40px; background-color: #F7F1E8; color: #2B211D; font-family: 'Cairo', 'Plus Jakarta Sans', sans-serif; direction: rtl; text-align: right; position: relative;">
      
      <!-- Top Luxury Header Bar -->
      <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #D8CBBE; padding-bottom: 24px; margin-bottom: 24px;">
        <div style="text-align: right;">
          ${renderInvoiceLogo(settings)}
          <div style="font-size: 13px; font-weight: 700; color: #2B211D;">${settings.storeNameAr || 'متجر زينة للإكسسوارات الفاخرة'}</div>
          <div style="font-size: 11px; color: #7A6A60; margin-top: 3px;">
            سجل تجاري: <span style="font-family: monospace;">${settings.commercialRecord}</span> | بطاقة ضريبية: <span style="font-family: monospace;">${settings.taxNumber}</span>
          </div>
          <div style="font-size: 11px; color: #7A6A60;">
            العنوان: ${settings.address} — هاتف: <span style="font-family: monospace;">${settings.phone}</span>
          </div>
        </div>

        <div style="text-align: left; direction: ltr;">
          <div style="display: inline-block; background-color: #2B211D; color: #F7F1E8; font-size: 11px; font-weight: 700; padding: 4px 12px; border-radius: 6px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;">
            OFFICIAL SALES INVOICE
          </div>
          <div style="font-size: 20px; font-weight: 800; font-family: 'Playfair Display', serif; color: #2B211D;">
            #${order.invoiceNumber}
          </div>
          <div style="font-size: 12px; color: #7A6A60; margin-top: 4px;">
            التاريخ: <span style="font-family: 'Cairo', sans-serif;">${dateStr}</span>
          </div>
          <div style="font-size: 12px; color: #7A6A60;">
            رقم الطلب: <span style="font-family: monospace; font-weight: 700; color: #B99A68;">${order.orderNumber}</span>
          </div>
        </div>
      </div>

      <!-- Parties Details (Billed To / Store Details) -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px;">
        <div style="background-color: rgba(232, 221, 208, 0.55); border: 1px solid #D8CBBE; border-radius: 12px; padding: 16px;">
          <div style="font-size: 11px; font-weight: 800; color: #B99A68; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">
            بيانات العميل المستلم (Billed To)
          </div>
          <div style="font-size: 15px; font-weight: 800; color: #2B211D; margin-bottom: 4px;">
            ${order.customerName}
          </div>
          <div style="font-size: 12px; color: #5C4D44; margin-bottom: 3px;">
            <strong>رقم الهاتف:</strong> <span style="font-family: monospace;">${order.customerPhone}</span>
          </div>
          <div style="font-size: 12px; color: #5C4D44; line-height: 1.5;">
            <strong>العنوان:</strong> ${order.city} — ${order.shippingAddress}
          </div>
          ${order.notes ? `<div style="font-size: 11px; color: #B76E79; margin-top: 6px;"><strong>ملاحظات العميل:</strong> ${order.notes}</div>` : ''}
        </div>

        <div style="background-color: rgba(232, 221, 208, 0.55); border: 1px solid #D8CBBE; border-radius: 12px; padding: 16px;">
          <div style="font-size: 11px; font-weight: 800; color: #B99A68; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">
            بيانات الدفع والتوصيل
          </div>
          <div style="font-size: 13px; color: #2B211D; margin-bottom: 6px;">
            <strong>طريقة السداد:</strong> ${getPaymentMethodAr(order.paymentMethod)}
          </div>
          <div style="font-size: 13px; color: #2B211D; margin-bottom: 6px;">
            <strong>حالة الفاتورة:</strong> 
            <span style="display: inline-block; background-color: ${order.paymentStatus === 'paid' ? '#D1FAE5' : '#FEF3C7'}; color: ${order.paymentStatus === 'paid' ? '#065F46' : '#92400E'}; padding: 2px 8px; border-radius: 6px; font-size: 11px; font-weight: 700;">
              ${order.paymentStatus === 'paid' ? 'تم السداد بالكامل ✓' : 'قيد التحصيل عند الاستلام'}
            </span>
          </div>
          <div style="font-size: 12px; color: #5C4D44;">
            <strong>تجهيز الطلب:</strong> تغليف هدايا فاخر من زينة ستور
          </div>
        </div>
      </div>

      <!-- Items Table -->
      <div style="border: 1px solid #D8CBBE; border-radius: 12px; overflow: hidden; margin-bottom: 24px;">
        <table style="width: 100%; border-collapse: collapse; text-align: right;">
          <thead>
            <tr style="background-color: #2B211D; color: #F7F1E8;">
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; width: 40px; text-align: center;">م</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700;">البيان / تفاصيل المنتج</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; text-align: center; width: 60px;">الكمية</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; text-align: left; width: 110px;">السعر الفردي</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; text-align: left; width: 120px;">الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>
      </div>

      <!-- Financial Calculation Summary -->
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px;">
        <div style="max-width: 380px; font-size: 11px; color: #7A6A60; line-height: 1.6;">
          <div style="font-weight: 700; color: #2B211D; margin-bottom: 4px;">سياسة الاستبدال والضمان:</div>
          <div>• يحق للعميل استبدال أو إرجاع المنتجات خلال 14 يوماً من تاريخ الاستلام في حالتها الأصلية.</div>
          <div>• قطع المجوهرات المطلية خاضعة لضمان زينة ستور ضد عيوب الصناعة.</div>
          <div>• للاستفسارات وخدمة ما بعد البيع: يرجى التواصل عبر واتساب على الرقم ${settings.phone}.</div>
        </div>

        <div style="width: 320px; background-color: rgba(232, 221, 208, 0.55); border: 1px solid #D8CBBE; border-radius: 12px; padding: 14px 18px;">
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 6px; color: #5C4D44;">
            <span>المجموع الفرعي:</span>
            <span style="font-weight: 700; color: #2B211D;">${(order.subtotal ?? 0).toLocaleString()} ج.م</span>
          </div>

          ${
            order.discount && order.discount > 0
              ? `
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 6px; color: #B76E79;">
            <span>الخصم المطبق (${order.discountCode || 'كود خصم'}):</span>
            <span style="font-weight: 700;">-${order.discount.toLocaleString()} ج.م</span>
          </div>
          `
              : ''
          }

          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 6px; color: #5C4D44;">
            <span>تكلفة الشحن والتوصيل:</span>
            <span style="font-weight: 700; color: #2B211D;">
              ${order.shippingFee === 0 ? 'شحن مجاني' : `${(order.shippingFee ?? 0).toLocaleString()} ج.م`}
            </span>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 8px; color: #7A6A60;">
            <span>ضريبة القيمة المضافة:</span>
            <span>مشمولة بالسعر</span>
          </div>

          <div style="border-top: 2px solid #D8CBBE; padding-top: 8px; display: flex; justify-content: space-between; align-items: baseline;">
            <span style="font-size: 14px; font-weight: 800; color: #2B211D;">صافي الفاتورة الإجمالي:</span>
            <span style="font-size: 18px; font-weight: 800; color: #B99A68;">
              ${(order.total ?? 0).toLocaleString()} ج.م
            </span>
          </div>
        </div>
      </div>

      <!-- Legal & Authentication Footer -->
      ${
        settings.returnPolicyAr
          ? `
      <div style="margin-top: 20px; padding: 10px 14px; background-color: rgba(232, 221, 208, 0.45); border: 1px dashed #D8CBBE; border-radius: 8px; font-size: 10px; color: #5C4D44; line-height: 1.6;">
        <span style="font-weight: 800; color: #2B211D;">سياسة الاسترجاع والاستبدال المعتمدة:</span> ${settings.returnPolicyAr}
      </div>
      `
          : ''
      }

      <div style="border-top: 1px dashed #D8CBBE; padding-top: 16px; text-align: center; font-size: 10px; color: #7A6A60; margin-top: 20px;">
        <div>فاتورة إلكترونية معتمدة صادرة آلياً عن نظام ${settings.storeNameAr || 'متجر زينة ستور'} — لا تحتاج لتوقيع يدوي.</div>
        <div style="margin-top: 2px;">شكراً لاختياركم زينة ستور للمجوهرات الفاخرة | www.zeinastore.com</div>
      </div>
    </div>
  `;
}

/**
 * Builds HTML template for purchase / supplier invoices.
 */
function buildPurchaseInvoiceHtml(purchase: PurchaseInvoice, settings: StoreSettings): string {
  const itemsHtml = purchase.items
    .map((item, idx) => {
      const unitCost = (item.costPrice ?? 0).toLocaleString();
      const lineTotal = ((item.costPrice ?? 0) * (item.quantity ?? 1)).toLocaleString();

      return `
      <tr style="border-bottom: 1px solid #D8CBBE; ${idx % 2 === 1 ? 'background-color: rgba(232, 221, 208, 0.25);' : ''}">
        <td style="padding: 10px 14px; font-size: 12px; color: #7A6A60; text-align: center;">${idx + 1}</td>
        <td style="padding: 10px 14px; text-align: right;">
          <div style="font-weight: 700; font-size: 13px; color: #2B211D;">${item.productName}</div>
        </td>
        <td style="padding: 10px 14px; font-size: 13px; font-weight: 700; text-align: center; color: #2B211D;">${item.quantity}</td>
        <td style="padding: 10px 14px; font-size: 12px; color: #2B211D; text-align: left;">${unitCost} ج.م</td>
        <td style="padding: 10px 14px; font-size: 13px; font-weight: 700; color: #2B211D; text-align: left;">${lineTotal} ج.م</td>
      </tr>
    `;
    })
    .join('');

  return `
    <div style="width: 794px; min-height: 1120px; box-sizing: border-box; padding: 40px; background-color: #F7F1E8; color: #2B211D; font-family: 'Cairo', 'Plus Jakarta Sans', sans-serif; direction: rtl; text-align: right;">
      <!-- Top Luxury Header Bar -->
      <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #D8CBBE; padding-bottom: 24px; margin-bottom: 24px;">
        <div>
          ${renderInvoiceLogo(settings)}
          <div style="font-size: 13px; font-weight: 700; color: #2B211D; margin-top: 8px;">${settings.storeNameAr || 'متجر زينة للإكسسوارات الفاخرة'}</div>
          <div style="font-size: 11px; color: #7A6A60; margin-top: 3px;">
            سجل تجاري: <span style="font-family: monospace;">${settings.commercialRecord}</span> | بطاقة ضريبية: <span style="font-family: monospace;">${settings.taxNumber}</span>
          </div>
        </div>

        <div style="text-align: left; direction: ltr;">
          <div style="display: inline-block; background-color: #2B211D; color: #F7F1E8; font-size: 11px; font-weight: 700; padding: 4px 12px; border-radius: 6px; text-transform: uppercase;">
            PURCHASE & SUPPLY INVOICE
          </div>
          <div style="font-size: 20px; font-weight: 800; font-family: 'Playfair Display', serif; color: #2B211D; margin-top: 4px;">
            #${purchase.invoiceNumber}
          </div>
          <div style="font-size: 12px; color: #7A6A60; margin-top: 4px;">
            تاريخ التوريد: <span style="font-family: 'Cairo', sans-serif;">${purchase.date}</span>
          </div>
        </div>
      </div>

      <!-- Supplier Info -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px;">
        <div style="background-color: rgba(232, 221, 208, 0.55); border: 1px solid #D8CBBE; border-radius: 12px; padding: 16px;">
          <div style="font-size: 11px; font-weight: 800; color: #B99A68; text-transform: uppercase; margin-bottom: 6px;">
            بيانات المورّد / جهة التوريد
          </div>
          <div style="font-size: 15px; font-weight: 800; color: #2B211D; margin-bottom: 4px;">
            ${purchase.supplierName}
          </div>
          <div style="font-size: 12px; color: #5C4D44; margin-bottom: 3px;">
            الهاتف: <span style="font-family: monospace;">${purchase.supplierPhone}</span>
          </div>
          ${purchase.supplierTaxId ? `<div style="font-size: 12px; color: #5C4D44;">الرقم الضريبي للمورد: <span style="font-family: monospace;">${purchase.supplierTaxId}</span></div>` : ''}
        </div>

        <div style="background-color: rgba(232, 221, 208, 0.55); border: 1px solid #D8CBBE; border-radius: 12px; padding: 16px;">
          <div style="font-size: 11px; font-weight: 800; color: #B99A68; text-transform: uppercase; margin-bottom: 6px;">
            حالة استلام المخزون والتوريد
          </div>
          <div style="font-size: 13px; color: #2B211D; margin-bottom: 6px;">
            <strong>حالة التوريد:</strong> 
            <span style="display: inline-block; background-color: ${purchase.status === 'received' ? '#D1FAE5' : '#FEF3C7'}; color: ${purchase.status === 'received' ? '#065F46' : '#92400E'}; padding: 2px 8px; border-radius: 6px; font-size: 11px; font-weight: 700;">
              ${purchase.status === 'received' ? 'تم الاستلام والفحص ✓' : 'قيد التوريد والشحن'}
            </span>
          </div>
          <div style="font-size: 13px; color: #2B211D;">
            <strong>تاريخ التوريد:</strong> ${new Date(purchase.date || purchase.createdAt).toLocaleDateString('ar-EG')}
          </div>
        </div>
      </div>

      <!-- Items Table -->
      <div style="border: 1px solid #D8CBBE; border-radius: 12px; overflow: hidden; margin-bottom: 24px;">
        <table style="width: 100%; border-collapse: collapse; text-align: right;">
          <thead>
            <tr style="background-color: #2B211D; color: #F7F1E8;">
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; width: 40px; text-align: center;">م</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700;">الصنف المورّد</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; text-align: center; width: 60px;">الكمية</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; text-align: left; width: 110px;">سعر التكلفة</th>
              <th style="padding: 10px 14px; font-size: 12px; font-weight: 700; text-align: left; width: 120px;">الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>
      </div>

      <!-- Total Cost -->
      <div style="display: flex; justify-content: flex-end; margin-bottom: 24px;">
        <div style="width: 320px; background-color: rgba(232, 221, 208, 0.55); border: 1px solid #D8CBBE; border-radius: 12px; padding: 14px 18px;">
          <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 8px; color: #5C4D44;">
            <span>عدد الأصناف المورّدة:</span>
            <span style="font-weight: 700; color: #2B211D;">${purchase.items.length} أصناف</span>
          </div>
          <div style="border-top: 2px solid #D8CBBE; padding-top: 8px; display: flex; justify-content: space-between; align-items: baseline;">
            <span style="font-size: 14px; font-weight: 800; color: #2B211D;">إجمالي فاتورة المشتريات:</span>
            <span style="font-size: 18px; font-weight: 800; color: #B99A68;">
              ${(purchase.totalAmount ?? 0).toLocaleString()} ج.م
            </span>
          </div>
        </div>
      </div>

      <div style="border-top: 1px dashed #D8CBBE; padding-top: 16px; text-align: center; font-size: 10px; color: #7A6A60; margin-top: 30px;">
        <div>فاتورة توريد ومشتريات داخلية مسجلة بنظام المخازن لمتجر زينة للمجوهرات الفاخرة.</div>
      </div>
    </div>
  `;
}

/**
 * Core PDF export function using high-resolution HTML-to-Canvas rendering.
 * Guarantees 100% proper Arabic BiDi, font glyph rendering, no character corruption,
 * and high vector-like clarity.
 */
async function generatePdfFromHtml(htmlContent: string, filename: string): Promise<void> {
  // 1. Create a container element positioned off-screen
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.left = '-9999px';
  container.style.top = '0';
  container.style.width = '794px';
  container.style.zIndex = '-1000';
  container.innerHTML = htmlContent;
  document.body.appendChild(container);

  try {
    // 2. Wait for fonts to be completely ready
    if (document.fonts && document.fonts.ready) {
      await document.fonts.ready;
    }

    // 3. Small microtask tick for DOM & SVG rendering
    await new Promise((resolve) => setTimeout(resolve, 150));

    // 4. Render to high-DPI canvas
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#F7F1E8',
      windowWidth: 1024,
    });

    // 5. Convert to PDF
    const imgData = canvas.toDataURL('image/jpeg', 0.98);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = 210; // A4 width in mm
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, Math.min(297, pdfHeight));
    pdf.save(filename);
  } finally {
    // 6. Clean up temporary container
    if (container.parentNode) {
      container.parentNode.removeChild(container);
    }
  }
}

/**
 * Export Sales Invoice as PDF with flawless Arabic text rendering.
 */
export async function exportSalesInvoicePDF(order: Order, settings: StoreSettings): Promise<void> {
  const html = buildSalesInvoiceHtml(order, settings);
  const filename = `Zeina_Store_Invoice_${order.invoiceNumber}.pdf`;
  await generatePdfFromHtml(html, filename);
}

/**
 * Export Purchase Invoice as PDF with flawless Arabic text rendering.
 */
export async function exportPurchaseInvoicePDF(purchase: PurchaseInvoice, settings: StoreSettings): Promise<void> {
  const html = buildPurchaseInvoiceHtml(purchase, settings);
  const filename = `Zeina_Store_Purchase_${purchase.invoiceNumber}.pdf`;
  await generatePdfFromHtml(html, filename);
}

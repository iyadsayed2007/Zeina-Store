/**
 * Security & Cryptographic Utilities for Zeina Store
 * Implements NIST-compliant PBKDF2 password hashing with unique random salts,
 * brute-force rate-limiting, and secure session management.
 */

const PBKDF2_ITERATIONS = 100000;
const HASH_ALGO = 'SHA-256';
const KEY_LENGTH_BITS = 256;
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes

const SECURITY_STORAGE_KEYS = {
  FAILED_ATTEMPTS: 'zn_admin_failed_attempts',
  LOCKOUT_UNTIL: 'zn_admin_lockout_until',
  ADMIN_SESSION: 'zn_admin_session_token',
};

// Convert Uint8Array to Hex string
function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

// Convert Hex string to Uint8Array
function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

/**
 * Hashes a plain-text password using PBKDF2 with SHA-256 and a 16-byte random salt.
 * Returns format: "pbkdf2:100000:<saltHex>:<hashHex>"
 */
export async function hashPassword(password: string, customSaltHex?: string): Promise<string> {
  const encoder = new TextEncoder();
  const salt = customSaltHex
    ? hexToBytes(customSaltHex)
    : crypto.getRandomValues(new Uint8Array(16));

  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: PBKDF2_ITERATIONS,
      hash: HASH_ALGO,
    },
    keyMaterial,
    KEY_LENGTH_BITS
  );

  const hashHex = bytesToHex(new Uint8Array(derivedBits));
  const saltHex = bytesToHex(salt);

  return `pbkdf2:${PBKDF2_ITERATIONS}:${saltHex}:${hashHex}`;
}

/**
 * Verifies a plain-text password against a stored PBKDF2 hash.
 */
export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  if (!storedHash || typeof storedHash !== 'string') return false;

  // Support PBKDF2 hashes
  if (storedHash.startsWith('pbkdf2:')) {
    const parts = storedHash.split(':');
    if (parts.length !== 4) return false;
    const saltHex = parts[2];
    const expectedHashHex = parts[3];

    const computed = await hashPassword(password, saltHex);
    const computedParts = computed.split(':');
    return computedParts[3] === expectedHashHex;
  }

  // Fallback for initial unmigrated accounts (will be migrated automatically on first check)
  return false;
}

/**
 * Rate Limiting & Account Lockout Enforcement
 */
export function checkAccountLockout(): { isLocked: boolean; remainingMinutes: number } {
  try {
    const lockoutUntilStr = localStorage.getItem(SECURITY_STORAGE_KEYS.LOCKOUT_UNTIL);
    if (lockoutUntilStr) {
      const lockoutUntil = parseInt(lockoutUntilStr, 10);
      const now = Date.now();
      if (now < lockoutUntil) {
        const remainingMinutes = Math.ceil((lockoutUntil - now) / 60000);
        return { isLocked: true, remainingMinutes };
      } else {
        // Lockout expired, clear it
        localStorage.removeItem(SECURITY_STORAGE_KEYS.LOCKOUT_UNTIL);
        localStorage.removeItem(SECURITY_STORAGE_KEYS.FAILED_ATTEMPTS);
      }
    }
  } catch {}
  return { isLocked: false, remainingMinutes: 0 };
}

export function recordFailedLoginAttempt(): { isNowLocked: boolean; remainingAttempts: number } {
  try {
    const current = parseInt(localStorage.getItem(SECURITY_STORAGE_KEYS.FAILED_ATTEMPTS) || '0', 10);
    const updated = current + 1;
    localStorage.setItem(SECURITY_STORAGE_KEYS.FAILED_ATTEMPTS, updated.toString());

    if (updated >= MAX_FAILED_ATTEMPTS) {
      const lockUntil = Date.now() + LOCKOUT_DURATION_MS;
      localStorage.setItem(SECURITY_STORAGE_KEYS.LOCKOUT_UNTIL, lockUntil.toString());
      return { isNowLocked: true, remainingAttempts: 0 };
    }
    return { isNowLocked: false, remainingAttempts: MAX_FAILED_ATTEMPTS - updated };
  } catch {
    return { isNowLocked: false, remainingAttempts: 3 };
  }
}

export function resetFailedLoginAttempts(): void {
  try {
    localStorage.removeItem(SECURITY_STORAGE_KEYS.FAILED_ATTEMPTS);
    localStorage.removeItem(SECURITY_STORAGE_KEYS.LOCKOUT_UNTIL);
  } catch {}
}

/**
 * Admin Session Token Management
 */
export interface AdminSession {
  token: string;
  email: string;
  createdAt: number;
  expiresAt: number;
}

const SESSION_VALIDITY_MS = 24 * 60 * 60 * 1000; // 24 hours

export function createAdminSession(email: string): string {
  const token = `zn_sess_${Date.now()}_${crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '') : Math.random().toString(36).substring(2)}`;
  const session: AdminSession = {
    token,
    email,
    createdAt: Date.now(),
    expiresAt: Date.now() + SESSION_VALIDITY_MS,
  };
  try {
    localStorage.setItem(SECURITY_STORAGE_KEYS.ADMIN_SESSION, JSON.stringify(session));
  } catch {}
  return token;
}

export function validateAdminSession(): boolean {
  try {
    const sessionStr = localStorage.getItem(SECURITY_STORAGE_KEYS.ADMIN_SESSION);
    if (!sessionStr) return false;
    const session: AdminSession = JSON.parse(sessionStr);
    if (!session || !session.token || !session.expiresAt) return false;
    if (Date.now() > session.expiresAt) {
      clearAdminSession();
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function clearAdminSession(): void {
  try {
    localStorage.removeItem(SECURITY_STORAGE_KEYS.ADMIN_SESSION);
  } catch {}
}

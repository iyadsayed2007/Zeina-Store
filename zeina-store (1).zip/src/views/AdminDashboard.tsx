import React, { useState, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { Logo } from '../components/Logo';
import { AdminAccountSecurity } from '../components/AdminAccountSecurity';
import { AdminSettingsManager } from '../components/AdminSettingsManager';
import { AdminStaffManager } from '../components/AdminStaffManager';
import { Product, Order, PurchaseInvoice, DiscountCoupon, Category, Review, Banner } from '../types';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  TrendingUp,
  FileSpreadsheet,
  FileText,
  Plus,
  Edit2,
  Trash2,
  Eye,
  Download,
  Upload,
  Search,
  CheckCircle2,
  XCircle,
  Tag,
  FolderTree,
  Users,
  UserCheck,
  Settings as SettingsIcon,
  Layers,
  Sparkles,
  ArrowUpRight,
  Database,
  RefreshCw,
  Clock,
  Store,
  MessageSquare,
  Image,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    products,
    categories,
    orders,
    purchases,
    discounts,
    reviews,
    banners,
    settings,
    currentUser,
    saveProductAction,
    deleteProductAction,
    updateOrderStatusAction,
    createPurchaseAction,
    saveCategoryAction,
    deleteCategoryAction,
    saveDiscountAction,
    deleteDiscountAction,
    updateReviewStatusAction,
    deleteReviewAction,
    saveBannerAction,
    updateSettingsAction,
    exportBackup,
    restoreBackup,
    resetDatabaseToDefault,
    exportProductsExcel,
    exportOrdersExcel,
    importProductsExcel,
    setPreviewOrder,
    setPreviewPurchase,
    setCurrentView,
    showToast,
  } = useStore();

  const addProduct = (prod: any) => saveProductAction(prod);
  const updateProduct = (id: string, prod: any) => saveProductAction({ ...prod, id });
  const deleteProduct = deleteProductAction;
  const updateOrderStatus = updateOrderStatusAction;
  const addPurchase = createPurchaseAction;
  const addDiscount = (disc: any) => saveDiscountAction(disc);
  const deleteDiscount = deleteDiscountAction;
  const addCategory = (cat: any) => saveCategoryAction(cat);
  const deleteCategory = deleteCategoryAction;
  const updateReviewStatus = updateReviewStatusAction;
  const deleteReview = deleteReviewAction;
  const updateSettings = updateSettingsAction;
  const openInvoice = (id: string, type: 'sale' | 'purchase') => {
    if (type === 'sale') {
      const o = orders.find((x) => x.id === id || x.invoiceNumber === id || x.orderNumber === id);
      if (o) setPreviewOrder(o);
    } else {
      const p = purchases.find((x) => x.id === id || x.invoiceNumber === id);
      if (p) setPreviewPurchase(p);
    }
  };

  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'products'
    | 'orders'
    | 'purchases'
    | 'customers'
    | 'staff'
    | 'categories'
    | 'discounts'
    | 'reviews'
    | 'banners'
    | 'settings'
  >('overview');

  // Search & Filter in Tables
  const [productSearch, setProductSearch] = useState('');
  const [orderSearch, setOrderSearch] = useState('');

  // Modals state
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);

  // File input refs for Excel import & Backup restore
  const excelInputRef = useRef<HTMLInputElement>(null);
  const backupInputRef = useRef<HTMLInputElement>(null);

  // --- Calculations for Overview Analytics ---
  const totalSalesRevenue = orders
    .filter((o) => o.status !== 'cancelled')
    .reduce((sum, o) => sum + (o.total ?? (o as any).totalAmount ?? 0), 0);

  const totalPurchasesCost = purchases.reduce((sum, p) => sum + (p.totalAmount ?? 0), 0);
  const estimatedGrossProfit = totalSalesRevenue - totalPurchasesCost;
  const totalStockCount = products.reduce((sum, p) => sum + (p.stock ?? 0), 0);
  const lowStockCount = products.filter((p) => (p.stock ?? 0) <= 5).length;
  const pendingOrdersCount = orders.filter((o) => o.status === 'pending').length;

  // --- Excel Export Handlers ---
  const handleExportProductsExcel = () => {
    exportProductsExcel();
  };

  const handleExportOrdersExcel = () => {
    exportOrdersExcel();
  };

  const handleImportExcelFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      await importProductsExcel(file);
    } catch (err: any) {
      alert('خطأ أثناء قراءة ملف Excel: ' + err.message);
    } finally {
      if (e.target) e.target.value = '';
    }
  };

  // --- Backup Handlers ---
  const handleBackupDownload = () => {
    exportBackup();
  };

  const handleBackupRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      restoreBackup(content);
    };
    reader.readAsText(file);
    if (e.target) e.target.value = '';
  };

  return (
    <div className="min-h-screen bg-[#E8DDD0]/40 flex flex-col lg:flex-row text-right">
      {/* 1. Admin Sidebar */}
      <aside className="w-full lg:w-72 bg-[#2B211D] text-[#F7F1E8] border-l border-[#3B2D27] flex flex-col shrink-0">
        {/* Logo and Brand Head */}
        <div className="p-6 border-b border-stone-800">
          <Logo variant="dark" size="sm" />
          <div className="mt-3 flex items-center justify-between text-xs text-[#D8C19A]">
            <span className="font-mono bg-[#382B26] px-2 py-0.5 rounded-md">لوحة التحكم الإدارية</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>
        </div>

        {/* Navigation items */}
        <nav className="p-4 space-y-1.5 flex-1 overflow-y-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'overview'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>نظرة عامة والتحليلات</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'products'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <Package className="w-4 h-4" />
              <span>إدارة المنتجات والمخزون</span>
            </div>
            <span className="bg-[#1C1513] text-[#D8C19A] px-2 py-0.5 rounded-full text-[10px] font-mono">
              {products.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'orders'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <ShoppingBag className="w-4 h-4" />
              <span>فواتير وطلبات البيع</span>
            </div>
            {pendingOrdersCount > 0 && (
              <span className="bg-[#B76E79] text-white px-2 py-0.5 rounded-full text-[10px] font-bold">
                {pendingOrdersCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('purchases')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'purchases'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4" />
              <span>المشتريات وتوريد المخزون</span>
            </div>
            <span className="bg-[#1C1513] text-[#D8C19A] px-2 py-0.5 rounded-full text-[10px] font-mono">
              {purchases.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'customers'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>سجل العملاء والمشتريات</span>
          </button>

          <button
            onClick={() => setActiveTab('staff')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'staff'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>فريق العمل والموظفين</span>
          </button>

          <button
            onClick={() => setActiveTab('categories')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'categories'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <FolderTree className="w-4 h-4" />
            <span>الفئات والأقسام</span>
          </button>

          <button
            onClick={() => setActiveTab('discounts')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'discounts'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <Tag className="w-4 h-4" />
            <span>أكواد الخصم والعروض</span>
          </button>

          <button
            onClick={() => setActiveTab('reviews')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'reviews'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <MessageSquare className="w-4 h-4" />
              <span>مراجعات وتقييمات العملاء</span>
            </div>
            <span className="bg-[#1C1513] text-[#D8C19A] px-2 py-0.5 rounded-full text-[10px]">
              {reviews.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('banners')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'banners'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <Image className="w-4 h-4" />
            <span>بانرات وإعلانات الواجهة</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'settings'
                ? 'bg-[#B99A68] text-white shadow-md'
                : 'text-stone-300 hover:bg-[#382B26] hover:text-white'
            }`}
          >
            <SettingsIcon className="w-4 h-4" />
            <span>إعدادات المتجر والنسخ الاحتياطي</span>
          </button>
        </nav>

        {/* Back to storefront button */}
        <div className="p-4 border-t border-stone-800 space-y-2">
          <button
            onClick={() => setCurrentView('home')}
            className="w-full py-2.5 bg-[#B99A68] hover:bg-[#A88856] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-sm"
          >
            <Store className="w-4 h-4" />
            <span>معاينة واجهة المتجر</span>
          </button>

          <div className="text-[11px] text-stone-400 text-center pt-1">
            المستخدم: <strong className="text-stone-200">{currentUser?.name || 'مدير النظام'}</strong>
          </div>
        </div>
      </aside>

      {/* 2. Main Content Area */}
      <main className="flex-1 p-4 sm:p-8 overflow-y-auto">
        {/* TOP BAR: Quick Actions */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8 bg-[#F7F1E8] p-4 sm:p-6 rounded-3xl border border-[#D8CBBE] shadow-xs">
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold font-serif text-[#2B211D]">
              {activeTab === 'overview' && 'لوحة التحليلات والمبيعات الشاملة'}
              {activeTab === 'products' && 'إدارة المنتجات والمخزون والتسعير'}
              {activeTab === 'orders' && 'سجل فواتير وطلبات المبيعات'}
              {activeTab === 'purchases' && 'فواتير المشتريات وتوريد المخزون'}
              {activeTab === 'customers' && 'قائمة العملاء وسجل المشتريات'}
              {activeTab === 'categories' && 'أقسام وتصنيفات المجوهرات'}
              {activeTab === 'discounts' && 'أكواد الخصم الترويجية'}
              {activeTab === 'reviews' && 'إدارة مراجعات العملاء'}
              {activeTab === 'banners' && 'بانرات الواجهة الرئيسية'}
              {activeTab === 'settings' && 'إعدادات المتجر والنسخ الاحتياطي'}
            </h1>
            <p className="text-xs text-[#7A6A60] mt-0.5">
              متجر زينة للإكسسوارات والمجوهرات الفاخرة — إدارة مركزية متكاملة
            </p>
          </div>

          {/* Quick Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportProductsExcel}
              className="px-3.5 py-2 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-[#D8CBBE]"
              title="تصدير إكسيل"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              <span>تصدير Excel للمنتجات</span>
            </button>

            <button
              onClick={() => {
                setEditingProduct(null);
                setIsProductModalOpen(true);
              }}
              className="px-4 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة منتج جديد</span>
            </button>
          </div>
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-fadeIn">
            {/* 4 Key Metric Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-[#7A6A60]">
                  <span>إجمالي المبيعات المحققة</span>
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-extrabold font-mono text-[#2B211D]">
                  {totalSalesRevenue.toLocaleString()}{' '}
                  <span className="text-xs font-sans text-[#7A6A60]">ج.م</span>
                </div>
                <div className="text-[11px] text-emerald-700 flex items-center gap-1">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  <span>من إجمالي {orders.length} طلب بيع</span>
                </div>
              </div>

              <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-[#7A6A60]">
                  <span>تكلفة المشتريات والتوريد</span>
                  <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
                    <FileText className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-extrabold font-mono text-[#2B211D]">
                  {totalPurchasesCost.toLocaleString()}{' '}
                  <span className="text-xs font-sans text-[#7A6A60]">ج.م</span>
                </div>
                <div className="text-[11px] text-[#7A6A60]">
                  من {purchases.length} فاتورة توريد مخزون
                </div>
              </div>

              <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-[#7A6A60]">
                  <span>مجمل الأرباح التقديرية</span>
                  <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-[#B99A68]" />
                  </div>
                </div>
                <div className="text-2xl font-extrabold font-mono text-[#B99A68]">
                  {estimatedGrossProfit.toLocaleString()}{' '}
                  <span className="text-xs font-sans text-[#7A6A60]">ج.م</span>
                </div>
                <div className="text-[11px] text-[#7A6A60]">المبيعات مطروحاً منها التكلفة</div>
              </div>

              <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-[#7A6A60]">
                  <span>حالة المخزون الحالي</span>
                  <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center">
                    <Package className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-extrabold font-mono text-[#2B211D]">
                  {totalStockCount} <span className="text-xs font-sans text-[#7A6A60]">قطعة</span>
                </div>
                <div className="text-[11px] text-rose-700">
                  {lowStockCount > 0 ? `${lowStockCount} قطع قاربت على النفاد!` : 'المخزون متوازن'}
                </div>
              </div>
            </div>

            {/* Recent Orders table snapshot */}
            <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base font-serif text-[#2B211D]">
                  أحدث طلبات البيع والفواتير
                </h3>
                <button
                  onClick={() => setActiveTab('orders')}
                  className="text-xs font-bold text-[#B99A68] hover:underline"
                >
                  عرض كافة الطلبات ({orders.length})
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right">
                  <thead>
                    <tr className="border-b border-[#D8CBBE] text-[#7A6A60]">
                      <th className="pb-3 font-semibold">رقم الفاتورة</th>
                      <th className="pb-3 font-semibold">اسم العميل</th>
                      <th className="pb-3 font-semibold">المحافظة</th>
                      <th className="pb-3 font-semibold">المبلغ</th>
                      <th className="pb-3 font-semibold">الحالة</th>
                      <th className="pb-3 font-semibold text-center">الإجراء</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D8CBBE]/50">
                    {orders.slice(0, 5).map((order) => (
                      <tr key={order.id} className="hover:bg-[#E8DDD0]/40">
                        <td className="py-3 font-mono font-bold text-[#2B211D]">
                          #{order.orderNumber}
                        </td>
                        <td className="py-3 font-medium text-[#2B211D]">{order.customerName}</td>
                        <td className="py-3 text-[#7A6A60]">{order.city}</td>
                        <td className="py-3 font-mono font-bold text-[#2B211D]">
                          {(order.total ?? (order as any).totalAmount ?? 0).toLocaleString()} ج.م
                        </td>
                        <td className="py-3">
                          <span className="bg-[#E8DDD0] px-2.5 py-1 rounded-full text-[10px] font-bold text-[#2B211D]">
                            {order.status === 'delivered'
                              ? 'تم التوصيل'
                              : order.status === 'shipped'
                              ? 'في الشحن'
                              : order.status === 'processing'
                              ? 'قيد التجهيز'
                              : 'معلق'}
                          </span>
                        </td>
                        <td className="py-3 text-center">
                          <button
                            onClick={() => openInvoice(order.id, 'sale')}
                            className="px-3 py-1 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-lg text-[11px] font-bold transition flex items-center gap-1 mx-auto"
                          >
                            <FileText className="w-3 h-3" />
                            <span>فاتورة PDF</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PRODUCTS (CRUD + Excel Import/Export) */}
        {activeTab === 'products' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Filter and Import/Export Tools */}
            <div className="bg-[#F7F1E8] p-4 sm:p-6 rounded-3xl border border-[#D8CBBE] flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="w-full md:w-80 relative">
                <input
                  type="text"
                  placeholder="ابحث عن منتج بالاسم أو كود SKU..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 pl-9 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
                <Search className="w-4 h-4 text-[#7A6A60] absolute left-3 top-2.5" />
              </div>

              <div className="flex items-center gap-2 self-end md:self-auto">
                <input
                  type="file"
                  ref={excelInputRef}
                  onChange={handleImportExcelFile}
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                />
                <button
                  onClick={() => excelInputRef.current?.click()}
                  className="px-3.5 py-2 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-[#D8CBBE]"
                  title="استيراد منتجات من ملف Excel"
                >
                  <Upload className="w-4 h-4 text-[#B99A68]" />
                  <span>استيراد Excel</span>
                </button>

                <button
                  onClick={handleExportProductsExcel}
                  className="px-3.5 py-2 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-[#D8CBBE]"
                >
                  <Download className="w-4 h-4 text-emerald-700" />
                  <span>تصدير Excel</span>
                </button>
              </div>
            </div>

            {/* Products Table */}
            <div className="bg-[#F7F1E8] rounded-3xl border border-[#D8CBBE] overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#E8DDD0]/60 text-[#7A6A60] border-b border-[#D8CBBE]">
                    <tr>
                      <th className="p-4 font-semibold">الصورة</th>
                      <th className="p-4 font-semibold">كود SKU</th>
                      <th className="p-4 font-semibold">اسم المنتج</th>
                      <th className="p-4 font-semibold">القسم</th>
                      <th className="p-4 font-semibold">سعر البيع</th>
                      <th className="p-4 font-semibold">تكلفة الشراء</th>
                      <th className="p-4 font-semibold">المخزون الحالي</th>
                      <th className="p-4 font-semibold text-center">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D8CBBE]/50">
                    {products
                      .filter(
                        (p) =>
                          p.nameAr.toLowerCase().includes(productSearch.toLowerCase()) ||
                          p.sku.toLowerCase().includes(productSearch.toLowerCase())
                      )
                      .map((product) => (
                        <tr key={product.id} className="hover:bg-[#E8DDD0]/30 transition">
                          <td className="p-4">
                            <img
                              src={product.images[0]}
                              alt={product.nameAr}
                              className="w-12 h-12 rounded-xl object-cover border border-[#D8CBBE]"
                            />
                          </td>
                          <td className="p-4 font-mono font-bold text-[#7A6A60]">{product.sku}</td>
                          <td className="p-4">
                            <p className="font-bold text-[#2B211D]">{product.nameAr}</p>
                            <p className="text-[10px] text-[#7A6A60]">{product.name}</p>
                          </td>
                          <td className="p-4 text-[#7A6A60]">{product.categoryName}</td>
                          <td className="p-4 font-mono font-bold text-[#2B211D]">
                            {(product.price ?? 0).toLocaleString()} ج.م
                          </td>
                          <td className="p-4 font-mono text-[#7A6A60]">
                            {product.costPrice ? `${(product.costPrice ?? 0).toLocaleString()} ج.م` : '—'}
                          </td>
                          <td className="p-4">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[11px] font-bold font-mono ${
                                product.stock <= 5
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {product.stock} قطعة
                            </span>
                          </td>
                          <td className="p-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => {
                                  setEditingProduct(product);
                                  setIsProductModalOpen(true);
                                }}
                                className="p-1.5 text-[#2B211D] hover:bg-[#E8DDD0] rounded-lg transition"
                                title="تعديل"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`هل أنت متأكد من حذف المنتج "${product.nameAr}"؟`)) {
                                    deleteProduct(product.id);
                                  }
                                }}
                                className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                                title="حذف"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ORDERS (Sales Invoices + PDF) */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center bg-[#F7F1E8] p-4 rounded-3xl border border-[#D8CBBE]">
              <div className="relative w-80">
                <input
                  type="text"
                  placeholder="ابحث برقم الفاتورة، اسم العميل، الهاتف..."
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 pl-9 text-xs text-[#2B211D] focus:outline-none"
                />
                <Search className="w-4 h-4 text-[#7A6A60] absolute left-3 top-2.5" />
              </div>

              <button
                onClick={handleExportOrdersExcel}
                className="px-3.5 py-2 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-[#D8CBBE]"
              >
                <Download className="w-4 h-4 text-emerald-700" />
                <span>تصدير الطلبات كـ Excel</span>
              </button>
            </div>

            <div className="bg-[#F7F1E8] rounded-3xl border border-[#D8CBBE] overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#E8DDD0]/60 text-[#7A6A60] border-b border-[#D8CBBE]">
                    <tr>
                      <th className="p-4 font-semibold">رقم الطلب / الفاتورة</th>
                      <th className="p-4 font-semibold">العميل</th>
                      <th className="p-4 font-semibold">الهاتف</th>
                      <th className="p-4 font-semibold">المدينة والعنوان</th>
                      <th className="p-4 font-semibold">المبلغ النهائي</th>
                      <th className="p-4 font-semibold">طريقة الدفع</th>
                      <th className="p-4 font-semibold">تغيير الحالة</th>
                      <th className="p-4 font-semibold text-center">الفاتورة الرسمية</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D8CBBE]/50">
                    {orders
                      .filter(
                        (o) =>
                          o.orderNumber.toLowerCase().includes(orderSearch.toLowerCase()) ||
                          o.customerName.toLowerCase().includes(orderSearch.toLowerCase()) ||
                          o.customerPhone.includes(orderSearch)
                      )
                      .map((order) => (
                        <tr key={order.id} className="hover:bg-[#E8DDD0]/30 transition">
                          <td className="p-4 font-mono font-bold text-[#2B211D]">
                            #{order.orderNumber}
                          </td>
                          <td className="p-4 font-bold text-[#2B211D]">{order.customerName}</td>
                          <td className="p-4 font-mono text-[#7A6A60]">{order.customerPhone}</td>
                          <td className="p-4 text-[#7A6A60]">
                            {order.city} — {order.shippingAddress}
                          </td>
                          <td className="p-4 font-mono font-bold text-[#2B211D]">
                            {(order.total ?? (order as any).totalAmount ?? 0).toLocaleString()} ج.م
                          </td>
                          <td className="p-4">
                            <span className="bg-[#E8DDD0] px-2 py-0.5 rounded text-[10px] font-bold">
                              {order.paymentMethod === 'cod' ? 'عند الاستلام' : order.paymentMethod}
                            </span>
                          </td>
                          <td className="p-4">
                            <select
                              value={order.status}
                              onChange={(e) => updateOrderStatus(order.id, e.target.value as any)}
                              className="bg-[#E8DDD0]/60 border border-[#D8CBBE] rounded-lg px-2 py-1 text-[11px] font-bold text-[#2B211D] focus:outline-none"
                            >
                              <option value="pending">معلق (Pending)</option>
                              <option value="processing">قيد التجهيز (Processing)</option>
                              <option value="shipped">تم الشحن (Shipped)</option>
                              <option value="delivered">تم التوصيل (Delivered)</option>
                              <option value="cancelled">ملغي (Cancelled)</option>
                            </select>
                          </td>
                          <td className="p-4 text-center">
                            <button
                              onClick={() => openInvoice(order.id, 'sale')}
                              className="px-3 py-1.5 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 mx-auto shadow-xs"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              <span>عرض وتحميل PDF</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: PURCHASES (Inventory replenishment & Purchase Invoices + PDF) */}
        {activeTab === 'purchases' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center bg-[#F7F1E8] p-4 rounded-3xl border border-[#D8CBBE]">
              <div>
                <h3 className="font-bold text-sm text-[#2B211D]">سجل توريد وشراء المخزون</h3>
                <p className="text-xs text-[#7A6A60]">
                  إضافة فاتورة شراء من الموردين تزيد تلقائياً في رصيد مخزون المنتجات وتحدث تكلفة الشراء
                </p>
              </div>

              <button
                onClick={() => setIsPurchaseModalOpen(true)}
                className="px-4 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة فاتورة مشتريات جديدة</span>
              </button>
            </div>

            <div className="bg-[#F7F1E8] rounded-3xl border border-[#D8CBBE] overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#E8DDD0]/60 text-[#7A6A60] border-b border-[#D8CBBE]">
                    <tr>
                      <th className="p-4 font-semibold">رقم الفاتورة</th>
                      <th className="p-4 font-semibold">اسم المورد</th>
                      <th className="p-4 font-semibold">التاريخ</th>
                      <th className="p-4 font-semibold">عدد الأصناف</th>
                      <th className="p-4 font-semibold">إجمالي الفاتورة</th>
                      <th className="p-4 font-semibold">حالة الدفع</th>
                      <th className="p-4 font-semibold text-center">فاتورة الشراء PDF</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D8CBBE]/50">
                    {purchases.map((pur) => (
                      <tr key={pur.id} className="hover:bg-[#E8DDD0]/30 transition">
                        <td className="p-4 font-mono font-bold text-[#2B211D]">
                          #{pur.invoiceNumber}
                        </td>
                        <td className="p-4 font-bold text-[#2B211D]">{pur.supplierName}</td>
                        <td className="p-4 text-[#7A6A60]">
                          {new Date(pur.date).toLocaleDateString('ar-EG')}
                        </td>
                        <td className="p-4 font-mono">{pur.items.length} أصناف</td>
                        <td className="p-4 font-mono font-bold text-[#2B211D]">
                          {pur.totalAmount.toLocaleString()} ج.م
                        </td>
                        <td className="p-4">
                          <span className="bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full text-[10px] font-bold">
                            {pur.paymentStatus === 'paid' ? 'مسدد بالكامل' : 'آجل'}
                          </span>
                        </td>
                        <td className="p-4 text-center">
                          <button
                            onClick={() => openInvoice(pur.id, 'purchase')}
                            className="px-3 py-1.5 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 mx-auto shadow-xs"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>فاتورة الشراء PDF</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: CUSTOMERS */}
        {activeTab === 'customers' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE]">
              <h3 className="font-bold text-base font-serif text-[#2B211D] mb-4">
                قاعدة بيانات العملاء والمشتريات
              </h3>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#E8DDD0]/60 text-[#7A6A60] border-b border-[#D8CBBE]">
                    <tr>
                      <th className="p-4 font-semibold">اسم العميل</th>
                      <th className="p-4 font-semibold">الهاتف</th>
                      <th className="p-4 font-semibold">البريد</th>
                      <th className="p-4 font-semibold">المحافظة</th>
                      <th className="p-4 font-semibold">إجمالي الطلبات</th>
                      <th className="p-4 font-semibold">إجمالي المنفق</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D8CBBE]/50">
                    {/* Unique customer groups from orders */}
                    {Array.from(new Set(orders.map((o) => o.customerPhone))).map((phone) => {
                      const custOrders = orders.filter((o) => o.customerPhone === phone);
                      const latest = custOrders[0];
                      const totalSpent = custOrders.reduce(
                        (sum, o) => sum + (o.total ?? (o as any).totalAmount ?? 0),
                        0
                      );

                      return (
                        <tr key={phone} className="hover:bg-[#E8DDD0]/30 transition">
                          <td className="p-4 font-bold text-[#2B211D]">{latest.customerName}</td>
                          <td className="p-4 font-mono text-[#7A6A60]">{phone}</td>
                          <td className="p-4 text-[#7A6A60]">{latest.customerEmail}</td>
                          <td className="p-4 text-[#7A6A60]">{latest.city}</td>
                          <td className="p-4 font-mono font-bold">{custOrders.length} طلبات</td>
                          <td className="p-4 font-mono font-bold text-[#B99A68]">
                            {(totalSpent || 0).toLocaleString()} ج.م
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: CATEGORIES */}
        {activeTab === 'categories' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center bg-[#F7F1E8] p-4 rounded-3xl border border-[#D8CBBE]">
              <h3 className="font-bold text-sm text-[#2B211D]">تصنيفات ومجموعات المجوهرات</h3>
              <button
                onClick={() => setIsCategoryModalOpen(true)}
                className="px-4 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة قسم جديد</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {categories.map((cat) => (
                <div
                  key={cat.id}
                  className="bg-[#F7F1E8] p-5 rounded-3xl border border-[#D8CBBE] shadow-xs flex items-center justify-between"
                >
                  <div>
                    <h4 className="font-bold text-sm text-[#2B211D] font-serif">{cat.nameAr}</h4>
                    <p className="text-xs text-[#7A6A60] mt-0.5">{cat.name}</p>
                    <span className="inline-block mt-2 text-[10px] bg-[#E8DDD0] px-2 py-0.5 rounded-full font-mono">
                      {products.filter((p) => p.categoryId === cat.id).length} منتجات حالية
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      if (confirm(`هل أنت متأكد من حذف القسم "${cat.nameAr}"؟`)) {
                        deleteCategory(cat.id);
                      }
                    }}
                    className="p-2 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                    title="حذف القسم"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 7: DISCOUNTS & COUPONS */}
        {activeTab === 'discounts' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center bg-[#F7F1E8] p-4 rounded-3xl border border-[#D8CBBE]">
              <h3 className="font-bold text-sm text-[#2B211D]">كوبونات وأكواد الخصم النشطة</h3>
              <button
                onClick={() => setIsDiscountModalOpen(true)}
                className="px-4 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>إنشاء كود خصم جديد</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {discounts.map((disc) => (
                <div
                  key={disc.id}
                  className="bg-[#F7F1E8] p-5 rounded-3xl border border-[#D8CBBE] shadow-xs flex flex-col justify-between space-y-3"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono font-bold text-base text-[#B76E79] tracking-wider block">
                        {disc.code}
                      </span>
                      <p className="text-xs text-[#7A6A60] mt-0.5">{disc.description}</p>
                    </div>

                    <button
                      onClick={() => deleteDiscount(disc.id)}
                      className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="border-t border-[#D8CBBE] pt-2 text-xs flex justify-between text-[#7A6A60]">
                    <span>
                      قيمة الخصم:{' '}
                      <strong className="text-[#2B211D]">
                        {disc.type === 'percentage' ? `${disc.value}%` : `${disc.value} ج.م`}
                      </strong>
                    </span>
                    <span>الحد الأدنى: {disc.minOrderAmount} ج.م</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 8: REVIEWS */}
        {activeTab === 'reviews' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-[#F7F1E8] rounded-3xl border border-[#D8CBBE] p-6 space-y-4">
              <h3 className="font-bold text-base font-serif text-[#2B211D]">
                إدارة مراجعات العملاء والموافقة عليها
              </h3>

              <div className="space-y-3">
                {reviews.map((rev) => (
                  <div
                    key={rev.id}
                    className="p-4 bg-[#E8DDD0]/50 rounded-2xl border border-[#D8CBBE] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-[#2B211D]">{rev.customerName}</span>
                        <span className="text-[10px] text-[#7A6A60]">على {rev.productName}</span>
                        <span className="text-amber-500 text-xs">★ {rev.rating}</span>
                      </div>
                      <p className="text-xs text-[#2B211D] mt-1">{rev.comment}</p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {rev.status === 'pending' && (
                        <button
                          onClick={() => updateReviewStatus(rev.id, 'approved')}
                          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition"
                        >
                          موافقة ونشر
                        </button>
                      )}
                      <button
                        onClick={() => deleteReview(rev.id)}
                        className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                        title="حذف"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 9: BANNERS */}
        {activeTab === 'banners' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] space-y-4">
              <h3 className="font-bold text-base font-serif text-[#2B211D]">
                بانرات وإعلانات الصفحة الرئيسية
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {banners.map((banner) => (
                  <div
                    key={banner.id}
                    className="bg-[#E8DDD0]/40 rounded-2xl border border-[#D8CBBE] overflow-hidden space-y-3 p-4"
                  >
                    <img
                      src={banner.image}
                      alt={banner.titleAr}
                      className="w-full h-40 object-cover rounded-xl border border-[#D8CBBE]"
                    />
                    <div>
                      <span className="text-[10px] bg-[#B99A68] text-white px-2 py-0.5 rounded font-bold">
                        {banner.tagAr}
                      </span>
                      <h4 className="font-bold text-sm text-[#2B211D] mt-1">{banner.titleAr}</h4>
                      <p className="text-xs text-[#7A6A60] mt-0.5">{banner.subtitleAr}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB: STAFF MANAGEMENT */}
        {activeTab === 'staff' && (
          <div className="space-y-6 animate-fadeIn">
            <AdminStaffManager />
          </div>
        )}

        {/* TAB 10: SETTINGS & BACKUP */}
        {activeTab === 'settings' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Comprehensive Store Configuration (General, Logo, Contact, Social, Pricing, Payments, Policies, Invoice) */}
            <AdminSettingsManager />

            {/* Staff Management */}
            <AdminStaffManager />

            {/* Admin Account & Security Settings */}
            <AdminAccountSecurity />

            {/* Database Backup & Restore & Reset Box */}
            <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] space-y-4">
              <h3 className="font-bold text-base font-serif text-[#2B211D] flex items-center gap-2">
                <Database className="w-5 h-5 text-[#B99A68]" />
                <span>النسخ الاحتياطي واستعادة البيانات (Backup & Restore)</span>
              </h3>
              <p className="text-xs text-[#7A6A60] leading-relaxed">
                يمكنك تحميل نسخة احتياطية كاملة لكافة المنتجات والطلبات والفواتير والمشتريات بصيغة JSON، أو استعادتها في أي وقت دون فقدان أي بيانات.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={handleBackupDownload}
                  className="px-5 py-2.5 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل نسخة احتياطية (JSON)</span>
                </button>

                <input
                  type="file"
                  ref={backupInputRef}
                  onChange={handleBackupRestore}
                  accept=".json"
                  className="hidden"
                />

                <button
                  onClick={() => backupInputRef.current?.click()}
                  className="px-5 py-2.5 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-xl text-xs font-bold transition flex items-center gap-2 border border-[#D8CBBE]"
                >
                  <Upload className="w-4 h-4 text-[#B99A68]" />
                  <span>استعادة من ملف نسخة احتياطية</span>
                </button>

                <button
                  onClick={() => {
                    if (confirm('هل أنت متأكد من إعادة ضبط قاعدة البيانات إلى البيانات الافتراضية؟')) {
                      resetDatabaseToDefault();
                    }
                  }}
                  className="px-5 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold transition flex items-center gap-2 mr-auto"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>إعادة ضبط البيانات الأولية</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* --- ADD / EDIT PRODUCT MODAL --- */}
      {isProductModalOpen && (
        <ProductModal
          isOpen={isProductModalOpen}
          editingProduct={editingProduct}
          categories={categories}
          onClose={() => setIsProductModalOpen(false)}
          onSave={(prodData) => {
            if (editingProduct) {
              updateProduct(editingProduct.id, prodData);
            } else {
              addProduct(prodData);
            }
            setIsProductModalOpen(false);
          }}
        />
      )}

      {/* --- ADD PURCHASE MODAL --- */}
      {isPurchaseModalOpen && (
        <PurchaseModal
          isOpen={isPurchaseModalOpen}
          products={products}
          onClose={() => setIsPurchaseModalOpen(false)}
          onSave={(purchaseData) => {
            addPurchase(purchaseData);
            setIsPurchaseModalOpen(false);
          }}
        />
      )}

      {/* --- ADD DISCOUNT MODAL --- */}
      {isDiscountModalOpen && (
        <DiscountModal
          isOpen={isDiscountModalOpen}
          onClose={() => setIsDiscountModalOpen(false)}
          onSave={(discData) => {
            addDiscount(discData);
            setIsDiscountModalOpen(false);
          }}
        />
      )}

      {/* --- ADD CATEGORY MODAL --- */}
      {isCategoryModalOpen && (
        <CategoryModal
          isOpen={isCategoryModalOpen}
          onClose={() => setIsCategoryModalOpen(false)}
          onSave={(catData) => {
            addCategory(catData);
            setIsCategoryModalOpen(false);
          }}
        />
      )}
    </div>
  );
};

// Subcomponent: Product Modal
interface ProductModalProps {
  isOpen: boolean;
  editingProduct: Product | null;
  categories: Category[];
  onClose: () => void;
  onSave: (product: any) => void;
}

const ProductModal: React.FC<ProductModalProps> = ({
  isOpen,
  editingProduct,
  categories,
  onClose,
  onSave,
}) => {
  const [sku, setSku] = useState(editingProduct?.sku || `ZN-${Math.floor(1000 + Math.random() * 9000)}`);
  const [nameAr, setNameAr] = useState(editingProduct?.nameAr || '');
  const [name, setName] = useState(editingProduct?.name || '');
  const [categoryId, setCategoryId] = useState(editingProduct?.categoryId || categories[0]?.id || '');
  const [price, setPrice] = useState(editingProduct?.price || 1200);
  const [costPrice, setCostPrice] = useState(editingProduct?.costPrice || 600);
  const [stock, setStock] = useState(editingProduct?.stock || 10);
  const [material, setMaterial] = useState(editingProduct?.material || 'مطلي ذهب عيار 18k مع زركونيا');
  const [descriptionAr, setDescriptionAr] = useState(editingProduct?.descriptionAr || '');
  const [imageUrl, setImageUrl] = useState(
    editingProduct?.images[0] || 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80'
  );
  const [isFeatured, setIsFeatured] = useState(editingProduct?.isFeatured || false);
  const [isBestSeller, setIsBestSeller] = useState(editingProduct?.isBestSeller || false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameAr || !price) return;

    const catObj = categories.find((c) => c.id === categoryId);

    onSave({
      sku,
      nameAr,
      name: name || nameAr,
      categoryId,
      categoryName: catObj?.nameAr || '',
      price: Number(price),
      costPrice: Number(costPrice),
      stock: Number(stock),
      material,
      descriptionAr,
      description: descriptionAr,
      images: [imageUrl],
      isFeatured,
      isBestSeller,
      status: 'active',
      colors: ['شامبين جولد', 'ذهب أبيض'],
      tags: ['مجوهرات', 'أناقة'],
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto text-right">
      <div className="bg-[#F7F1E8] rounded-3xl w-full max-w-xl border border-[#D8CBBE] shadow-2xl overflow-hidden p-6 space-y-4">
        <h3 className="font-bold text-lg font-serif text-[#2B211D] border-b border-[#D8CBBE] pb-3">
          {editingProduct ? 'تعديل بيانات المنتج' : 'إضافة منتج مجوهرات جديد'}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">اسم المنتج بالعربي *</label>
              <input
                type="text"
                required
                value={nameAr}
                onChange={(e) => setNameAr(e.target.value)}
                placeholder="عقد زينة الملكي"
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
              />
            </div>
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">الاسم بالإنجليزي</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Zeina Royal Necklace"
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">كود SKU *</label>
              <input
                type="text"
                required
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">القسم / التصنيف</label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.nameAr}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">المخزون المتوفر</label>
              <input
                type="number"
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">سعر البيع للعميل (ج.م) *</label>
              <input
                type="number"
                required
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">تكلفة الشراء (ج.م)</label>
              <input
                type="number"
                value={costPrice}
                onChange={(e) => setCostPrice(Number(e.target.value))}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#2B211D] mb-1">رابط صورة المنتج (URL)</label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#2B211D] mb-1">الخامة والمواصفات</label>
            <input
              type="text"
              value={material}
              onChange={(e) => setMaterial(e.target.value)}
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#2B211D] mb-1">وصف المنتج</label>
            <textarea
              rows={3}
              value={descriptionAr}
              onChange={(e) => setDescriptionAr(e.target.value)}
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
            />
          </div>

          <div className="flex items-center gap-6 pt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isFeatured}
                onChange={(e) => setIsFeatured(e.target.checked)}
                className="accent-[#B99A68]"
              />
              <span className="font-bold text-[#2B211D]">منتج مميز بالرئيسية</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isBestSeller}
                onChange={(e) => setIsBestSeller(e.target.checked)}
                className="accent-[#B76E79]"
              />
              <span className="font-bold text-[#2B211D]">شارة الأكثر طلباً</span>
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t border-[#D8CBBE]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-transparent text-[#7A6A60] rounded-xl hover:bg-[#E8DDD0]"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl font-bold transition"
            >
              حفظ المنتج
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Subcomponent: Purchase Invoice Modal
interface PurchaseModalProps {
  isOpen: boolean;
  products: Product[];
  onClose: () => void;
  onSave: (purchase: any) => void;
}

const PurchaseModal: React.FC<PurchaseModalProps> = ({ isOpen, products, onClose, onSave }) => {
  const [supplierName, setSupplierName] = useState('مسبك الزهراء لطلاء المعادن والزركون');
  const [invoiceNumber, setInvoiceNumber] = useState(`PUR-${Date.now().toString().slice(-4)}`);
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id || '');
  const [quantity, setQuantity] = useState(20);
  const [unitCost, setUnitCost] = useState(650);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const prod = products.find((p) => p.id === selectedProductId) || products[0];

    const total = quantity * unitCost;

    onSave({
      invoiceNumber,
      supplierName,
      supplierPhone: '01009988776',
      items: [
        {
          productId: prod.id,
          productName: prod.nameAr,
          sku: prod.sku,
          quantity: Number(quantity),
          unitCost: Number(unitCost),
          totalCost: total,
        },
      ],
      totalAmount: total,
      paymentStatus: 'paid',
      notes: 'توريد مخزون جديد مع طلاء وحماية عازلة',
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 text-right">
      <div className="bg-[#F7F1E8] rounded-3xl w-full max-w-lg border border-[#D8CBBE] shadow-2xl p-6 space-y-4">
        <h3 className="font-bold text-lg font-serif text-[#2B211D] border-b border-[#D8CBBE] pb-3">
          إضافة فاتورة مشتريات وتوريد مخزون
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#2B211D] mb-1">اسم المورد / الورشة *</label>
            <input
              type="text"
              required
              value={supplierName}
              onChange={(e) => setSupplierName(e.target.value)}
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">رقم فاتورة المورد</label>
              <input
                type="text"
                required
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#2B211D] mb-1">المنتج المورد</label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.nameAr} ({p.sku})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">الكمية الموردة *</label>
              <input
                type="number"
                min="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">سعر تكلفة القطعة (ج.م) *</label>
              <input
                type="number"
                min="1"
                required
                value={unitCost}
                onChange={(e) => setUnitCost(Number(e.target.value))}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>
          </div>

          <div className="p-3 bg-[#E8DDD0] rounded-xl text-xs font-bold text-[#2B211D] flex justify-between">
            <span>إجمالي الفاتورة:</span>
            <span className="font-mono text-sm text-[#B99A68]">
              {(quantity * unitCost).toLocaleString()} ج.م
            </span>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-[#D8CBBE]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-transparent text-[#7A6A60] rounded-xl hover:bg-[#E8DDD0]"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl font-bold transition"
            >
              تأكيد وحفظ الفاتورة
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Subcomponent: Discount Modal
interface DiscountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (discount: any) => void;
}

const DiscountModal: React.FC<DiscountModalProps> = ({ isOpen, onClose, onSave }) => {
  const [code, setCode] = useState('');
  const [value, setValue] = useState(15);
  const [type, setType] = useState<'percentage' | 'fixed'>('percentage');
  const [minOrderAmount, setMinOrderAmount] = useState(1000);
  const [description, setDescription] = useState('خصم حصري على المجوهرات');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code) return;
    onSave({
      code: code.toUpperCase(),
      type,
      value: Number(value),
      minOrderAmount: Number(minOrderAmount),
      description,
      isActive: true,
      usageLimit: 500,
      usedCount: 0,
      expiryDate: '2026-12-31',
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 text-right">
      <div className="bg-[#F7F1E8] rounded-3xl w-full max-w-md border border-[#D8CBBE] shadow-2xl p-6 space-y-4">
        <h3 className="font-bold text-lg font-serif text-[#2B211D] border-b border-[#D8CBBE] pb-3">
          إنشاء كود خصم جديد
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#2B211D] mb-1">كود الكوبون *</label>
            <input
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="مثال: GOLD20"
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono uppercase text-[#2B211D]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">نوع الخصم</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
              >
                <option value="percentage">نسبة مئوية (%)</option>
                <option value="fixed">مبلغ ثابت (ج.م)</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-[#2B211D] mb-1">قيمة الخصم *</label>
              <input
                type="number"
                required
                value={value}
                onChange={(e) => setValue(Number(e.target.value))}
                className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#2B211D] mb-1">الحد الأدنى لقيمة الطلب (ج.م)</label>
            <input
              type="number"
              value={minOrderAmount}
              onChange={(e) => setMinOrderAmount(Number(e.target.value))}
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 font-mono text-[#2B211D]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#2B211D] mb-1">وصف العرض</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-[#D8CBBE]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-transparent text-[#7A6A60] rounded-xl hover:bg-[#E8DDD0]"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl font-bold transition"
            >
              تفعيل الكود
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Subcomponent: Category Modal
interface CategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (category: any) => void;
}

const CategoryModal: React.FC<CategoryModalProps> = ({ isOpen, onClose, onSave }) => {
  const [nameAr, setNameAr] = useState('');
  const [name, setName] = useState('');
  const [iconName, setIconName] = useState('Gem');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameAr) return;
    const slug = name ? name.toLowerCase().replace(/\s+/g, '-') : `cat-${Date.now()}`;
    onSave({
      slug,
      nameAr,
      name: name || nameAr,
      iconName,
      itemCount: 0,
      displayOrder: 10,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 text-right">
      <div className="bg-[#F7F1E8] rounded-3xl w-full max-w-md border border-[#D8CBBE] shadow-2xl p-6 space-y-4">
        <h3 className="font-bold text-lg font-serif text-[#2B211D] border-b border-[#D8CBBE] pb-3">
          إضافة قسم مجوهرات جديد
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#2B211D] mb-1">اسم القسم بالعربي *</label>
            <input
              type="text"
              required
              value={nameAr}
              onChange={(e) => setNameAr(e.target.value)}
              placeholder="مثال: دبابيس وبروشات ملكية"
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
            />
          </div>

          <div>
            <label className="block font-bold text-[#2B211D] mb-1">الاسم بالإنجليزي</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Brooches"
              className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3 py-2 text-[#2B211D]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-[#D8CBBE]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-transparent text-[#7A6A60] rounded-xl hover:bg-[#E8DDD0]"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl font-bold transition"
            >
              إضافة القسم
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { Logo } from '../components/Logo';
import {
  Lock,
  Mail,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Eye,
  EyeOff,
  Clock,
} from 'lucide-react';
import {
  checkAccountLockout,
  recordFailedLoginAttempt,
  resetFailedLoginAttempts,
  createAdminSession,
  verifyPassword,
} from '../utils/security';
import { getUsers } from '../db/storage';
import { loginApi } from '../services/api';

interface AdminLoginViewProps {
  onSuccess: () => void;
  onBackToStore: () => void;
}

export const AdminLoginView: React.FC<AdminLoginViewProps> = ({ onSuccess, onBackToStore }) => {
  const { setCurrentUser, showToast } = useStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [remainingAttempts, setRemainingAttempts] = useState<number | null>(null);
  const [isLocked, setIsLocked] = useState(false);
  const [lockMinutes, setLockMinutes] = useState(0);

  // Check lockout on mount
  useEffect(() => {
    const lockStatus = checkAccountLockout();
    if (lockStatus.isLocked) {
      setIsLocked(true);
      setLockMinutes(lockStatus.remainingMinutes);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // Pre-check brute force lockout
    const lockStatus = checkAccountLockout();
    if (lockStatus.isLocked) {
      setIsLocked(true);
      setLockMinutes(lockStatus.remainingMinutes);
      setErrorMessage(`تم قفل محاولات تسجيل الدخول مؤقتاً لحماية النظام. يرجى الانتظار ${lockStatus.remainingMinutes} دقيقة والمحاولة لاحقاً.`);
      return;
    }

    if (!email.trim() || !password) {
      setErrorMessage('يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }

    setIsLoading(true);

    try {
      const cleanEmail = email.toLowerCase().trim();

      // Artificial delay (300ms) for rate-limiting resistance against automated brute-force timing attacks
      await new Promise((resolve) => setTimeout(resolve, 300));

      // 1. Try server-side authentication first to get session token & verify backend DB
      try {
        const apiRes = await loginApi(cleanEmail, password);
        if (apiRes.success && apiRes.user) {
          if (apiRes.user.role === 'admin' || apiRes.user.role === 'staff') {
            resetFailedLoginAttempts();
            createAdminSession(apiRes.user.email);
            if (typeof setCurrentUser === 'function') {
              setCurrentUser(apiRes.user);
            }
            showToast(`تم تسجيل الدخول بنجاح. أهلاً بك ${apiRes.user.name}`);
            onSuccess();
            return;
          } else {
            setErrorMessage('عذراً، هذا الحساب ليس لديه صلاحيات الوصول إلى لوحة تحكم الإدارة.');
            setIsLoading(false);
            return;
          }
        } else if (apiRes.error && !apiRes.error.includes('تعذر الاتصال بخادم المتجر')) {
          // Server returned explicit authentication failure (e.g. wrong password or lockout)
          setErrorMessage(apiRes.error);
          setIsLoading(false);
          return;
        }
      } catch (e) {
        console.warn('Server authentication fallback to local storage check:', e);
      }

      // 2. Local resilient fallback check
      const users = getUsers();
      const targetUser = users.find(
        (u) => (u.role === 'admin' || u.role === 'staff') && u.email.toLowerCase() === cleanEmail
      );

      if (!targetUser) {
        const lockInfo = recordFailedLoginAttempt();
        if (lockInfo.isNowLocked) {
          setIsLocked(true);
          setLockMinutes(15);
          setErrorMessage('تم قفل الحساب مؤقتاً لمدة 15 دقيقة بعد 5 محاولات فاشلة متتالية.');
        } else {
          setRemainingAttempts(lockInfo.remainingAttempts);
          setErrorMessage(`البريد الإلكتروني أو كلمة المرور غير صحيحة. المحاولات المتبقية: ${lockInfo.remainingAttempts}`);
        }
        setIsLoading(false);
        return;
      }

      // Verify PBKDF2 hashed password
      let isValid = false;
      if (targetUser.passwordHash.startsWith('pbkdf2:')) {
        isValid = await verifyPassword(password, targetUser.passwordHash);
      } else {
        isValid = targetUser.passwordHash === password || targetUser.passwordHash === `hash_${password}`;
      }

      if (!isValid) {
        const lockInfo = recordFailedLoginAttempt();
        if (lockInfo.isNowLocked) {
          setIsLocked(true);
          setLockMinutes(15);
          setErrorMessage('تم قفل الحساب مؤقتاً لمدة 15 دقيقة بعد 5 محاولات فاشلة متتالية.');
        } else {
          setRemainingAttempts(lockInfo.remainingAttempts);
          setErrorMessage(`كلمة المرور غير صحيحة. المحاولات المتبقية: ${lockInfo.remainingAttempts}`);
        }
        setIsLoading(false);
        return;
      }

      // Successful verification
      resetFailedLoginAttempts();
      createAdminSession(targetUser.email);
      if (typeof setCurrentUser === 'function') {
        setCurrentUser(targetUser);
      }
      showToast(`تم تسجيل الدخول بنجاح. أهلاً بك ${targetUser.name}`);
      onSuccess();
    } catch (err) {
      console.error('Login error:', err);
      setErrorMessage('حدث خطأ غير متوقع أثناء معالجة تسجيل الدخول');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1F1714] text-[#F7F1E8] flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden selection:bg-[#B99A68] selection:text-white">
      {/* Subtle Background Glow Accent */}
      <div className="absolute top-1/4 -right-24 w-96 h-96 bg-[#B99A68]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -left-24 w-96 h-96 bg-[#B76E79]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Login Card */}
      <div className="w-full max-w-md bg-[#2B211D] border border-[#43342D] rounded-3xl p-8 sm:p-10 shadow-2xl relative z-10 animate-fadeIn">
        {/* Top Header & Logo */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="p-3 bg-[#3B2E28] rounded-2xl border border-[#524037] mb-4 shadow-inner">
            <Logo variant="light" size="md" />
          </div>
          <h1 className="text-xl font-bold font-serif text-[#F7F1E8] tracking-wide">
            بوابة الإدارة المركزية
          </h1>
          <p className="text-xs text-[#A8988C] mt-1.5 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#B99A68]" />
            <span>تسجيل دخول محمي ومشفر بالكامل</span>
          </p>
        </div>

        {/* Lockout Warning Banner */}
        {isLocked && (
          <div className="mb-6 p-4 bg-rose-950/60 border border-rose-800/80 rounded-2xl text-rose-200 text-xs flex items-start gap-3">
            <Clock className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">الحساب مقفل مؤقتاً</p>
              <p className="text-[11px] text-rose-300 mt-0.5">
                لحماية النظام من هجمات التخمين، تم قفل تسجيل الدخول. يرجى الانتظار قرابة {lockMinutes} دقيقة قبل المحاولة التالية.
              </p>
            </div>
          </div>
        )}

        {/* Error Alert Banner */}
        {errorMessage && !isLocked && (
          <div className="mb-6 p-4 bg-rose-950/50 border border-rose-800/60 rounded-2xl text-rose-200 text-xs flex items-start gap-3 animate-shake">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="leading-relaxed">{errorMessage}</p>
              {remainingAttempts !== null && remainingAttempts > 0 && (
                <p className="text-[10px] text-rose-300 font-mono mt-1">
                  المحاولات المتبقية قبل القفل المؤقت: {remainingAttempts} / 5
                </p>
              )}
            </div>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Email Field */}
          <div>
            <label className="block text-xs font-semibold text-[#D8CBBE] mb-2">
              البريد الإلكتروني (Admin Email)
            </label>
            <div className="relative">
              <input
                type="email"
                required
                disabled={isLocked || isLoading}
                dir="ltr"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="iyadsayed@gmail.com"
                className="w-full bg-[#1F1714] border border-[#524037] focus:border-[#B99A68] focus:ring-2 focus:ring-[#B99A68]/20 rounded-xl px-4 py-3 pl-10 text-sm text-[#F7F1E8] placeholder-stone-600 transition outline-none disabled:opacity-50"
              />
              <Mail className="w-4 h-4 text-[#A8988C] absolute left-3.5 top-3.5" />
            </div>
          </div>

          {/* Password Field */}
          <div>
            <label className="block text-xs font-semibold text-[#D8CBBE] mb-2">
              كلمة المرور (Password)
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                disabled={isLocked || isLoading}
                dir="ltr"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-[#1F1714] border border-[#524037] focus:border-[#B99A68] focus:ring-2 focus:ring-[#B99A68]/20 rounded-xl px-4 py-3 pl-10 pr-10 text-sm text-[#F7F1E8] placeholder-stone-600 transition outline-none disabled:opacity-50"
              />
              <Lock className="w-4 h-4 text-[#A8988C] absolute left-3.5 top-3.5" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                tabIndex={-1}
                className="absolute right-3.5 top-3.5 text-[#A8988C] hover:text-[#D8CBBE] transition"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLocked || isLoading}
            className="w-full py-3.5 px-4 bg-[#B99A68] hover:bg-[#A88856] active:scale-[0.99] text-white font-bold text-sm rounded-xl shadow-lg transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <span>تسجيل الدخول للنظام</span>
                <ArrowRight className="w-4 h-4 rotate-180" />
              </>
            )}
          </button>
        </form>

        {/* Security Feature Badges */}
        <div className="mt-8 pt-6 border-t border-[#43342D]/70 grid grid-cols-2 gap-3 text-center">
          <div className="p-2.5 bg-[#1F1714]/60 rounded-xl border border-[#43342D]/50">
            <p className="text-[10px] font-bold text-[#D8CBBE]">تشفير PBKDF2</p>
            <p className="text-[9px] text-[#A8988C] mt-0.5">100,000 دورة تشفير مع Salt</p>
          </div>
          <div className="p-2.5 bg-[#1F1714]/60 rounded-xl border border-[#43342D]/50">
            <p className="text-[10px] font-bold text-[#D8CBBE]">حماية القوة الغاشمة</p>
            <p className="text-[9px] text-[#A8988C] mt-0.5">قفل تلقائي بعد 5 محاولات</p>
          </div>
        </div>

        {/* Return to Storefront */}
        <div className="mt-6 text-center">
          <button
            onClick={onBackToStore}
            className="text-xs text-[#A8988C] hover:text-[#F7F1E8] transition inline-flex items-center gap-1.5"
          >
            <span>العودة لمتجر زينة</span>
            <ArrowRight className="w-3.5 h-3.5 rotate-180" />
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Logo } from '../components/Logo';
import { useStore } from '../context/StoreContext';
import { Sparkles, Award, Gem, Heart, ShieldCheck, ArrowLeft } from 'lucide-react';

export const StorefrontAbout: React.FC = () => {
  const { setCurrentView } = useStore();

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-right space-y-16">
      {/* Intro Hero */}
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#B99A68] bg-[#E8DDD0] px-4 py-1 rounded-full">
          قصة الشغف والبريق
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-[#2B211D]">
          الفخامة في كل تفصيلة
        </h1>
        <p className="text-sm sm:text-base text-[#7A6A60] max-w-2xl mx-auto leading-relaxed">
          تأسس متجر زينة (Zeina Store) ليكون الوجهة الأولى لكل سيدة تبحث عن التميز والأنوثة الطاغية عبر تشكيلات مجوهرات وإكسسوارات استثنائية تنافس الذهب الخالص في بريقه وجودته.
        </p>
      </div>

      {/* Values Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-[#F7F1E8] p-8 rounded-3xl border border-[#D8CBBE] shadow-xs text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-[#B99A68]/20 text-[#B99A68] flex items-center justify-center mx-auto">
            <Gem className="w-7 h-7" />
          </div>
          <h3 className="font-bold text-base text-[#2B211D] font-serif">أحجار الزركون السويسرية</h3>
          <p className="text-xs text-[#7A6A60] leading-relaxed">
            نعتمد في جميع تصاميمنا على أحجار الزركونيا المكعبة فئة 5A التي تضاهي أنقى أحجار الألماس الطبيعي في انعكاساتها الضوئية الخلابة.
          </p>
        </div>

        <div className="bg-[#F7F1E8] p-8 rounded-3xl border border-[#D8CBBE] shadow-xs text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-[#B76E79]/20 text-[#B76E79] flex items-center justify-center mx-auto">
            <Award className="w-7 h-7" />
          </div>
          <h3 className="font-bold text-base text-[#2B211D] font-serif">طلاء ذهب عيار 18k</h3>
          <p className="text-xs text-[#7A6A60] leading-relaxed">
            تخضع جميع قطعنا لتقنية الطلاء الكهروكيميائي ثلاثي الطبقات مع طبقة حماية عازلة تمنع تلاشي اللون ومقاومة للماء والرطوبة والعطور.
          </p>
        </div>

        <div className="bg-[#F7F1E8] p-8 rounded-3xl border border-[#D8CBBE] shadow-xs text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-[#B99A68]/20 text-[#B99A68] flex items-center justify-center mx-auto">
            <Heart className="w-7 h-7" />
          </div>
          <h3 className="font-bold text-base text-[#2B211D] font-serif">تغليف الهدايا المخملي</h3>
          <p className="text-xs text-[#7A6A60] leading-relaxed">
            تصلك كل قطعة داخل علبة مجوهرات مخملية ملكية محفورة بشعار زينة مع كيس هدايا فاخر وبطاقة إهداء مخصصة تجعلها الهدية المثالية.
          </p>
        </div>
      </div>

      {/* Narrative Section */}
      <div className="bg-[#2B211D] text-[#F7F1E8] rounded-3xl p-8 sm:p-12 border-2 border-[#B99A68] shadow-2xl grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <span className="text-xs font-bold text-[#D8C19A] tracking-wider uppercase">رؤيتنا</span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif leading-snug">
            إبراز جمال وأناقة كل امرأة بلمسة ملكية تدوم طويلاً
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
            نؤمن في متجر زينة أن كل تفصيلة تصنع فارقاً، من اختيار أدق تفاصيل التصميم حتى لحظة فتح علبة المجوهرات المخملية. يسعدنا أن نكون جزءاً من لحظاتك السعيدة ومناسباتك الغالية.
          </p>
          <button
            onClick={() => setCurrentView('shop')}
            className="mt-2 px-6 py-3 bg-[#B99A68] hover:bg-[#A88856] text-white rounded-xl text-xs font-bold transition flex items-center gap-2"
          >
            <span>استكشفي تشكيلة زينة الكاملة</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

        <div className="rounded-2xl overflow-hidden border border-[#D8CBBE]/40 aspect-4/3">
          <img
            src="https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80"
            alt="Zeina Jewelry Craftsmanship"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </div>
  );
};

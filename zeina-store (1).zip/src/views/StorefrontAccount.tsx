import React from 'react';
import { useStore } from '../context/StoreContext';
import {
  User as UserIcon,
  Package,
  FileText,
  Clock,
  CheckCircle2,
  Truck,
  ArrowRight,
  LogOut,
  MapPin,
  Phone,
  Mail,
} from 'lucide-react';

interface AccountViewProps {
  onOpenAuth: () => void;
}

export const StorefrontAccount: React.FC<AccountViewProps> = ({ onOpenAuth }) => {
  const { currentUser, orders, logout, setPreviewOrder, setCurrentView } = useStore();

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center text-right">
        <div className="bg-[#F7F1E8] p-8 rounded-3xl border border-[#D8CBBE] shadow-xl text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#E8DDD0] mx-auto flex items-center justify-center text-[#B99A68]">
            <UserIcon className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold font-serif text-[#2B211D]">تسجيل الدخول مطلوب</h2>
          <p className="text-xs text-[#7A6A60] leading-relaxed">
            يرجى تسجيل الدخول لعرض سجل طلباتك السابقة وتفاصيل حسابك وفواتير الشراء.
          </p>
          <button
            onClick={onOpenAuth}
            className="w-full py-3 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition shadow-md"
          >
            تسجيل الدخول الآن
          </button>
        </div>
      </div>
    );
  }

  // Filter user's orders by customer phone, email or id
  const userOrders = orders.filter(
    (o) =>
      o.customerId === currentUser.id ||
      o.customerEmail.toLowerCase() === currentUser.email.toLowerCase() ||
      o.customerPhone === currentUser.phone
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'delivered':
        return (
          <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>تم التوصيل بنجاح</span>
          </span>
        );
      case 'shipped':
        return (
          <span className="bg-blue-100 text-blue-800 text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Truck className="w-3.5 h-3.5" />
            <span>في طريق التوصيل</span>
          </span>
        );
      case 'processing':
        return (
          <span className="bg-amber-100 text-amber-800 text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            <span>قيد التجهيز والتغليف</span>
          </span>
        );
      default:
        return (
          <span className="bg-stone-100 text-stone-700 text-[11px] font-bold px-2.5 py-1 rounded-full">
            تم استلام الطلب
          </span>
        );
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 text-right">
      {/* Header */}
      <div className="flex items-center justify-between pb-6 mb-8 border-b border-[#D8CBBE]">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#B99A68]">
            الملف الشخصي
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-serif text-[#2B211D] mt-0.5">
            حسابي وسجل الطلبات
          </h1>
        </div>

        <button
          onClick={logout}
          className="flex items-center gap-1.5 text-xs text-rose-700 hover:text-rose-900 bg-rose-50 px-3 py-1.5 rounded-xl transition font-medium"
        >
          <LogOut className="w-4 h-4" />
          <span>تسجيل الخروج</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* User Card */}
        <div className="lg:col-span-4 bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-[#B99A68] text-white flex items-center justify-center font-serif font-bold text-xl shadow-md">
              {currentUser.name.charAt(0)}
            </div>
            <div>
              <h2 className="font-bold text-base text-[#2B211D]">{currentUser.name}</h2>
              <span className="inline-block mt-0.5 text-[10px] font-bold text-[#B76E79] bg-[#E8DDD0] px-2 py-0.5 rounded-md">
                {currentUser.role === 'admin' ? 'مدير النظام' : currentUser.role === 'staff' ? 'موظف مبيعات' : 'عميل مميز'}
              </span>
            </div>
          </div>

          <div className="border-t border-[#D8CBBE] pt-4 space-y-3 text-xs text-[#7A6A60]">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#B99A68] shrink-0" />
              <span>{currentUser.email}</span>
            </div>
            {currentUser.phone && (
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#B99A68] shrink-0" />
                <span className="font-mono">{currentUser.phone}</span>
              </div>
            )}
            {currentUser.city && (
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#B99A68] shrink-0" />
                <span>{currentUser.city} {currentUser.address ? `— ${currentUser.address}` : ''}</span>
              </div>
            )}
          </div>
        </div>

        {/* Order History */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-lg font-serif text-[#2B211D] flex items-center gap-2">
              <Package className="w-5 h-5 text-[#B99A68]" />
              <span>سجل الطلبات السابقة ({userOrders.length})</span>
            </h3>
          </div>

          {userOrders.length === 0 ? (
            <div className="p-8 text-center bg-[#E8DDD0]/40 rounded-3xl border border-[#D8CBBE] space-y-3">
              <Package className="w-10 h-10 text-[#B99A68] mx-auto opacity-70" />
              <p className="text-xs text-[#7A6A60]">لم تسجلي أي طلبات بعد في متجر زينة.</p>
              <button
                onClick={() => setCurrentView('shop')}
                className="px-6 py-2 bg-[#2B211D] text-white rounded-full text-xs font-bold hover:bg-[#B99A68] transition"
              >
                تصفحي تشكيلة المجوهرات
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {userOrders.map((order) => (
                <div
                  key={order.id}
                  className="bg-[#F7F1E8] p-5 rounded-2xl border border-[#D8CBBE] shadow-xs space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#D8CBBE] pb-3">
                    <div>
                      <span className="text-xs font-mono font-bold text-[#2B211D] block">
                        طلب رقم #{order.orderNumber}
                      </span>
                      <span className="text-[11px] text-[#7A6A60]">
                        تاريخ الطلب: {new Date(order.createdAt).toLocaleDateString('ar-EG')}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      {getStatusBadge(order.status)}
                      <button
                        onClick={() => setPreviewOrder(order)}
                        className="px-3 py-1.5 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                        title="عرض وتحميل فاتورة البيع"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>فاتورة البيع PDF</span>
                      </button>
                    </div>
                  </div>

                  {/* Items snapshot */}
                  <div className="space-y-2">
                    {order.items.map((it, i) => (
                      <div key={i} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <img
                            src={it.image}
                            alt={it.nameAr}
                            className="w-10 h-10 rounded-lg object-cover border border-[#D8CBBE]"
                          />
                          <div>
                            <span className="font-semibold text-[#2B211D]">{it.nameAr}</span>
                            <span className="text-[#7A6A60] block text-[10px]">
                              الكمية: {it.quantity} {it.selectedColor ? `• اللون: ${it.selectedColor}` : ''}
                            </span>
                          </div>
                        </div>
                        <span className="font-mono font-bold text-[#2B211D]">
                          {((it.price ?? 0) * (it.quantity ?? 1)).toLocaleString()} ج.م
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Total & Shipping info */}
                  <div className="border-t border-[#D8CBBE] pt-3 flex flex-wrap justify-between items-center text-xs text-[#7A6A60]">
                    <span>طريقة الدفع: {order.paymentMethod === 'cod' ? 'عند الاستلام' : order.paymentMethod}</span>
                    <div className="flex items-center gap-2">
                      <span>الإجمالي المسدد:</span>
                      <span className="text-sm font-mono font-bold text-[#2B211D]">
                        {(order.total ?? (order as any).totalAmount ?? 0).toLocaleString()} ج.م
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

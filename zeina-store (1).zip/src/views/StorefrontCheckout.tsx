import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import confetti from 'canvas-confetti';
import {
  CreditCard,
  Banknote,
  Smartphone,
  ShieldCheck,
  ArrowRight,
  CheckCircle2,
  Lock,
  Truck,
  Sparkles,
  ShoppingBag,
} from 'lucide-react';

export const StorefrontCheckout: React.FC = () => {
  const {
    cart,
    cartTotal,
    appliedCoupon,
    discountAmount,
    settings,
    placeOrder,
    currentUser,
    setCurrentView,
  } = useStore();

  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerEmail, setCustomerEmail] = useState(currentUser?.email || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '');
  const [city, setCity] = useState(currentUser?.city || 'القاهرة');
  const [shippingAddress, setShippingAddress] = useState(currentUser?.address || '');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'card' | 'instapay' | 'vodafone_cash'>('cod');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderCompleted, setOrderCompleted] = useState(false);

  if (cart.length === 0 && !orderCompleted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <ShoppingBag className="w-16 h-16 text-[#B99A68] mx-auto mb-4" />
        <h2 className="text-2xl font-bold font-serif text-[#2B211D]">حقيبة التسوق فارغة</h2>
        <p className="text-xs text-[#7A6A60] mt-2">
          لا توجد منتجات في حقيبة التسوق لإتمام الطلب. تصفحي المجوهرات الآن.
        </p>
        <button
          onClick={() => setCurrentView('shop')}
          className="mt-6 px-8 py-3 bg-[#2B211D] text-white rounded-full text-xs font-bold hover:bg-[#B99A68] transition"
        >
          العودة للمتجر
        </button>
      </div>
    );
  }

  const shippingFee = cartTotal >= settings.freeShippingThreshold ? 0 : settings.shippingFeeFlat;
  const grandTotal = Math.max(0, cartTotal - discountAmount + shippingFee);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !shippingAddress) {
      alert('يرجى استكمال جميع بيانات التوصيل الإلزامية');
      return;
    }

    setIsSubmitting(true);

    try {
      const order = placeOrder({
        customerName,
        customerEmail: customerEmail || 'customer@zeinastore.com',
        customerPhone,
        shippingAddress,
        city,
        paymentMethod,
        notes,
      });

      // Confetti burst for luxurious celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#B99A68', '#B76E79', '#D8C19A', '#2B211D'],
        });
      } catch {}

      setOrderCompleted(true);
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء إتمام الطلب');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (orderCompleted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center text-right animate-fadeIn">
        <div className="bg-[#F7F1E8] rounded-3xl border border-[#D8CBBE] p-8 sm:p-12 shadow-2xl space-y-6">
          <div className="w-20 h-20 rounded-full bg-emerald-100 mx-auto flex items-center justify-center text-emerald-700 shadow-sm">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-[#B99A68]">
              تم تأكيد الطلب بنجاح
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold font-serif text-[#2B211D]">
              شكراً لاختيارك متجر زينة للمجوهرات
            </h1>
            <p className="text-xs sm:text-sm text-[#7A6A60] max-w-md mx-auto leading-relaxed">
              تم تسجيل طلبيتك وإصدار فاتورة المبيعات الرسمية. سنقوم بتجهيز القطع في علب الهدايا الفاخرة والتواصل معك هاتفياً قبل التوصيل.
            </p>
          </div>

          <div className="p-4 bg-[#E8DDD0]/60 rounded-2xl border border-[#D8CBBE] text-xs text-[#2B211D] space-y-2">
            <div className="flex justify-between">
              <span>الاسم المستلم:</span>
              <span className="font-bold">{customerName}</span>
            </div>
            <div className="flex justify-between">
              <span>رقم الهاتف:</span>
              <span className="font-bold font-mono">{customerPhone}</span>
            </div>
            <div className="flex justify-between">
              <span>العنوان:</span>
              <span>{city} — {shippingAddress}</span>
            </div>
            <div className="flex justify-between border-t border-[#D8CBBE] pt-2 font-bold text-sm">
              <span className="text-[#B99A68]">المبلغ المطلوب:</span>
              <span className="font-mono text-[#B99A68] text-base">{(grandTotal || 0).toLocaleString()} ج.م</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
            <button
              onClick={() => setCurrentView('account')}
              className="px-6 py-3 bg-[#2B211D] hover:bg-[#B99A68] text-[#F7F1E8] rounded-xl text-xs font-bold transition shadow-md"
            >
              عرض سجل طلباتي السابقة
            </button>
            <button
              onClick={() => setCurrentView('shop')}
              className="px-6 py-3 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-xl text-xs font-bold transition"
            >
              مواصلة التسوق
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 text-right">
      <div className="flex items-center justify-between pb-6 mb-8 border-b border-[#D8CBBE]">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#B99A68]">
            الخطوة الأخيرة
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-serif text-[#2B211D] mt-0.5">
            إتمام الطلب وتأكيد الشحن
          </h1>
        </div>

        <button
          onClick={() => setCurrentView('shop')}
          className="flex items-center gap-1 text-xs font-bold text-[#7A6A60] hover:text-[#2B211D] transition"
        >
          <ArrowRight className="w-4 h-4" />
          <span>العودة للمتجر</span>
        </button>
      </div>

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Customer Form & Payment Method (8 cols) */}
        <div className="lg:col-span-8 space-y-8">
          {/* Section 1: Delivery info */}
          <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-4">
            <h2 className="text-base font-bold font-serif text-[#2B211D] flex items-center gap-2 border-b border-[#D8CBBE] pb-3">
              <Truck className="w-5 h-5 text-[#B99A68]" />
              <span>1. بيانات الشحن والتوصيل</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">الاسم بالكامل *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="مثال: ياسمين سليم"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">رقم الهاتف للتوصيل *</label>
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="01012345678"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">المحافظة / المدينة *</label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                >
                  <option value="القاهرة">القاهرة</option>
                  <option value="الجيزة">الجيزة</option>
                  <option value="الإسكندرية">الإسكندرية</option>
                  <option value="القاهرة الجديدة والتجمع">القاهرة الجديدة والتجمع</option>
                  <option value="الشيخ زايد وأكتوبر">الشيخ زايد وأكتوبر</option>
                  <option value="المنصورة">المنصورة</option>
                  <option value="طنطا">طنطا</option>
                  <option value="بورسعيد">بورسعيد</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-[#2B211D] mb-1">العنوان بالتفصيل *</label>
                <input
                  type="text"
                  required
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  placeholder="الشارع، رقم العمارة، رقم الشقة أو الفيلا"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">البريد الإلكتروني (اختياري)</label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">ملاحظات لمندوب التوصيل</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="التوصيل بالفترة المسائية، الاتصال قبل الوصول..."
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Payment Method */}
          <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-4">
            <h2 className="text-base font-bold font-serif text-[#2B211D] flex items-center gap-2 border-b border-[#D8CBBE] pb-3">
              <CreditCard className="w-5 h-5 text-[#B99A68]" />
              <span>2. طريقة الدفع وتأكيد السداد</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* COD */}
              <label
                className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'cod'
                    ? 'border-[#B99A68] bg-[#E8DDD0]/70 shadow-xs'
                    : 'border-[#D8CBBE] hover:bg-[#E8DDD0]/30'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value="cod"
                  checked={paymentMethod === 'cod'}
                  onChange={() => setPaymentMethod('cod')}
                  className="accent-[#B99A68] mt-1"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <Banknote className="w-4 h-4 text-[#B99A68]" />
                    <span className="font-bold text-xs text-[#2B211D]">الدفع عند الاستلام (COD)</span>
                  </div>
                  <p className="text-[11px] text-[#7A6A60] mt-1">
                    معاينة القطع قبل الدفع نقدياً لمندوب الشحن.
                  </p>
                </div>
              </label>

              {/* InstaPay */}
              <label
                className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'instapay'
                    ? 'border-[#B99A68] bg-[#E8DDD0]/70 shadow-xs'
                    : 'border-[#D8CBBE] hover:bg-[#E8DDD0]/30'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value="instapay"
                  checked={paymentMethod === 'instapay'}
                  onChange={() => setPaymentMethod('instapay')}
                  className="accent-[#B99A68] mt-1"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-[#B76E79]" />
                    <span className="font-bold text-xs text-[#2B211D]">تحويل إنستاباي (InstaPay)</span>
                  </div>
                  <p className="text-[11px] text-[#7A6A60] mt-1">
                    تحويل فوري عبر تطبيق إنستاباي إلى حساب المتجر.
                  </p>
                </div>
              </label>

              {/* Credit Card */}
              <label
                className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'card'
                    ? 'border-[#B99A68] bg-[#E8DDD0]/70 shadow-xs'
                    : 'border-[#D8CBBE] hover:bg-[#E8DDD0]/30'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value="card"
                  checked={paymentMethod === 'card'}
                  onChange={() => setPaymentMethod('card')}
                  className="accent-[#B99A68] mt-1"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#B99A68]" />
                    <span className="font-bold text-xs text-[#2B211D]">بطاقة بنكية (فيزا / ماستركارد)</span>
                  </div>
                  <p className="text-[11px] text-[#7A6A60] mt-1">
                    دفع إلكتروني مشفر وآمن بمعيار 3D Secure.
                  </p>
                </div>
              </label>

              {/* Vodafone Cash */}
              <label
                className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition ${
                  paymentMethod === 'vodafone_cash'
                    ? 'border-[#B99A68] bg-[#E8DDD0]/70 shadow-xs'
                    : 'border-[#D8CBBE] hover:bg-[#E8DDD0]/30'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value="vodafone_cash"
                  checked={paymentMethod === 'vodafone_cash'}
                  onChange={() => setPaymentMethod('vodafone_cash')}
                  className="accent-[#B99A68] mt-1"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-rose-600" />
                    <span className="font-bold text-xs text-[#2B211D]">محفظة فودافون كاش</span>
                  </div>
                  <p className="text-[11px] text-[#7A6A60] mt-1">
                    تحويل مباشر لمحفظة المتجر الإلكترونية.
                  </p>
                </div>
              </label>
            </div>

            {/* InstaPay Info Box */}
            {paymentMethod === 'instapay' && (
              <div className="p-4 bg-[#E8DDD0] rounded-2xl border border-[#D8CBBE] text-xs space-y-1 animate-fadeIn">
                <p className="font-bold text-[#2B211D]">بيانات التحويل عبر إنستاباي:</p>
                <p className="text-[#7A6A60]">عنوان الدفع (IPA): <strong className="text-[#2B211D] font-mono">zeinastore@instapay</strong></p>
                <p className="text-[#7A6A60]">أو رقم الهاتف المرتبط: <strong className="text-[#2B211D] font-mono">01099887766</strong></p>
                <p className="text-[11px] text-[#B76E79]">يرجى كتابة رقم هاتفك في خانة الملاحظات بالتطبيق لتأكيد الدفع فوراً.</p>
              </div>
            )}

            {/* Vodafone Cash Box */}
            {paymentMethod === 'vodafone_cash' && (
              <div className="p-4 bg-rose-50 rounded-2xl border border-rose-200 text-xs space-y-1 animate-fadeIn">
                <p className="font-bold text-rose-900">بيانات تحويل فودافون كاش:</p>
                <p className="text-rose-800">رقم المحفظة: <strong className="font-mono">01099887766</strong></p>
                <p className="text-[11px] text-rose-700">سيتم تأكيد الإيداع وإصدار الفاتورة آلياً بمجرد إتمام التحويل.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Order Summary (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#E8DDD0]/50 p-6 rounded-3xl border border-[#D8CBBE] shadow-md space-y-6">
            <h3 className="font-bold text-base font-serif text-[#2B211D] border-b border-[#D8CBBE] pb-3">
              ملخص الطلب ({cart.length} قطع)
            </h3>

            {/* Items mini list */}
            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {cart.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3 text-xs">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.nameAr}
                    className="w-12 h-12 rounded-xl object-cover border border-[#D8CBBE]"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-[#2B211D] truncate">{item.product.nameAr}</p>
                    <p className="text-[11px] text-[#7A6A60]">
                      الكمية: {item.quantity} {item.selectedColor ? `(${item.selectedColor})` : ''}
                    </p>
                  </div>
                  <span className="font-bold font-mono text-[#2B211D]">
                    {(((item.product.price ?? 0) * (item.quantity ?? 1))).toLocaleString()} ج.م
                  </span>
                </div>
              ))}
            </div>

            {/* Calculations */}
            <div className="space-y-2 text-xs text-[#7A6A60] border-t border-[#D8CBBE] pt-4">
              <div className="flex justify-between">
                <span>المجموع الفرعي:</span>
                <span className="font-bold text-[#2B211D]">{(cartTotal || 0).toLocaleString()} ج.م</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-[#B76E79] font-medium">
                  <span>الخصم ({appliedCoupon?.code || 'كوبون'}):</span>
                  <span>-{(discountAmount || 0).toLocaleString()} ج.م</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>الشحن والتوصيل:</span>
                <span>{shippingFee === 0 ? 'مجاناً' : `${shippingFee} ج.م`}</span>
              </div>

              <div className="border-t border-[#D8CBBE] pt-3 flex justify-between items-center text-base font-bold text-[#2B211D]">
                <span className="text-[#B99A68]">الإجمالي النهائي:</span>
                <span className="text-xl font-mono text-[#B99A68]">{(grandTotal || 0).toLocaleString()} ج.م</span>
              </div>
            </div>

            {/* Submit Order Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-[#2B211D] hover:bg-[#B99A68] text-[#F7F1E8] rounded-2xl font-bold text-sm shadow-xl transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
            >
              <Lock className="w-4 h-4 text-[#D8C19A]" />
              <span>{isSubmitting ? 'جاري تأكيد الطلب...' : 'تأكيد الطلب وإصدار الفاتورة'}</span>
            </button>

            <div className="text-center text-[11px] text-[#7A6A60] flex items-center justify-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>معاينة المنتجات قبل السداد | تغليف هدايا مجاني</span>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

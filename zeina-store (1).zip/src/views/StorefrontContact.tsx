import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Phone, Mail, MapPin, Send, CheckCircle2, MessageCircle, Clock } from 'lucide-react';

export const StorefrontContact: React.FC = () => {
  const { settings, showToast } = useStore();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !message) return;
    setSubmitted(true);
    showToast('شكراً لتواصلك! سنرد عليك خلال ساعات عمل الفريق.');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-right space-y-12">
      {/* Title */}
      <div className="text-center space-y-2">
        <span className="text-xs font-bold uppercase tracking-widest text-[#B99A68]">
          فريق خدمة العملاء
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-[#2B211D]">
          يسعدنا تواصلك مع متجر زينة
        </h1>
        <p className="text-xs sm:text-sm text-[#7A6A60] max-w-lg mx-auto">
          سواء كان لديك استفسار عن مقاسات الخواتم، تفاصيل الأطقم، أو تتبع شحنتك، نحن هنا لمساعدتك دائماً.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Contact Info Cards (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#B99A68]/20 flex items-center justify-center text-[#B99A68]">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-xs text-[#2B211D]">الاتصال المباشر وواتساب</h3>
                <p className="text-xs text-[#7A6A60] font-mono mt-0.5">{settings.phone}</p>
              </div>
            </div>
          </div>

          <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#B76E79]/20 flex items-center justify-center text-[#B76E79]">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-xs text-[#2B211D]">البريد الإلكتروني</h3>
                <p className="text-xs text-[#7A6A60] mt-0.5">{settings.email}</p>
              </div>
            </div>
          </div>

          <div className="bg-[#F7F1E8] p-6 rounded-3xl border border-[#D8CBBE] shadow-xs space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#B99A68]/20 flex items-center justify-center text-[#B99A68]">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-xs text-[#2B211D]">المقر الرئيسي والمعرض</h3>
                <p className="text-xs text-[#7A6A60] mt-0.5">{settings.address}</p>
              </div>
            </div>
          </div>

          <div className="bg-[#E8DDD0]/60 p-6 rounded-3xl border border-[#D8CBBE] space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-[#2B211D]">
              <Clock className="w-4 h-4 text-[#B99A68]" />
              <span>مواعيد خدمة العملاء</span>
            </div>
            <p className="text-xs text-[#7A6A60]">
              يومياً من الساعة 10:00 صباحاً حتى 11:00 مساءً بتوقيت القاهرة.
            </p>
          </div>
        </div>

        {/* Contact Form (7 cols) */}
        <div className="lg:col-span-7 bg-[#F7F1E8] p-8 rounded-3xl border border-[#D8CBBE] shadow-md">
          {submitted ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg font-serif text-[#2B211D]">تم استلام رسالتك بنجاح</h3>
              <p className="text-xs text-[#7A6A60] max-w-sm mx-auto">
                شكراً لتواصلك معنا، سيقوم أحد مستشاري المجوهرات بالرد عليك في أقرب وقت.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setMessage('');
                }}
                className="px-6 py-2 bg-[#2B211D] text-white rounded-full text-xs font-bold hover:bg-[#B99A68] transition"
              >
                إرسال رسالة أخرى
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h3 className="font-bold text-base font-serif text-[#2B211D] border-b border-[#D8CBBE] pb-3">
                أرسلي لنا استفسارك
              </h3>

              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">الاسم الكريم *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="اسمك"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">رقم الهاتف أو واتساب *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01012345678"
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2B211D] mb-1">تفاصيل الرسالة أو الاستفسار *</label>
                <textarea
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="اكتبي استفسارك هنا..."
                  className="w-full bg-[#E8DDD0]/50 border border-[#D8CBBE] rounded-xl px-3.5 py-2.5 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-[#2B211D] hover:bg-[#B99A68] text-[#F7F1E8] rounded-xl font-bold text-xs shadow-md transition flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>إرسال الرسالة لفريق العمل</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard3D } from '../components/ProductCard3D';
import { Logo } from '../components/Logo';
import {
  Sparkles,
  ArrowLeft,
  Gem,
  ShoppingBag,
  CircleDot,
  Watch,
  Disc,
  Star,
  CheckCircle,
  Clock,
  ShieldCheck,
  Percent,
} from 'lucide-react';

export const StorefrontHome: React.FC = () => {
  const {
    products,
    categories,
    banners,
    setCurrentView,
    setSelectedCategorySlug,
    setSelectedProductId,
  } = useStore();

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);

  const featuredProducts = products.filter((p) => p.isFeatured).slice(0, 4);
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 4);
  const activeBanner = banners[activeBannerIdx] || banners[0];

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Gem':
        return <Gem className="w-8 h-8" />;
      case 'Watch':
        return <Watch className="w-8 h-8" />;
      case 'CircleDot':
        return <CircleDot className="w-8 h-8" />;
      case 'Disc':
        return <Disc className="w-8 h-8" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-8 h-8" />;
      default:
        return <Sparkles className="w-8 h-8" />;
    }
  };

  const handleCategorySelect = (slug: string) => {
    setSelectedCategorySlug(slug);
    setCurrentView('shop');
  };

  return (
    <div className="space-y-16 sm:space-y-24 pb-16">
      {/* 1. Hero Section with 3D Parallax & Depth */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#F7F1E8] via-[#E8DDD0]/50 to-[#F7F1E8] pt-6 sm:pt-12 pb-16 border-b border-[#D8CBBE]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left/Right Text in RTL */}
            <div className="lg:col-span-7 space-y-6 text-right">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E8DDD0] border border-[#D8CBBE] text-xs font-bold text-[#B99A68] shadow-xs animate-fadeIn">
                <Sparkles className="w-4 h-4 text-[#B76E79]" />
                <span>{activeBanner?.tagAr || 'تشكيلة خريف 2026 الحصرية'}</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-serif text-[#2B211D] leading-tight tracking-tight">
                {activeBanner?.titleAr || 'فخامة خالدة تليق بأنوثتك الراقية'}
              </h1>

              <p className="text-sm sm:text-base text-[#7A6A60] leading-relaxed max-w-xl">
                {activeBanner?.subtitleAr ||
                  'اكتشفي أرقى الإكسسوارات والمجوهرات المطلية بماء الذهب عيار 18 والمرصعة بأحجار الزركون السويسرية فائقة النقاء.'}
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => {
                    setSelectedCategorySlug(null);
                    setCurrentView('shop');
                  }}
                  className="px-8 py-4 bg-[#2B211D] hover:bg-[#B99A68] text-[#F7F1E8] rounded-full font-bold text-sm shadow-xl transition-all flex items-center gap-3 transform hover:-translate-y-0.5 active:translate-y-0"
                >
                  <span>{activeBanner?.ctaTextAr || 'استكشفي المجموعات'}</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleCategorySelect('jewelry-sets')}
                  className="px-6 py-4 bg-[#E8DDD0] hover:bg-[#D8CBBE] text-[#2B211D] rounded-full font-bold text-sm border border-[#D8CBBE] transition shadow-xs"
                >
                  أطقم الزفاف والمناسبات
                </button>
              </div>

              {/* Social proof metric */}
              <div className="pt-6 flex items-center gap-6 border-t border-[#D8CBBE]/60 text-xs text-[#7A6A60]">
                <div className="flex items-center gap-1.5 text-[#B99A68]">
                  <div className="flex text-amber-500">
                    {'★★★★★'.split('').map((s, i) => (
                      <span key={i}>{s}</span>
                    ))}
                  </div>
                  <span className="font-bold text-[#2B211D]">4.9 / 5.0</span>
                </div>
                <span>•</span>
                <span>أكثر من 3,500 عميلة سعيدة بمصر والخليج</span>
              </div>
            </div>

            {/* Visual 3D Hero Card with Logo & Products */}
            <div className="lg:col-span-5 relative perspective-1000">
              <div className="relative rounded-3xl overflow-hidden border-2 border-[#D8CBBE] shadow-2xl bg-[#E8DDD0] aspect-4/5 transform transition-transform duration-700 hover:rotate-1">
                <img
                  src={activeBanner?.image || 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=85'}
                  alt="Zeina Jewelry"
                  className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-1000"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-[#2B211D]/80 via-transparent to-black/20" />

                {/* Floating Logo Badge on Hero */}
                <div className="absolute top-4 right-4 bg-[#F7F1E8]/90 backdrop-blur-md px-4 py-2 rounded-2xl border border-[#D8CBBE] shadow-lg">
                  <Logo size="sm" showSubtitle={false} />
                </div>

                {/* Floating Bottom Card */}
                <div className="absolute bottom-6 inset-x-6 bg-[#F7F1E8]/95 backdrop-blur-md p-4 rounded-2xl border border-[#D8CBBE] shadow-xl text-right">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-[#B76E79] uppercase bg-[#E8DDD0] px-2 py-0.5 rounded-md">
                      الأكثر طلباً
                    </span>
                    <span className="text-xs font-mono font-bold text-[#2B211D]">3,450 ج.م</span>
                  </div>
                  <h3 className="font-bold text-sm text-[#2B211D] mt-1 font-serif">
                    طقم الزفاف الملكي المطلي ذهب عيار 18
                  </h3>
                  <p className="text-[11px] text-[#7A6A60] mt-0.5">ترصيع زركونيا فاخر مع علبة هدايا مخملية</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Apple-Style Large Categories with Depth */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#B99A68]">
              تسوقي حسب التصنيف
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-[#2B211D] mt-1">
              مجموعات إكسسوارات زينة الفاخرة
            </h2>
          </div>
          <button
            onClick={() => {
              setSelectedCategorySlug(null);
              setCurrentView('shop');
            }}
            className="text-xs font-bold text-[#B99A68] hover:text-[#2B211D] flex items-center gap-1 self-start md:self-auto transition"
          >
            <span>عرض كافة المجموعات</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => handleCategorySelect(cat.slug)}
              className="group relative bg-[#F7F1E8] hover:bg-[#E8DDD0] rounded-3xl p-5 border border-[#D8CBBE] shadow-xs hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col items-center text-center transform hover:-translate-y-1.5"
            >
              {/* Apple-style Large Icon Container */}
              <div className="w-16 h-16 rounded-2xl bg-[#E8DDD0] group-hover:bg-[#B99A68] text-[#B99A68] group-hover:text-white flex items-center justify-center mb-4 transition-colors duration-300 shadow-xs">
                {getCategoryIcon(cat.iconName)}
              </div>

              <h3 className="font-bold text-xs sm:text-sm text-[#2B211D] leading-snug font-serif">
                {cat.nameAr}
              </h3>

              <span className="text-[10px] text-[#7A6A60] mt-1 group-hover:text-[#2B211D] transition">
                {cat.itemCount} تصاميم مختارة
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Featured Products Grid (with 3D tilt cards) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#B76E79]">
              المختارات الملكية
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-[#2B211D] mt-1">
              مجوهرات مميزة لا غنى عنها
            </h2>
          </div>
          <button
            onClick={() => {
              setSelectedCategorySlug(null);
              setCurrentView('shop');
            }}
            className="text-xs font-bold text-[#B99A68] hover:text-[#2B211D] flex items-center gap-1 self-start md:self-auto transition"
          >
            <span>مشاهدة الكل</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((prod) => (
            <ProductCard3D key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* 4. Luxury Promotional Banner with Coupon ZEINA10 */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-[#2B211D] text-[#F7F1E8] border-2 border-[#B99A68] shadow-2xl p-8 sm:p-12">
          {/* Subtle gold decorative accents */}
          <div className="absolute -right-16 -top-16 w-64 h-64 bg-[#B99A68]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -left-16 -bottom-16 w-64 h-64 bg-[#B76E79]/20 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center text-right">
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 bg-[#3B2D27] text-[#D8C19A] px-3.5 py-1 rounded-full text-xs font-bold border border-stone-700">
                <Percent className="w-3.5 h-3.5 text-[#B76E79]" />
                <span>عرض ترحيبي حصري</span>
              </div>

              <h2 className="text-2xl sm:text-4xl font-extrabold font-serif leading-snug">
                احصلي على خصم 10% فوري على طلبيتك الأولى
              </h2>

              <p className="text-xs sm:text-sm text-stone-300 max-w-xl leading-relaxed">
                استخدمي كود الخصم أثناء إتمام الطلب لتستمتعي بتجربة تسوق لا تُنسى مع تغليف الهدايا المخملي الفاخر وشحن سريع لجميع المحافظات.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <div className="flex items-center gap-3 bg-[#1C1513] px-4 py-2.5 rounded-xl border border-[#B99A68]">
                  <span className="text-xs text-stone-400">الكوبون:</span>
                  <span className="font-mono text-base font-bold text-[#D8C19A] tracking-wider">ZEINA10</span>
                </div>

                <button
                  onClick={() => setCurrentView('shop')}
                  className="px-6 py-2.5 bg-[#B99A68] hover:bg-[#A88856] text-white rounded-xl text-xs font-bold transition shadow-md"
                >
                  تسوقي الآن واستفيدي من الخصم
                </button>
              </div>
            </div>

            <div className="lg:col-span-4 flex justify-center">
              <div className="w-48 h-48 rounded-full bg-[#3B2D27] border-4 border-[#B99A68]/40 flex flex-col items-center justify-center p-6 text-center shadow-inner">
                <Logo variant="dark" size="sm" />
                <span className="text-xs text-[#D8C19A] mt-2 font-serif font-bold">هدية مع كل طلب</span>
                <span className="text-[10px] text-stone-400">منديل تلميع المجوهرات الإيطالي</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Best Sellers Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-right">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#B99A68]">
              الأعلى تقييماً
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-[#2B211D] mt-1">
              القطع الأكثر مبيعاً وإعجاباً
            </h2>
          </div>
          <button
            onClick={() => {
              setSelectedCategorySlug(null);
              setCurrentView('shop');
            }}
            className="text-xs font-bold text-[#B99A68] hover:text-[#2B211D] flex items-center gap-1 self-start md:self-auto transition"
          >
            <span>مشاهدة تشكيلة الأكثر طلباً</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map((prod) => (
            <ProductCard3D key={prod.id} product={prod} />
          ))}
        </div>
      </section>
    </div>
  );
};

import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard3D } from '../components/ProductCard3D';
import {
  Star,
  ShoppingBag,
  ShieldCheck,
  RefreshCw,
  Gift,
  ArrowRight,
  Plus,
  Minus,
  CheckCircle,
  Share2,
  Heart,
  MessageSquare,
} from 'lucide-react';

export const StorefrontProductDetail: React.FC = () => {
  const {
    products,
    selectedProductId,
    setCurrentView,
    addToCart,
    reviews,
    addReviewAction,
    currentUser,
    showToast,
  } = useStore();

  const product = products.find((p) => p.id === selectedProductId) || products[0];

  const [selectedImgIdx, setSelectedImgIdx] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string>(product.colors?.[0] || 'شامبين جولد');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'details' | 'care' | 'shipping'>('details');

  // Review form state
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewName, setReviewName] = useState(currentUser?.name || '');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p>المنتج غير موجود</p>
        <button onClick={() => setCurrentView('shop')} className="mt-4 px-6 py-2 bg-[#2B211D] text-white rounded-full">
          العودة للمتجر
        </button>
      </div>
    );
  }

  const productReviews = reviews.filter((r) => r.productId === product.id && r.status === 'approved');
  const relatedProducts = products
    .filter((p) => p.categoryId === product.categoryId && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedColor);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('تم نسخ رابط المنتج إلى الحافظة ✨');
    }
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName || !reviewComment) return;

    addReviewAction({
      productId: product.id,
      productName: product.nameAr,
      customerName: reviewName,
      rating: reviewRating,
      comment: reviewComment,
    });

    setReviewComment('');
    setShowReviewForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 text-right">
      {/* Breadcrumb / Back button */}
      <div className="flex items-center justify-between pb-6 mb-8 border-b border-[#D8CBBE]">
        <button
          onClick={() => setCurrentView('shop')}
          className="flex items-center gap-2 text-xs font-bold text-[#7A6A60] hover:text-[#2B211D] transition"
        >
          <ArrowRight className="w-4 h-4" />
          <span>العودة إلى تشكيلة الإكسسوارات</span>
        </button>

        <button
          onClick={handleShare}
          className="p-2 text-[#7A6A60] hover:text-[#2B211D] hover:bg-[#E8DDD0] rounded-full transition flex items-center gap-1.5 text-xs"
          title="مشاركة المنتج"
        >
          <Share2 className="w-4 h-4" />
          <span className="hidden sm:inline">مشاركة</span>
        </button>
      </div>

      {/* Main Product Showcase Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-16">
        {/* Gallery Column */}
        <div className="lg:col-span-6 space-y-4">
          <div className="relative aspect-square rounded-3xl overflow-hidden bg-[#E8DDD0] border border-[#D8CBBE] shadow-xl">
            <img
              src={product.images[selectedImgIdx] || product.images[0]}
              alt={product.nameAr}
              className="w-full h-full object-cover object-center"
            />

            {/* Badges */}
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              {product.isBestSeller && (
                <span className="bg-[#B76E79] text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                  الأكثر طلباً
                </span>
              )}
              {product.isFeatured && (
                <span className="bg-[#B99A68] text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                  مختارات زينة
                </span>
              )}
            </div>
          </div>

          {/* Thumbnails row */}
          {product.images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImgIdx(idx)}
                  className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-all shrink-0 ${
                    selectedImgIdx === idx
                      ? 'border-[#B99A68] shadow-md scale-105'
                      : 'border-[#D8CBBE] opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Details & Actions Column */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            <div className="flex items-center justify-between text-xs text-[#7A6A60] mb-2">
              <span className="font-semibold">{product.categoryName}</span>
              <span className="font-mono">كود: {product.sku}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold font-serif text-[#2B211D] leading-snug">
              {product.nameAr}
            </h1>

            {/* Rating Stars */}
            <div className="flex items-center gap-3 mt-3">
              <div className="flex text-amber-500">
                {'★★★★★'.split('').map((s, i) => (
                  <span key={i} className={i < Math.floor(product.rating) ? 'opacity-100' : 'opacity-40'}>
                    {s}
                  </span>
                ))}
              </div>
              <span className="text-xs font-bold text-[#2B211D]">{product.rating.toFixed(1)}</span>
              <span className="text-xs text-[#7A6A60]">
                ({product.reviewsCount + productReviews.length} تقييم حقيقي)
              </span>
            </div>
          </div>

          {/* Price Box */}
          <div className="p-4 rounded-2xl bg-[#E8DDD0]/50 border border-[#D8CBBE] flex items-center justify-between">
            <div>
              <span className="text-xs text-[#7A6A60] block">السعر الإجمالي شامل العلبة الفاخرة</span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-3xl font-extrabold font-mono text-[#2B211D]">
                  {(product.price ?? 0).toLocaleString()}
                </span>
                <span className="text-sm font-bold text-[#7A6A60]">جنيه مصري</span>
              </div>
            </div>

            <div className="text-left">
              {product.stock > 0 ? (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>متوفر بالمخزون ({product.stock} قطعة)</span>
                </span>
              ) : (
                <span className="text-xs font-bold text-rose-700 bg-rose-100 px-3 py-1 rounded-full">
                  نفدت الكمية حالياً
                </span>
              )}
            </div>
          </div>

          {/* Color Selector */}
          {product.colors && product.colors.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-[#2B211D] mb-2">
                درجة الطلاء / اللون: <span className="text-[#B99A68]">{selectedColor}</span>
              </label>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c}
                    onClick={() => setSelectedColor(c)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition ${
                      selectedColor === c
                        ? 'bg-[#2B211D] text-white border-[#2B211D] shadow-sm'
                        : 'bg-[#F7F1E8] text-[#2B211D] border-[#D8CBBE] hover:bg-[#E8DDD0]'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity & Add to Cart */}
          <div className="flex items-center gap-4 pt-2">
            {/* Quantity Stepper */}
            <div className="flex items-center border border-[#D8CBBE] rounded-2xl bg-[#E8DDD0]/50 p-1">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-10 h-10 flex items-center justify-center rounded-xl bg-[#F7F1E8] text-[#2B211D] hover:bg-[#D8CBBE] transition"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-12 text-center font-mono font-bold text-sm text-[#2B211D]">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity(Math.min(product.stock || 10, quantity + 1))}
                className="w-10 h-10 flex items-center justify-center rounded-xl bg-[#F7F1E8] text-[#2B211D] hover:bg-[#D8CBBE] transition"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Add to Cart CTA */}
            <button
              onClick={handleAddToCart}
              disabled={product.stock <= 0}
              className="flex-1 py-4 bg-[#2B211D] hover:bg-[#B99A68] text-[#F7F1E8] rounded-2xl font-bold text-sm shadow-xl transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
            >
              <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span>إضافة لحقيبة التسوق الفاخرة</span>
            </button>
          </div>

          {/* Feature Badges */}
          <div className="grid grid-cols-3 gap-3 pt-4 border-t border-[#D8CBBE]">
            <div className="p-3 bg-[#E8DDD0]/40 rounded-xl border border-[#D8CBBE]/60 text-center">
              <Gift className="w-5 h-5 text-[#B76E79] mx-auto mb-1" />
              <p className="text-[11px] font-bold text-[#2B211D]">تغليف هدايا ملكي</p>
              <p className="text-[10px] text-[#7A6A60]">علبة مخملية راقية</p>
            </div>
            <div className="p-3 bg-[#E8DDD0]/40 rounded-xl border border-[#D8CBBE]/60 text-center">
              <ShieldCheck className="w-5 h-5 text-[#B99A68] mx-auto mb-1" />
              <p className="text-[11px] font-bold text-[#2B211D]">ضمان أصالة 18k</p>
              <p className="text-[10px] text-[#7A6A60]">مقاوم للماء والعطور</p>
            </div>
            <div className="p-3 bg-[#E8DDD0]/40 rounded-xl border border-[#D8CBBE]/60 text-center">
              <RefreshCw className="w-5 h-5 text-[#B99A68] mx-auto mb-1" />
              <p className="text-[11px] font-bold text-[#2B211D]">استبدال 14 يوم</p>
              <p className="text-[10px] text-[#7A6A60]">معاينة قبل الاستلام</p>
            </div>
          </div>

          {/* Tabs Details */}
          <div className="pt-4">
            <div className="flex border-b border-[#D8CBBE] text-xs font-bold">
              <button
                onClick={() => setActiveTab('details')}
                className={`py-3 px-4 border-b-2 transition ${
                  activeTab === 'details'
                    ? 'border-[#B99A68] text-[#2B211D]'
                    : 'border-transparent text-[#7A6A60] hover:text-[#2B211D]'
                }`}
              >
                المواصفات والخامة
              </button>
              <button
                onClick={() => setActiveTab('care')}
                className={`py-3 px-4 border-b-2 transition ${
                  activeTab === 'care'
                    ? 'border-[#B99A68] text-[#2B211D]'
                    : 'border-transparent text-[#7A6A60] hover:text-[#2B211D]'
                }`}
              >
                إرشادات العناية
              </button>
              <button
                onClick={() => setActiveTab('shipping')}
                className={`py-3 px-4 border-b-2 transition ${
                  activeTab === 'shipping'
                    ? 'border-[#B99A68] text-[#2B211D]'
                    : 'border-transparent text-[#7A6A60] hover:text-[#2B211D]'
                }`}
              >
                الشحن والتوصيل
              </button>
            </div>

            <div className="p-4 text-xs text-[#2B211D] leading-relaxed bg-[#E8DDD0]/20 rounded-b-2xl">
              {activeTab === 'details' && (
                <div className="space-y-2">
                  <p>{product.descriptionAr}</p>
                  <p className="font-semibold text-[#7A6A60]">
                    الخامة: <span className="text-[#2B211D]">{product.material || 'نحاس عالي النقاء مطلي بماء الذهب'}</span>
                  </p>
                </div>
              )}
              {activeTab === 'care' && (
                <ul className="list-disc list-inside space-y-1.5 text-[#7A6A60]">
                  <li>احفظي القطعة في علبتها المخملية الخاصة أو كيس زينة القماشي عند عدم الارتداء.</li>
                  <li>يُفضل ارتداء المجوهرات بعد وضع العطور ومستحضرات التجميل.</li>
                  <li>نظفي القطعة بلطف بقطعة القماش الإيطالية المرفقة مع الطلب للحفاظ على لمعانها البراق.</li>
                </ul>
              )}
              {activeTab === 'shipping' && (
                <div className="space-y-1.5 text-[#7A6A60]">
                  <p>• التوصيل خلال 24 إلى 48 ساعة داخل القاهرة والجيزة والإسكندرية.</p>
                  <p>• التوصيل لجميع باقي محافظات مصر خلال 2-3 أيام عمل.</p>
                  <p>• شحن مجاني للطلبيات بقيمة 1,500 ج.م فأكثر.</p>
                  <p>• إمكانية فتح الشحنة ومعاينة المنتج أمام مندوب التوصيل قبل السداد.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Customer Reviews Section */}
      <section className="border-t border-[#D8CBBE] pt-12 mb-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold font-serif text-[#2B211D]">
              آراء وتقييمات العملاء
            </h3>
            <p className="text-xs text-[#7A6A60] mt-1">
              تجارب حقيقية لعميلات متجر زينة الفاخر
            </p>
          </div>

          <button
            onClick={() => setShowReviewForm(!showReviewForm)}
            className="px-4 py-2 bg-[#2B211D] hover:bg-[#B99A68] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>كتابة تقييم</span>
          </button>
        </div>

        {/* Review Form Modal/Drawer */}
        {showReviewForm && (
          <form
            onSubmit={handleSubmitReview}
            className="mb-8 p-6 bg-[#E8DDD0]/50 rounded-2xl border border-[#D8CBBE] space-y-4 max-w-xl animate-fadeIn"
          >
            <h4 className="font-bold text-sm text-[#2B211D]">شاركينا رأيك بالمنتج</h4>
            <div>
              <label className="block text-xs font-bold text-[#2B211D] mb-1">اسمك الكريم</label>
              <input
                type="text"
                required
                value={reviewName}
                onChange={(e) => setReviewName(e.target.value)}
                placeholder="اسمك أو اللقب"
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] rounded-xl px-3 py-2 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2B211D] mb-1">التقييم</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    type="button"
                    key={star}
                    onClick={() => setReviewRating(star)}
                    className={`text-lg transition ${star <= reviewRating ? 'text-amber-500 scale-110' : 'text-stone-300'}`}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#2B211D] mb-1">تعليقك وتجربتك مع القطعة</label>
              <textarea
                required
                rows={3}
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="صفي لمعان القطعة، التغليف، سرعة التوصيل..."
                className="w-full bg-[#F7F1E8] border border-[#D8CBBE] rounded-xl px-3 py-2 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowReviewForm(false)}
                className="px-4 py-2 bg-transparent text-[#7A6A60] text-xs font-bold rounded-xl hover:bg-[#E8DDD0]"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#B99A68] hover:bg-[#A88856] text-white text-xs font-bold rounded-xl transition"
              >
                إرسال التقييم
              </button>
            </div>
          </form>
        )}

        {/* Reviews List */}
        <div className="space-y-4">
          {productReviews.length === 0 ? (
            <p className="text-xs text-[#7A6A60] italic py-4">
              لا توجد تقييمات مكتوبة لهذا المنتج بعد. كوني أول من يشاركنا رأيه الراقي!
            </p>
          ) : (
            productReviews.map((rev) => (
              <div
                key={rev.id}
                className="p-4 bg-[#F7F1E8] rounded-2xl border border-[#D8CBBE] shadow-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-[#2B211D]">{rev.customerName}</span>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-medium">
                      مشترية مؤكدة ✓
                    </span>
                  </div>
                  <div className="flex text-amber-500 text-xs">
                    {'★★★★★'.split('').map((s, i) => (
                      <span key={i} className={i < rev.rating ? 'opacity-100' : 'opacity-30'}>
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-[#2B211D] leading-relaxed">{rev.comment}</p>
                <span className="text-[10px] text-[#7A6A60] block">{rev.date}</span>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <section className="border-t border-[#D8CBBE] pt-12">
          <h3 className="text-xl sm:text-2xl font-bold font-serif text-[#2B211D] mb-6">
            قطع تكتمل بها إطلالتك
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard3D key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard3D } from '../components/ProductCard3D';
import { Search, SlidersHorizontal, ArrowUpDown, X, Sparkles } from 'lucide-react';

export const StorefrontShop: React.FC = () => {
  const { products, categories, selectedCategorySlug, setSelectedCategorySlug } = useStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>(selectedCategorySlug || 'all');
  const [maxPrice, setMaxPrice] = useState<number>(5000);
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'rating' | 'bestseller'>('newest');

  // Filter & Sort
  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        if (p.status !== 'active') return false;

        // Search
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const match =
            p.nameAr.toLowerCase().includes(q) ||
            p.name.toLowerCase().includes(q) ||
            (p.descriptionAr && p.descriptionAr.toLowerCase().includes(q)) ||
            (p.categoryName && p.categoryName.toLowerCase().includes(q)) ||
            p.sku.toLowerCase().includes(q);
          if (!match) return false;
        }

        // Category
        if (selectedCat !== 'all') {
          const foundCat = categories.find((c) => c.slug === selectedCat || c.id === selectedCat);
          if (foundCat && p.categoryId !== foundCat.id) return false;
        }

        // Price
        if (p.price > maxPrice) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'bestseller') return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [products, categories, searchQuery, selectedCat, maxPrice, sortBy]);

  const handleCategoryChange = (slug: string) => {
    setSelectedCat(slug);
    setSelectedCategorySlug(slug === 'all' ? null : slug);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCat('all');
    setSelectedCategorySlug(null);
    setMaxPrice(5000);
    setSortBy('newest');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 text-right">
      {/* Page Header */}
      <div className="border-b border-[#D8CBBE] pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#B99A68]">
            متجر زينة الإلكتروني
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold font-serif text-[#2B211D] mt-1">
            تشكيلة الإكسسوارات والمجوهرات
          </h1>
          <p className="text-xs sm:text-sm text-[#7A6A60] mt-1">
            استكشفي أحدث القطع المصنوعة بحرفية مطلية بالذهب ومرصعة بأحجار الزركون الفاخرة
          </p>
        </div>

        <div className="text-xs text-[#7A6A60] bg-[#E8DDD0] px-3.5 py-1.5 rounded-full font-medium self-start md:self-auto">
          عرض <span className="font-bold text-[#2B211D]">{filteredProducts.length}</span> من أصل{' '}
          <span className="font-bold text-[#2B211D]">{products.length}</span> قطعة
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="bg-[#E8DDD0]/50 p-4 sm:p-6 rounded-3xl border border-[#D8CBBE] mb-8 space-y-4">
        {/* Search & Sort line */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-8 relative">
            <input
              type="text"
              placeholder="ابحثي عن اسم المنتج، الموديل، الخامة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#F7F1E8] border border-[#D8CBBE] rounded-2xl px-4 py-3 pl-10 text-xs text-[#2B211D] focus:outline-none focus:ring-1 focus:ring-[#B99A68]"
            />
            <Search className="w-4 h-4 text-[#7A6A60] absolute left-3.5 top-3.5" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-10 top-3 text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="md:col-span-4 relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-[#F7F1E8] border border-[#D8CBBE] rounded-2xl px-4 py-3 text-xs text-[#2B211D] font-medium focus:outline-none focus:ring-1 focus:ring-[#B99A68] appearance-none pr-4"
            >
              <option value="newest">الترتيب: الأحدث إضافةً</option>
              <option value="bestseller">الترتيب: الأكثر طلباً</option>
              <option value="rating">الترتيب: الأعلى تقييماً</option>
              <option value="price-asc">السعر: من الأقل للأعلى</option>
              <option value="price-desc">السعر: من الأعلى للأقل</option>
            </select>
            <ArrowUpDown className="w-4 h-4 text-[#7A6A60] absolute left-3.5 top-3.5 pointer-events-none" />
          </div>
        </div>

        {/* Category Pills & Price Slider */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pt-2 border-t border-[#D8CBBE]/60">
          {/* Categories Pill Scroller */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            <button
              onClick={() => handleCategoryChange('all')}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCat === 'all'
                  ? 'bg-[#2B211D] text-[#F7F1E8] shadow-sm'
                  : 'bg-[#F7F1E8] text-[#2B211D] hover:bg-[#D8CBBE]'
              }`}
            >
              الكل
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategoryChange(cat.slug)}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCat === cat.slug || selectedCat === cat.id
                    ? 'bg-[#2B211D] text-[#F7F1E8] shadow-sm'
                    : 'bg-[#F7F1E8] text-[#2B211D] hover:bg-[#D8CBBE]'
                }`}
              >
                {cat.nameAr}
              </button>
            ))}
          </div>

          {/* Price Range */}
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-xs text-[#7A6A60]">أقصى سعر:</span>
            <input
              type="range"
              min="500"
              max="5000"
              step="100"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="accent-[#B99A68] w-28 sm:w-36 cursor-pointer"
            />
            <span className="text-xs font-bold font-mono text-[#2B211D] min-w-16">
              {maxPrice.toLocaleString()} ج.م
            </span>

            {(searchQuery || selectedCat !== 'all' || maxPrice < 5000) && (
              <button
                onClick={handleResetFilters}
                className="text-xs text-rose-700 hover:underline flex items-center gap-1 mr-2"
              >
                <X className="w-3.5 h-3.5" />
                <span>إلغاء الفلاتر</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-20 bg-[#E8DDD0]/30 rounded-3xl border border-[#D8CBBE]">
          <div className="w-16 h-16 rounded-full bg-[#E8DDD0] mx-auto flex items-center justify-center text-[#7A6A60] mb-4">
            <Sparkles className="w-8 h-8 text-[#B99A68]" />
          </div>
          <h3 className="font-bold text-base text-[#2B211D]">لم يتم العثور على قطع تطابق بحثك</h3>
          <p className="text-xs text-[#7A6A60] mt-1 max-w-sm mx-auto">
            جربي تعديل معايير البحث أو اختيار فئة مجوهرات مختلفة لتصفح التشكيلة الكاملة.
          </p>
          <button
            onClick={handleResetFilters}
            className="mt-6 px-6 py-2.5 bg-[#2B211D] text-[#F7F1E8] rounded-full text-xs font-bold hover:bg-[#B99A68] transition"
          >
            إعادة تعيين الفلاتر
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard3D key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};
